﻿namespace Admiral.ImportData.Win.Editors
{
    partial class UserControl1
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            DevExpress.XtraBars.Ribbon.ReduceOperation reduceOperation1 = new DevExpress.XtraBars.Ribbon.ReduceOperation();
            DevExpress.XtraBars.Ribbon.GalleryItemGroup galleryItemGroup1 = new DevExpress.XtraBars.Ribbon.GalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem1 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem2 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem3 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem4 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem5 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem6 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem7 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem8 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem9 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem10 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem11 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup1 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem12 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem13 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem14 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem15 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem16 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem17 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup2 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem18 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem19 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem20 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem21 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem22 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem23 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup3 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem24 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem25 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem26 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem27 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem28 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem29 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem30 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem31 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem32 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem33 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem34 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem35 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup4 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem36 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem37 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem38 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem39 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem40 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem41 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem42 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup5 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem43 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem44 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem45 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem46 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem47 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup6 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem48 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem49 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem50 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup7 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem51 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem52 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem53 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem54 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem55 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup8 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem56 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem57 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem58 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup9 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem59 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem60 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem61 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem62 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup10 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem63 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem64 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem65 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem66 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup11 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem67 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem68 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem69 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem70 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup12 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem71 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem72 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem73 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem74 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup13 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem75 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem76 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem77 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem78 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem79 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem80 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup14 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem81 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup15 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem82 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem83 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup16 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem84 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem85 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup17 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem86 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem87 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup18 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem88 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem89 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem90 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup19 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem91 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem92 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem93 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup20 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem94 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem95 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem96 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup21 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem97 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem98 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem99 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup22 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem100 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem101 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem102 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup23 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem103 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem104 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem105 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup24 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem106 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem107 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem108 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup25 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem109 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem110 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem111 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem112 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem113 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup26 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem114 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem115 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup27 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem116 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem117 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem118 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem119 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup28 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem120 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem121 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem122 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup29 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem123 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem124 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem125 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup30 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem126 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem127 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup31 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem128 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem129 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem130 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem131 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup32 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem132 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem133 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem134 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem135 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem136 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem137 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem138 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup33 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem139 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem140 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem141 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem142 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem143 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem144 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem145 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem146 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem147 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem148 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem149 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup34 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem150 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem151 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem152 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem153 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem154 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem155 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem156 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem157 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem158 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup35 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem159 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem160 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem161 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem162 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem163 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem164 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem165 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem166 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem167 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup36 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem168 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem169 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem170 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem171 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup37 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem172 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem173 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem174 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem175 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup38 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem176 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem177 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem178 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem179 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem180 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup39 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem181 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem182 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup spreadsheetCommandGalleryItemGroup40 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItemGroup();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem183 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem184 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem185 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem spreadsheetCommandGalleryItem186 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandGalleryItem();
            this.SpreadSheet = new DevExpress.XtraSpreadsheet.SpreadsheetControl();
            this.ribbonControl1 = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.spreadsheetBarController1 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetBarController();
            this.commonRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.CommonRibbonPageGroup();
            this.fileRibbonPage1 = new DevExpress.XtraSpreadsheet.UI.FileRibbonPage();
            this.spreadsheetCommandBarButtonItem1 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem2 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem3 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem4 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem5 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem6 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem7 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem8 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem9 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.infoRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.InfoRibbonPageGroup();
            this.spreadsheetCommandBarButtonItem10 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.clipboardRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.ClipboardRibbonPageGroup();
            this.homeRibbonPage1 = new DevExpress.XtraSpreadsheet.UI.HomeRibbonPage();
            this.spreadsheetCommandBarButtonItem11 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem12 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem13 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem14 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.fontRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.FontRibbonPageGroup();
            this.changeFontNameItem1 = new DevExpress.XtraSpreadsheet.UI.ChangeFontNameItem();
            this.changeFontSizeItem1 = new DevExpress.XtraSpreadsheet.UI.ChangeFontSizeItem();
            this.spreadsheetCommandBarButtonItem15 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem16 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarCheckItem1 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarCheckItem2 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarCheckItem3 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarCheckItem4 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarSubItem1 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem17 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem18 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem19 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem20 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem21 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem22 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem23 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem24 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem25 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem26 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem27 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem28 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem29 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.changeBorderLineColorItem1 = new DevExpress.XtraSpreadsheet.UI.ChangeBorderLineColorItem();
            this.changeBorderLineStyleItem1 = new DevExpress.XtraSpreadsheet.UI.ChangeBorderLineStyleItem();
            this.commandBarGalleryDropDown1 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.changeCellFillColorItem1 = new DevExpress.XtraSpreadsheet.UI.ChangeCellFillColorItem();
            this.changeFontColorItem1 = new DevExpress.XtraSpreadsheet.UI.ChangeFontColorItem();
            this.barButtonGroup1 = new DevExpress.XtraBars.BarButtonGroup();
            this.repositoryItemFontEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemFontEdit();
            this.repositoryItemSpreadsheetFontSizeEdit1 = new DevExpress.XtraSpreadsheet.Design.RepositoryItemSpreadsheetFontSizeEdit();
            this.barButtonGroup2 = new DevExpress.XtraBars.BarButtonGroup();
            this.barButtonGroup3 = new DevExpress.XtraBars.BarButtonGroup();
            this.barButtonGroup4 = new DevExpress.XtraBars.BarButtonGroup();
            this.alignmentRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.AlignmentRibbonPageGroup();
            this.spreadsheetCommandBarCheckItem5 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarCheckItem6 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarCheckItem7 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarCheckItem8 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarCheckItem9 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarCheckItem10 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarButtonItem30 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem31 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarCheckItem11 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarSubItem2 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarCheckItem12 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarButtonItem32 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem33 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem34 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.barButtonGroup5 = new DevExpress.XtraBars.BarButtonGroup();
            this.barButtonGroup6 = new DevExpress.XtraBars.BarButtonGroup();
            this.barButtonGroup7 = new DevExpress.XtraBars.BarButtonGroup();
            this.numberRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.NumberRibbonPageGroup();
            this.changeNumberFormatItem1 = new DevExpress.XtraSpreadsheet.UI.ChangeNumberFormatItem();
            this.spreadsheetCommandBarSubItem3 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem35 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem36 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem37 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem38 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem39 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem40 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem41 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem42 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem43 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.barButtonGroup8 = new DevExpress.XtraBars.BarButtonGroup();
            this.repositoryItemPopupGalleryEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemPopupGalleryEdit();
            this.barButtonGroup9 = new DevExpress.XtraBars.BarButtonGroup();
            this.barButtonGroup10 = new DevExpress.XtraBars.BarButtonGroup();
            this.stylesRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.StylesRibbonPageGroup();
            this.spreadsheetCommandBarSubItem4 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarSubItem5 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem44 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem45 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem46 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem47 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem48 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem49 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem50 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarSubItem6 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem51 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem52 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem53 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem54 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem55 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem56 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonGalleryDropDownItem1 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem();
            this.commandBarGalleryDropDown2 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.spreadsheetCommandBarButtonGalleryDropDownItem2 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem();
            this.commandBarGalleryDropDown3 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.spreadsheetCommandBarButtonGalleryDropDownItem3 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem();
            this.commandBarGalleryDropDown4 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.spreadsheetCommandBarSubItem7 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem57 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem58 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.galleryFormatAsTableItem1 = new DevExpress.XtraSpreadsheet.UI.GalleryFormatAsTableItem();
            this.commandBarGalleryDropDown5 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.galleryChangeStyleItem1 = new DevExpress.XtraSpreadsheet.UI.GalleryChangeStyleItem();
            this.cellsRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.CellsRibbonPageGroup();
            this.spreadsheetCommandBarSubItem8 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem59 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem60 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem61 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarSubItem9 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem62 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem63 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem64 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarSubItem10 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem65 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem66 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem67 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem68 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem69 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarSubItem11 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem70 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem71 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem72 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem73 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem74 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem75 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem76 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem77 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.changeSheetTabColorItem1 = new DevExpress.XtraSpreadsheet.UI.ChangeSheetTabColorItem();
            this.spreadsheetCommandBarButtonItem78 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarCheckItem13 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarButtonItem79 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.editingRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.EditingRibbonPageGroup();
            this.spreadsheetCommandBarSubItem12 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem80 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem81 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem82 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem83 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem84 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarSubItem13 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem85 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem86 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem87 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem88 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarSubItem14 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem89 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem90 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem91 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem92 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem93 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem94 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarSubItem15 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem95 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem96 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarCheckItem14 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarButtonItem97 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem98 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarSubItem16 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem99 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem100 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem101 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem102 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem103 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem104 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem105 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.tablesRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.TablesRibbonPageGroup();
            this.insertRibbonPage1 = new DevExpress.XtraSpreadsheet.UI.InsertRibbonPage();
            this.spreadsheetCommandBarButtonItem106 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem107 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.illustrationsRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.IllustrationsRibbonPageGroup();
            this.spreadsheetCommandBarButtonItem108 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.chartsRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.ChartsRibbonPageGroup();
            this.spreadsheetCommandBarButtonGalleryDropDownItem4 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem();
            this.commandBarGalleryDropDown6 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.spreadsheetCommandBarButtonGalleryDropDownItem5 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem();
            this.commandBarGalleryDropDown7 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.spreadsheetCommandBarButtonGalleryDropDownItem6 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem();
            this.commandBarGalleryDropDown8 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.spreadsheetCommandBarButtonGalleryDropDownItem7 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem();
            this.commandBarGalleryDropDown9 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.spreadsheetCommandBarButtonGalleryDropDownItem8 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem();
            this.commandBarGalleryDropDown10 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.spreadsheetCommandBarButtonGalleryDropDownItem9 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem();
            this.commandBarGalleryDropDown11 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.spreadsheetCommandBarButtonGalleryDropDownItem10 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem();
            this.commandBarGalleryDropDown12 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.linksRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.LinksRibbonPageGroup();
            this.spreadsheetCommandBarButtonItem109 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.symbolsRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.SymbolsRibbonPageGroup();
            this.spreadsheetCommandBarButtonItem110 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.pageSetupRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.PageSetupRibbonPageGroup();
            this.pageLayoutRibbonPage1 = new DevExpress.XtraSpreadsheet.UI.PageLayoutRibbonPage();
            this.spreadsheetCommandBarSubItem17 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarCheckItem15 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarCheckItem16 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarCheckItem17 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarButtonItem111 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarSubItem18 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarCheckItem18 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarCheckItem19 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.pageSetupPaperKindItem1 = new DevExpress.XtraSpreadsheet.UI.PageSetupPaperKindItem();
            this.spreadsheetCommandBarSubItem19 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem112 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem113 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem114 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.pageSetupShowRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.PageSetupShowRibbonPageGroup();
            this.spreadsheetCommandBarCheckItem20 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarCheckItem21 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.pageSetupPrintRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.PageSetupPrintRibbonPageGroup();
            this.spreadsheetCommandBarCheckItem22 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarCheckItem23 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.arrangeRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.ArrangeRibbonPageGroup();
            this.spreadsheetCommandBarSubItem20 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem115 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem116 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarSubItem21 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem117 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem118 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.functionLibraryRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.FunctionLibraryRibbonPageGroup();
            this.formulasRibbonPage1 = new DevExpress.XtraSpreadsheet.UI.FormulasRibbonPage();
            this.spreadsheetCommandBarSubItem22 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem119 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem120 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem121 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem122 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem123 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.functionsFinancialItem1 = new DevExpress.XtraSpreadsheet.UI.FunctionsFinancialItem();
            this.functionsLogicalItem1 = new DevExpress.XtraSpreadsheet.UI.FunctionsLogicalItem();
            this.functionsTextItem1 = new DevExpress.XtraSpreadsheet.UI.FunctionsTextItem();
            this.functionsDateAndTimeItem1 = new DevExpress.XtraSpreadsheet.UI.FunctionsDateAndTimeItem();
            this.functionsLookupAndReferenceItem1 = new DevExpress.XtraSpreadsheet.UI.FunctionsLookupAndReferenceItem();
            this.functionsMathAndTrigonometryItem1 = new DevExpress.XtraSpreadsheet.UI.FunctionsMathAndTrigonometryItem();
            this.spreadsheetCommandBarSubItem23 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.functionsStatisticalItem1 = new DevExpress.XtraSpreadsheet.UI.FunctionsStatisticalItem();
            this.functionsEngineeringItem1 = new DevExpress.XtraSpreadsheet.UI.FunctionsEngineeringItem();
            this.functionsInformationItem1 = new DevExpress.XtraSpreadsheet.UI.FunctionsInformationItem();
            this.functionsCompatibilityItem1 = new DevExpress.XtraSpreadsheet.UI.FunctionsCompatibilityItem();
            this.functionsWebItem1 = new DevExpress.XtraSpreadsheet.UI.FunctionsWebItem();
            this.formulaDefinedNamesRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.FormulaDefinedNamesRibbonPageGroup();
            this.spreadsheetCommandBarButtonItem124 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem125 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.definedNameListItem1 = new DevExpress.XtraSpreadsheet.UI.DefinedNameListItem();
            this.spreadsheetCommandBarButtonItem126 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.formulaAuditingRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.FormulaAuditingRibbonPageGroup();
            this.spreadsheetCommandBarCheckItem24 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.formulaCalculationRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.FormulaCalculationRibbonPageGroup();
            this.spreadsheetCommandBarSubItem24 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarCheckItem25 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarCheckItem26 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarButtonItem127 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem128 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.sortAndFilterRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.SortAndFilterRibbonPageGroup();
            this.dataRibbonPage1 = new DevExpress.XtraSpreadsheet.UI.DataRibbonPage();
            this.dataToolsRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.DataToolsRibbonPageGroup();
            this.spreadsheetCommandBarSubItem25 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem129 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem130 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem131 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.outlineRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.OutlineRibbonPageGroup();
            this.spreadsheetCommandBarSubItem26 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem132 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem133 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarSubItem27 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem134 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem135 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem136 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem137 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem138 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.commentsRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.CommentsRibbonPageGroup();
            this.reviewRibbonPage1 = new DevExpress.XtraSpreadsheet.UI.ReviewRibbonPage();
            this.spreadsheetCommandBarButtonItem139 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem140 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem141 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem142 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.changesRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.ChangesRibbonPageGroup();
            this.spreadsheetCommandBarButtonItem143 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem144 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem145 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem146 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.showRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.ShowRibbonPageGroup();
            this.viewRibbonPage1 = new DevExpress.XtraSpreadsheet.UI.ViewRibbonPage();
            this.zoomRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.ZoomRibbonPageGroup();
            this.spreadsheetCommandBarButtonItem147 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem148 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem149 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.windowRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.WindowRibbonPageGroup();
            this.spreadsheetCommandBarSubItem28 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem150 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem151 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem152 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem153 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.chartsDesignTypeRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.ChartsDesignTypeRibbonPageGroup();
            this.chartsDesignRibbonPage1 = new DevExpress.XtraSpreadsheet.UI.ChartsDesignRibbonPage();
            this.chartToolsRibbonPageCategory1 = new DevExpress.XtraSpreadsheet.UI.ChartToolsRibbonPageCategory();
            this.spreadsheetCommandBarButtonItem154 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.chartsDesignDataRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.ChartsDesignDataRibbonPageGroup();
            this.spreadsheetCommandBarButtonItem155 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem156 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.chartsDesignLayoutsRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.ChartsDesignLayoutsRibbonPageGroup();
            this.galleryChartLayoutItem1 = new DevExpress.XtraSpreadsheet.UI.GalleryChartLayoutItem();
            this.chartsDesignStylesRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.ChartsDesignStylesRibbonPageGroup();
            this.galleryChartStyleItem1 = new DevExpress.XtraSpreadsheet.UI.GalleryChartStyleItem();
            this.chartsLayoutLabelsRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.ChartsLayoutLabelsRibbonPageGroup();
            this.chartsLayoutRibbonPage1 = new DevExpress.XtraSpreadsheet.UI.ChartsLayoutRibbonPage();
            this.spreadsheetCommandBarButtonGalleryDropDownItem11 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem();
            this.commandBarGalleryDropDown13 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.spreadsheetCommandBarSubItem29 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonGalleryDropDownItem12 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem();
            this.commandBarGalleryDropDown14 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.spreadsheetCommandBarButtonGalleryDropDownItem13 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem();
            this.commandBarGalleryDropDown15 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.spreadsheetCommandBarButtonGalleryDropDownItem14 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem();
            this.commandBarGalleryDropDown16 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.spreadsheetCommandBarButtonGalleryDropDownItem15 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem();
            this.commandBarGalleryDropDown17 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.chartsLayoutAxesRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.ChartsLayoutAxesRibbonPageGroup();
            this.spreadsheetCommandBarSubItem30 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonGalleryDropDownItem16 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem();
            this.commandBarGalleryDropDown18 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.spreadsheetCommandBarButtonGalleryDropDownItem17 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem();
            this.commandBarGalleryDropDown19 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.spreadsheetCommandBarSubItem31 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonGalleryDropDownItem18 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem();
            this.commandBarGalleryDropDown20 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.spreadsheetCommandBarButtonGalleryDropDownItem19 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem();
            this.commandBarGalleryDropDown21 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.chartsLayoutAnalysisRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.ChartsLayoutAnalysisRibbonPageGroup();
            this.spreadsheetCommandBarButtonGalleryDropDownItem20 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem();
            this.commandBarGalleryDropDown22 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.spreadsheetCommandBarButtonGalleryDropDownItem21 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem();
            this.commandBarGalleryDropDown23 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.spreadsheetCommandBarButtonGalleryDropDownItem22 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem();
            this.commandBarGalleryDropDown24 = new DevExpress.XtraBars.Commands.CommandBarGalleryDropDown(this.components);
            this.chartsFormatArrangeRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.ChartsFormatArrangeRibbonPageGroup();
            this.chartsFormatRibbonPage1 = new DevExpress.XtraSpreadsheet.UI.ChartsFormatRibbonPage();
            this.tablePropertiesRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.TablePropertiesRibbonPageGroup();
            this.tableToolsDesignRibbonPage1 = new DevExpress.XtraSpreadsheet.UI.TableToolsDesignRibbonPage();
            this.tableToolsRibbonPageCategory1 = new DevExpress.XtraSpreadsheet.UI.TableToolsRibbonPageCategory();
            this.barStaticItem1 = new DevExpress.XtraBars.BarStaticItem();
            this.renameTableItem1 = new DevExpress.XtraSpreadsheet.UI.RenameTableItem();
            this.repositoryItemTextEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.tableToolsRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.TableToolsRibbonPageGroup();
            this.spreadsheetCommandBarCheckItem27 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.tableStyleOptionsRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.TableStyleOptionsRibbonPageGroup();
            this.spreadsheetCommandBarCheckItem28 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarCheckItem29 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarCheckItem30 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarCheckItem31 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarCheckItem32 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarCheckItem33 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.tableStylesRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.TableStylesRibbonPageGroup();
            this.galleryTableStylesItem1 = new DevExpress.XtraSpreadsheet.UI.GalleryTableStylesItem();
            this.pictureFormatArrangeRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.PictureFormatArrangeRibbonPageGroup();
            this.pictureFormatRibbonPage1 = new DevExpress.XtraSpreadsheet.UI.PictureFormatRibbonPage();
            this.pictureToolsRibbonPageCategory1 = new DevExpress.XtraSpreadsheet.UI.PictureToolsRibbonPageCategory();
            this.drawingFormatArrangeRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.DrawingFormatArrangeRibbonPageGroup();
            this.drawingFormatRibbonPage1 = new DevExpress.XtraSpreadsheet.UI.DrawingFormatRibbonPage();
            this.drawingToolsRibbonPageCategory1 = new DevExpress.XtraSpreadsheet.UI.DrawingToolsRibbonPageCategory();
            this.pivotTableAnalyzePivotTableRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzePivotTableRibbonPageGroup();
            this.pivotTableAnalyzeRibbonPage1 = new DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeRibbonPage();
            this.pivotTableToolsRibbonPageCategory1 = new DevExpress.XtraSpreadsheet.UI.PivotTableToolsRibbonPageCategory();
            this.spreadsheetCommandBarButtonItem157 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.pivotTableAnalyzeActiveFieldRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeActiveFieldRibbonPageGroup();
            this.spreadsheetCommandBarButtonItem158 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem159 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem160 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.pivotTableAnalyzeDataRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeDataRibbonPageGroup();
            this.spreadsheetCommandBarSubItem32 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem161 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem162 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem163 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.pivotTableAnalyzeActionsRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeActionsRibbonPageGroup();
            this.spreadsheetCommandBarSubItem33 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem164 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem165 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarSubItem34 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem166 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem167 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem168 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem169 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.pivotTableAnalyzeShowRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeShowRibbonPageGroup();
            this.spreadsheetCommandBarCheckItem34 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarCheckItem35 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarCheckItem36 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.pivotTableDesignLayoutRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.PivotTableDesignLayoutRibbonPageGroup();
            this.pivotTableDesignRibbonPage1 = new DevExpress.XtraSpreadsheet.UI.PivotTableDesignRibbonPage();
            this.spreadsheetCommandBarSubItem35 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem170 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem171 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem172 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarSubItem36 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem173 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem174 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem175 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem176 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarSubItem37 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem177 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem178 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem179 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem180 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem181 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarSubItem38 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem();
            this.spreadsheetCommandBarButtonItem182 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.spreadsheetCommandBarButtonItem183 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem();
            this.pivotTableDesignPivotTableStyleOptionsRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.PivotTableDesignPivotTableStyleOptionsRibbonPageGroup();
            this.spreadsheetCommandBarCheckItem37 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarCheckItem38 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarCheckItem39 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.spreadsheetCommandBarCheckItem40 = new DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem();
            this.pivotTableDesignPivotTableStylesRibbonPageGroup1 = new DevExpress.XtraSpreadsheet.UI.PivotTableDesignPivotTableStylesRibbonPageGroup();
            this.galleryPivotStylesItem1 = new DevExpress.XtraSpreadsheet.UI.GalleryPivotStylesItem();
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.spreadsheetBarController1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemFontEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpreadsheetFontSizeEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPopupGalleryEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).BeginInit();
            this.SuspendLayout();
            // 
            // SpreadSheet
            // 
            this.SpreadSheet.Dock = System.Windows.Forms.DockStyle.Fill;
            this.SpreadSheet.Location = new System.Drawing.Point(0, 182);
            this.SpreadSheet.MenuManager = this.ribbonControl1;
            this.SpreadSheet.Name = "SpreadSheet";
            this.SpreadSheet.Size = new System.Drawing.Size(1221, 678);
            this.SpreadSheet.TabIndex = 0;
            this.SpreadSheet.Text = "spreadsheetControl1";
            // 
            // ribbonControl1
            // 
            this.ribbonControl1.ExpandCollapseItem.Id = 0;
            this.ribbonControl1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.ribbonControl1.ExpandCollapseItem,
            this.spreadsheetCommandBarButtonItem1,
            this.spreadsheetCommandBarButtonItem2,
            this.spreadsheetCommandBarButtonItem3,
            this.spreadsheetCommandBarButtonItem4,
            this.spreadsheetCommandBarButtonItem5,
            this.spreadsheetCommandBarButtonItem6,
            this.spreadsheetCommandBarButtonItem7,
            this.spreadsheetCommandBarButtonItem8,
            this.spreadsheetCommandBarButtonItem9,
            this.spreadsheetCommandBarButtonItem10,
            this.spreadsheetCommandBarButtonItem11,
            this.spreadsheetCommandBarButtonItem12,
            this.spreadsheetCommandBarButtonItem13,
            this.spreadsheetCommandBarButtonItem14,
            this.barButtonGroup1,
            this.changeFontNameItem1,
            this.changeFontSizeItem1,
            this.spreadsheetCommandBarButtonItem15,
            this.spreadsheetCommandBarButtonItem16,
            this.barButtonGroup2,
            this.spreadsheetCommandBarCheckItem1,
            this.spreadsheetCommandBarCheckItem2,
            this.spreadsheetCommandBarCheckItem3,
            this.spreadsheetCommandBarCheckItem4,
            this.barButtonGroup3,
            this.spreadsheetCommandBarSubItem1,
            this.spreadsheetCommandBarButtonItem17,
            this.spreadsheetCommandBarButtonItem18,
            this.spreadsheetCommandBarButtonItem19,
            this.spreadsheetCommandBarButtonItem20,
            this.spreadsheetCommandBarButtonItem21,
            this.spreadsheetCommandBarButtonItem22,
            this.spreadsheetCommandBarButtonItem23,
            this.spreadsheetCommandBarButtonItem24,
            this.spreadsheetCommandBarButtonItem25,
            this.spreadsheetCommandBarButtonItem26,
            this.spreadsheetCommandBarButtonItem27,
            this.spreadsheetCommandBarButtonItem28,
            this.spreadsheetCommandBarButtonItem29,
            this.changeBorderLineColorItem1,
            this.changeBorderLineStyleItem1,
            this.barButtonGroup4,
            this.changeCellFillColorItem1,
            this.changeFontColorItem1,
            this.barButtonGroup5,
            this.spreadsheetCommandBarCheckItem5,
            this.spreadsheetCommandBarCheckItem6,
            this.spreadsheetCommandBarCheckItem7,
            this.barButtonGroup6,
            this.spreadsheetCommandBarCheckItem8,
            this.spreadsheetCommandBarCheckItem9,
            this.spreadsheetCommandBarCheckItem10,
            this.barButtonGroup7,
            this.spreadsheetCommandBarButtonItem30,
            this.spreadsheetCommandBarButtonItem31,
            this.spreadsheetCommandBarCheckItem11,
            this.spreadsheetCommandBarSubItem2,
            this.spreadsheetCommandBarCheckItem12,
            this.spreadsheetCommandBarButtonItem32,
            this.spreadsheetCommandBarButtonItem33,
            this.spreadsheetCommandBarButtonItem34,
            this.barButtonGroup8,
            this.changeNumberFormatItem1,
            this.barButtonGroup9,
            this.spreadsheetCommandBarSubItem3,
            this.spreadsheetCommandBarButtonItem35,
            this.spreadsheetCommandBarButtonItem36,
            this.spreadsheetCommandBarButtonItem37,
            this.spreadsheetCommandBarButtonItem38,
            this.spreadsheetCommandBarButtonItem39,
            this.spreadsheetCommandBarButtonItem40,
            this.spreadsheetCommandBarButtonItem41,
            this.barButtonGroup10,
            this.spreadsheetCommandBarButtonItem42,
            this.spreadsheetCommandBarButtonItem43,
            this.spreadsheetCommandBarSubItem4,
            this.spreadsheetCommandBarButtonItem44,
            this.spreadsheetCommandBarButtonItem45,
            this.spreadsheetCommandBarButtonItem46,
            this.spreadsheetCommandBarButtonItem47,
            this.spreadsheetCommandBarButtonItem48,
            this.spreadsheetCommandBarButtonItem49,
            this.spreadsheetCommandBarButtonItem50,
            this.spreadsheetCommandBarSubItem5,
            this.spreadsheetCommandBarButtonItem51,
            this.spreadsheetCommandBarButtonItem52,
            this.spreadsheetCommandBarButtonItem53,
            this.spreadsheetCommandBarButtonItem54,
            this.spreadsheetCommandBarButtonItem55,
            this.spreadsheetCommandBarButtonItem56,
            this.spreadsheetCommandBarSubItem6,
            this.spreadsheetCommandBarButtonGalleryDropDownItem1,
            this.spreadsheetCommandBarButtonGalleryDropDownItem2,
            this.spreadsheetCommandBarButtonGalleryDropDownItem3,
            this.spreadsheetCommandBarButtonItem57,
            this.spreadsheetCommandBarButtonItem58,
            this.spreadsheetCommandBarSubItem7,
            this.galleryFormatAsTableItem1,
            this.galleryChangeStyleItem1,
            this.spreadsheetCommandBarSubItem8,
            this.spreadsheetCommandBarButtonItem59,
            this.spreadsheetCommandBarButtonItem60,
            this.spreadsheetCommandBarButtonItem61,
            this.spreadsheetCommandBarSubItem9,
            this.spreadsheetCommandBarButtonItem62,
            this.spreadsheetCommandBarButtonItem63,
            this.spreadsheetCommandBarButtonItem64,
            this.spreadsheetCommandBarSubItem10,
            this.spreadsheetCommandBarButtonItem65,
            this.spreadsheetCommandBarButtonItem66,
            this.spreadsheetCommandBarButtonItem67,
            this.spreadsheetCommandBarButtonItem68,
            this.spreadsheetCommandBarButtonItem69,
            this.spreadsheetCommandBarButtonItem70,
            this.spreadsheetCommandBarButtonItem71,
            this.spreadsheetCommandBarButtonItem72,
            this.spreadsheetCommandBarButtonItem73,
            this.spreadsheetCommandBarButtonItem74,
            this.spreadsheetCommandBarButtonItem75,
            this.spreadsheetCommandBarSubItem11,
            this.spreadsheetCommandBarButtonItem76,
            this.spreadsheetCommandBarButtonItem77,
            this.changeSheetTabColorItem1,
            this.spreadsheetCommandBarButtonItem78,
            this.spreadsheetCommandBarCheckItem13,
            this.spreadsheetCommandBarButtonItem79,
            this.spreadsheetCommandBarSubItem12,
            this.spreadsheetCommandBarButtonItem80,
            this.spreadsheetCommandBarButtonItem81,
            this.spreadsheetCommandBarButtonItem82,
            this.spreadsheetCommandBarButtonItem83,
            this.spreadsheetCommandBarButtonItem84,
            this.spreadsheetCommandBarSubItem13,
            this.spreadsheetCommandBarButtonItem85,
            this.spreadsheetCommandBarButtonItem86,
            this.spreadsheetCommandBarButtonItem87,
            this.spreadsheetCommandBarButtonItem88,
            this.spreadsheetCommandBarSubItem14,
            this.spreadsheetCommandBarButtonItem89,
            this.spreadsheetCommandBarButtonItem90,
            this.spreadsheetCommandBarButtonItem91,
            this.spreadsheetCommandBarButtonItem92,
            this.spreadsheetCommandBarButtonItem93,
            this.spreadsheetCommandBarButtonItem94,
            this.spreadsheetCommandBarSubItem15,
            this.spreadsheetCommandBarButtonItem95,
            this.spreadsheetCommandBarButtonItem96,
            this.spreadsheetCommandBarCheckItem14,
            this.spreadsheetCommandBarButtonItem97,
            this.spreadsheetCommandBarButtonItem98,
            this.spreadsheetCommandBarSubItem16,
            this.spreadsheetCommandBarButtonItem99,
            this.spreadsheetCommandBarButtonItem100,
            this.spreadsheetCommandBarButtonItem101,
            this.spreadsheetCommandBarButtonItem102,
            this.spreadsheetCommandBarButtonItem103,
            this.spreadsheetCommandBarButtonItem104,
            this.spreadsheetCommandBarButtonItem105,
            this.spreadsheetCommandBarButtonItem106,
            this.spreadsheetCommandBarButtonItem107,
            this.spreadsheetCommandBarButtonItem108,
            this.spreadsheetCommandBarButtonGalleryDropDownItem4,
            this.spreadsheetCommandBarButtonGalleryDropDownItem5,
            this.spreadsheetCommandBarButtonGalleryDropDownItem6,
            this.spreadsheetCommandBarButtonGalleryDropDownItem7,
            this.spreadsheetCommandBarButtonGalleryDropDownItem8,
            this.spreadsheetCommandBarButtonGalleryDropDownItem9,
            this.spreadsheetCommandBarButtonGalleryDropDownItem10,
            this.spreadsheetCommandBarButtonItem109,
            this.spreadsheetCommandBarButtonItem110,
            this.spreadsheetCommandBarSubItem17,
            this.spreadsheetCommandBarCheckItem15,
            this.spreadsheetCommandBarCheckItem16,
            this.spreadsheetCommandBarCheckItem17,
            this.spreadsheetCommandBarButtonItem111,
            this.spreadsheetCommandBarSubItem18,
            this.spreadsheetCommandBarCheckItem18,
            this.spreadsheetCommandBarCheckItem19,
            this.pageSetupPaperKindItem1,
            this.spreadsheetCommandBarSubItem19,
            this.spreadsheetCommandBarButtonItem112,
            this.spreadsheetCommandBarButtonItem113,
            this.spreadsheetCommandBarButtonItem114,
            this.spreadsheetCommandBarCheckItem20,
            this.spreadsheetCommandBarCheckItem21,
            this.spreadsheetCommandBarCheckItem22,
            this.spreadsheetCommandBarCheckItem23,
            this.spreadsheetCommandBarSubItem20,
            this.spreadsheetCommandBarButtonItem115,
            this.spreadsheetCommandBarButtonItem116,
            this.spreadsheetCommandBarSubItem21,
            this.spreadsheetCommandBarButtonItem117,
            this.spreadsheetCommandBarButtonItem118,
            this.spreadsheetCommandBarSubItem22,
            this.functionsFinancialItem1,
            this.functionsLogicalItem1,
            this.functionsTextItem1,
            this.functionsDateAndTimeItem1,
            this.functionsLookupAndReferenceItem1,
            this.functionsMathAndTrigonometryItem1,
            this.spreadsheetCommandBarSubItem23,
            this.functionsStatisticalItem1,
            this.functionsEngineeringItem1,
            this.functionsInformationItem1,
            this.functionsCompatibilityItem1,
            this.functionsWebItem1,
            this.spreadsheetCommandBarButtonItem124,
            this.spreadsheetCommandBarButtonItem125,
            this.definedNameListItem1,
            this.spreadsheetCommandBarButtonItem126,
            this.spreadsheetCommandBarCheckItem24,
            this.spreadsheetCommandBarSubItem24,
            this.spreadsheetCommandBarCheckItem25,
            this.spreadsheetCommandBarCheckItem26,
            this.spreadsheetCommandBarButtonItem127,
            this.spreadsheetCommandBarButtonItem128,
            this.spreadsheetCommandBarSubItem25,
            this.spreadsheetCommandBarButtonItem129,
            this.spreadsheetCommandBarButtonItem130,
            this.spreadsheetCommandBarButtonItem131,
            this.spreadsheetCommandBarSubItem26,
            this.spreadsheetCommandBarButtonItem132,
            this.spreadsheetCommandBarButtonItem133,
            this.spreadsheetCommandBarSubItem27,
            this.spreadsheetCommandBarButtonItem134,
            this.spreadsheetCommandBarButtonItem135,
            this.spreadsheetCommandBarButtonItem136,
            this.spreadsheetCommandBarButtonItem137,
            this.spreadsheetCommandBarButtonItem138,
            this.spreadsheetCommandBarButtonItem139,
            this.spreadsheetCommandBarButtonItem140,
            this.spreadsheetCommandBarButtonItem141,
            this.spreadsheetCommandBarButtonItem142,
            this.spreadsheetCommandBarButtonItem143,
            this.spreadsheetCommandBarButtonItem144,
            this.spreadsheetCommandBarButtonItem145,
            this.spreadsheetCommandBarButtonItem146,
            this.spreadsheetCommandBarButtonItem147,
            this.spreadsheetCommandBarButtonItem148,
            this.spreadsheetCommandBarButtonItem149,
            this.spreadsheetCommandBarSubItem28,
            this.spreadsheetCommandBarButtonItem150,
            this.spreadsheetCommandBarButtonItem151,
            this.spreadsheetCommandBarButtonItem152,
            this.spreadsheetCommandBarButtonItem153,
            this.spreadsheetCommandBarButtonItem154,
            this.spreadsheetCommandBarButtonItem155,
            this.spreadsheetCommandBarButtonItem156,
            this.galleryChartLayoutItem1,
            this.galleryChartStyleItem1,
            this.spreadsheetCommandBarButtonGalleryDropDownItem11,
            this.spreadsheetCommandBarSubItem29,
            this.spreadsheetCommandBarButtonGalleryDropDownItem12,
            this.spreadsheetCommandBarButtonGalleryDropDownItem13,
            this.spreadsheetCommandBarButtonGalleryDropDownItem14,
            this.spreadsheetCommandBarButtonGalleryDropDownItem15,
            this.spreadsheetCommandBarSubItem30,
            this.spreadsheetCommandBarButtonGalleryDropDownItem16,
            this.spreadsheetCommandBarButtonGalleryDropDownItem17,
            this.spreadsheetCommandBarSubItem31,
            this.spreadsheetCommandBarButtonGalleryDropDownItem18,
            this.spreadsheetCommandBarButtonGalleryDropDownItem19,
            this.spreadsheetCommandBarButtonGalleryDropDownItem20,
            this.spreadsheetCommandBarButtonGalleryDropDownItem21,
            this.spreadsheetCommandBarButtonGalleryDropDownItem22,
            this.barStaticItem1,
            this.renameTableItem1,
            this.spreadsheetCommandBarCheckItem27,
            this.spreadsheetCommandBarCheckItem28,
            this.spreadsheetCommandBarCheckItem29,
            this.spreadsheetCommandBarCheckItem30,
            this.spreadsheetCommandBarCheckItem31,
            this.spreadsheetCommandBarCheckItem32,
            this.spreadsheetCommandBarCheckItem33,
            this.galleryTableStylesItem1,
            this.spreadsheetCommandBarButtonItem157,
            this.spreadsheetCommandBarButtonItem158,
            this.spreadsheetCommandBarButtonItem159,
            this.spreadsheetCommandBarButtonItem160,
            this.spreadsheetCommandBarSubItem32,
            this.spreadsheetCommandBarButtonItem161,
            this.spreadsheetCommandBarButtonItem162,
            this.spreadsheetCommandBarButtonItem163,
            this.spreadsheetCommandBarSubItem33,
            this.spreadsheetCommandBarButtonItem164,
            this.spreadsheetCommandBarButtonItem165,
            this.spreadsheetCommandBarSubItem34,
            this.spreadsheetCommandBarButtonItem166,
            this.spreadsheetCommandBarButtonItem167,
            this.spreadsheetCommandBarButtonItem168,
            this.spreadsheetCommandBarButtonItem169,
            this.spreadsheetCommandBarCheckItem34,
            this.spreadsheetCommandBarCheckItem35,
            this.spreadsheetCommandBarCheckItem36,
            this.spreadsheetCommandBarSubItem35,
            this.spreadsheetCommandBarButtonItem170,
            this.spreadsheetCommandBarButtonItem171,
            this.spreadsheetCommandBarButtonItem172,
            this.spreadsheetCommandBarSubItem36,
            this.spreadsheetCommandBarButtonItem173,
            this.spreadsheetCommandBarButtonItem174,
            this.spreadsheetCommandBarButtonItem175,
            this.spreadsheetCommandBarButtonItem176,
            this.spreadsheetCommandBarSubItem37,
            this.spreadsheetCommandBarButtonItem177,
            this.spreadsheetCommandBarButtonItem178,
            this.spreadsheetCommandBarButtonItem179,
            this.spreadsheetCommandBarButtonItem180,
            this.spreadsheetCommandBarButtonItem181,
            this.spreadsheetCommandBarSubItem38,
            this.spreadsheetCommandBarButtonItem182,
            this.spreadsheetCommandBarButtonItem183,
            this.spreadsheetCommandBarCheckItem37,
            this.spreadsheetCommandBarCheckItem38,
            this.spreadsheetCommandBarCheckItem39,
            this.spreadsheetCommandBarCheckItem40,
            this.galleryPivotStylesItem1});
            this.ribbonControl1.Location = new System.Drawing.Point(0, 0);
            this.ribbonControl1.MaxItemId = 318;
            this.ribbonControl1.Name = "ribbonControl1";
            this.ribbonControl1.PageCategories.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageCategory[] {
            this.chartToolsRibbonPageCategory1,
            this.tableToolsRibbonPageCategory1,
            this.pictureToolsRibbonPageCategory1,
            this.drawingToolsRibbonPageCategory1,
            this.pivotTableToolsRibbonPageCategory1});
            this.ribbonControl1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.fileRibbonPage1,
            this.homeRibbonPage1,
            this.insertRibbonPage1,
            this.pageLayoutRibbonPage1,
            this.formulasRibbonPage1,
            this.dataRibbonPage1,
            this.reviewRibbonPage1,
            this.viewRibbonPage1});
            this.ribbonControl1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemFontEdit1,
            this.repositoryItemSpreadsheetFontSizeEdit1,
            this.repositoryItemPopupGalleryEdit1,
            this.repositoryItemTextEdit1});
            this.ribbonControl1.Size = new System.Drawing.Size(1221, 182);
            // 
            // spreadsheetBarController1
            // 
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem1);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem2);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem3);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem4);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem5);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem6);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem7);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem8);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem9);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem10);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem11);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem12);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem13);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem14);
            this.spreadsheetBarController1.BarItems.Add(this.changeFontNameItem1);
            this.spreadsheetBarController1.BarItems.Add(this.changeFontSizeItem1);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem15);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem16);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem1);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem2);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem3);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem4);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem1);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem17);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem18);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem19);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem20);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem21);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem22);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem23);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem24);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem25);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem26);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem27);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem28);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem29);
            this.spreadsheetBarController1.BarItems.Add(this.changeBorderLineColorItem1);
            this.spreadsheetBarController1.BarItems.Add(this.changeBorderLineStyleItem1);
            this.spreadsheetBarController1.BarItems.Add(this.changeCellFillColorItem1);
            this.spreadsheetBarController1.BarItems.Add(this.changeFontColorItem1);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem5);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem6);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem7);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem8);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem9);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem10);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem30);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem31);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem11);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem2);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem12);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem32);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem33);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem34);
            this.spreadsheetBarController1.BarItems.Add(this.changeNumberFormatItem1);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem3);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem35);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem36);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem37);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem38);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem39);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem40);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem41);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem42);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem43);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem4);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem5);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem44);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem45);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem46);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem47);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem48);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem49);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem50);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem6);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem51);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem52);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem53);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem54);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem55);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem56);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem1);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem2);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem3);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem7);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem57);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem58);
            this.spreadsheetBarController1.BarItems.Add(this.galleryFormatAsTableItem1);
            this.spreadsheetBarController1.BarItems.Add(this.galleryChangeStyleItem1);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem8);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem59);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem60);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem61);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem9);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem62);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem63);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem64);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem10);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem65);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem66);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem67);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem68);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem69);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem11);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem70);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem71);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem72);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem73);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem74);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem75);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem76);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem77);
            this.spreadsheetBarController1.BarItems.Add(this.changeSheetTabColorItem1);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem78);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem13);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem79);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem12);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem80);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem81);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem82);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem83);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem84);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem13);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem85);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem86);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem87);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem88);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem14);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem89);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem90);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem91);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem92);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem93);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem94);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem15);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem95);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem96);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem14);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem97);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem98);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem16);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem99);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem100);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem101);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem102);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem103);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem104);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem105);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem106);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem107);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem108);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem4);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem5);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem6);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem7);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem8);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem9);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem10);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem109);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem110);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem17);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem15);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem16);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem17);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem111);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem18);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem18);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem19);
            this.spreadsheetBarController1.BarItems.Add(this.pageSetupPaperKindItem1);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem19);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem112);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem113);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem114);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem20);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem21);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem22);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem23);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem20);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem115);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem116);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem21);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem117);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem118);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem22);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem119);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem120);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem121);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem122);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem123);
            this.spreadsheetBarController1.BarItems.Add(this.functionsFinancialItem1);
            this.spreadsheetBarController1.BarItems.Add(this.functionsLogicalItem1);
            this.spreadsheetBarController1.BarItems.Add(this.functionsTextItem1);
            this.spreadsheetBarController1.BarItems.Add(this.functionsDateAndTimeItem1);
            this.spreadsheetBarController1.BarItems.Add(this.functionsLookupAndReferenceItem1);
            this.spreadsheetBarController1.BarItems.Add(this.functionsMathAndTrigonometryItem1);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem23);
            this.spreadsheetBarController1.BarItems.Add(this.functionsStatisticalItem1);
            this.spreadsheetBarController1.BarItems.Add(this.functionsEngineeringItem1);
            this.spreadsheetBarController1.BarItems.Add(this.functionsInformationItem1);
            this.spreadsheetBarController1.BarItems.Add(this.functionsCompatibilityItem1);
            this.spreadsheetBarController1.BarItems.Add(this.functionsWebItem1);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem124);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem125);
            this.spreadsheetBarController1.BarItems.Add(this.definedNameListItem1);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem126);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem24);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem24);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem25);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem26);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem127);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem128);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem25);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem129);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem130);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem131);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem26);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem132);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem133);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem27);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem134);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem135);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem136);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem137);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem138);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem139);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem140);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem141);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem142);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem143);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem144);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem145);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem146);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem147);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem148);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem149);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem28);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem150);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem151);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem152);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem153);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem154);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem155);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem156);
            this.spreadsheetBarController1.BarItems.Add(this.galleryChartLayoutItem1);
            this.spreadsheetBarController1.BarItems.Add(this.galleryChartStyleItem1);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem11);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem29);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem12);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem13);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem14);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem15);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem30);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem16);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem17);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem31);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem18);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem19);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem20);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem21);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem22);
            this.spreadsheetBarController1.BarItems.Add(this.barStaticItem1);
            this.spreadsheetBarController1.BarItems.Add(this.renameTableItem1);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem27);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem28);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem29);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem30);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem31);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem32);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem33);
            this.spreadsheetBarController1.BarItems.Add(this.galleryTableStylesItem1);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem157);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem158);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem159);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem160);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem32);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem161);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem162);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem163);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem33);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem164);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem165);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem34);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem166);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem167);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem168);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem169);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem34);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem35);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem36);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem35);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem170);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem171);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem172);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem36);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem173);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem174);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem175);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem176);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem37);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem177);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem178);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem179);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem180);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem181);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarSubItem38);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem182);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarButtonItem183);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem37);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem38);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem39);
            this.spreadsheetBarController1.BarItems.Add(this.spreadsheetCommandBarCheckItem40);
            this.spreadsheetBarController1.BarItems.Add(this.galleryPivotStylesItem1);
            this.spreadsheetBarController1.Control = this.SpreadSheet;
            // 
            // commonRibbonPageGroup1
            // 
            this.commonRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem1);
            this.commonRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem2);
            this.commonRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem3);
            this.commonRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem4);
            this.commonRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem5);
            this.commonRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem6);
            this.commonRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem7);
            this.commonRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem8);
            this.commonRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem9);
            this.commonRibbonPageGroup1.Name = "commonRibbonPageGroup1";
            // 
            // fileRibbonPage1
            // 
            this.fileRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.commonRibbonPageGroup1,
            this.infoRibbonPageGroup1});
            this.fileRibbonPage1.Name = "fileRibbonPage1";
            // 
            // spreadsheetCommandBarButtonItem1
            // 
            this.spreadsheetCommandBarButtonItem1.CommandName = "FileNew";
            this.spreadsheetCommandBarButtonItem1.Id = 1;
            this.spreadsheetCommandBarButtonItem1.Name = "spreadsheetCommandBarButtonItem1";
            // 
            // spreadsheetCommandBarButtonItem2
            // 
            this.spreadsheetCommandBarButtonItem2.CommandName = "FileOpen";
            this.spreadsheetCommandBarButtonItem2.Id = 2;
            this.spreadsheetCommandBarButtonItem2.Name = "spreadsheetCommandBarButtonItem2";
            // 
            // spreadsheetCommandBarButtonItem3
            // 
            this.spreadsheetCommandBarButtonItem3.CommandName = "FileSave";
            this.spreadsheetCommandBarButtonItem3.Id = 3;
            this.spreadsheetCommandBarButtonItem3.Name = "spreadsheetCommandBarButtonItem3";
            // 
            // spreadsheetCommandBarButtonItem4
            // 
            this.spreadsheetCommandBarButtonItem4.CommandName = "FileSaveAs";
            this.spreadsheetCommandBarButtonItem4.Id = 4;
            this.spreadsheetCommandBarButtonItem4.Name = "spreadsheetCommandBarButtonItem4";
            // 
            // spreadsheetCommandBarButtonItem5
            // 
            this.spreadsheetCommandBarButtonItem5.CommandName = "FileQuickPrint";
            this.spreadsheetCommandBarButtonItem5.Id = 5;
            this.spreadsheetCommandBarButtonItem5.Name = "spreadsheetCommandBarButtonItem5";
            // 
            // spreadsheetCommandBarButtonItem6
            // 
            this.spreadsheetCommandBarButtonItem6.CommandName = "FilePrint";
            this.spreadsheetCommandBarButtonItem6.Id = 6;
            this.spreadsheetCommandBarButtonItem6.Name = "spreadsheetCommandBarButtonItem6";
            // 
            // spreadsheetCommandBarButtonItem7
            // 
            this.spreadsheetCommandBarButtonItem7.CommandName = "FilePrintPreview";
            this.spreadsheetCommandBarButtonItem7.Id = 7;
            this.spreadsheetCommandBarButtonItem7.Name = "spreadsheetCommandBarButtonItem7";
            // 
            // spreadsheetCommandBarButtonItem8
            // 
            this.spreadsheetCommandBarButtonItem8.CommandName = "FileUndo";
            this.spreadsheetCommandBarButtonItem8.Id = 8;
            this.spreadsheetCommandBarButtonItem8.Name = "spreadsheetCommandBarButtonItem8";
            // 
            // spreadsheetCommandBarButtonItem9
            // 
            this.spreadsheetCommandBarButtonItem9.CommandName = "FileRedo";
            this.spreadsheetCommandBarButtonItem9.Id = 9;
            this.spreadsheetCommandBarButtonItem9.Name = "spreadsheetCommandBarButtonItem9";
            // 
            // infoRibbonPageGroup1
            // 
            this.infoRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem10);
            this.infoRibbonPageGroup1.Name = "infoRibbonPageGroup1";
            // 
            // spreadsheetCommandBarButtonItem10
            // 
            this.spreadsheetCommandBarButtonItem10.CommandName = "FileShowDocumentProperties";
            this.spreadsheetCommandBarButtonItem10.Id = 10;
            this.spreadsheetCommandBarButtonItem10.Name = "spreadsheetCommandBarButtonItem10";
            // 
            // clipboardRibbonPageGroup1
            // 
            this.clipboardRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem11);
            this.clipboardRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem12);
            this.clipboardRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem13);
            this.clipboardRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem14);
            this.clipboardRibbonPageGroup1.Name = "clipboardRibbonPageGroup1";
            // 
            // homeRibbonPage1
            // 
            this.homeRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.clipboardRibbonPageGroup1,
            this.fontRibbonPageGroup1,
            this.alignmentRibbonPageGroup1,
            this.numberRibbonPageGroup1,
            this.stylesRibbonPageGroup1,
            this.cellsRibbonPageGroup1,
            this.editingRibbonPageGroup1});
            this.homeRibbonPage1.Name = "homeRibbonPage1";
            reduceOperation1.Behavior = DevExpress.XtraBars.Ribbon.ReduceOperationBehavior.UntilAvailable;
            reduceOperation1.Group = this.stylesRibbonPageGroup1;
            reduceOperation1.ItemLinkIndex = 2;
            reduceOperation1.ItemLinksCount = 0;
            reduceOperation1.Operation = DevExpress.XtraBars.Ribbon.ReduceOperationType.Gallery;
            this.homeRibbonPage1.ReduceOperations.Add(reduceOperation1);
            // 
            // spreadsheetCommandBarButtonItem11
            // 
            this.spreadsheetCommandBarButtonItem11.CommandName = "PasteSelection";
            this.spreadsheetCommandBarButtonItem11.Id = 21;
            this.spreadsheetCommandBarButtonItem11.Name = "spreadsheetCommandBarButtonItem11";
            this.spreadsheetCommandBarButtonItem11.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem12
            // 
            this.spreadsheetCommandBarButtonItem12.CommandName = "CutSelection";
            this.spreadsheetCommandBarButtonItem12.Id = 22;
            this.spreadsheetCommandBarButtonItem12.Name = "spreadsheetCommandBarButtonItem12";
            this.spreadsheetCommandBarButtonItem12.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // spreadsheetCommandBarButtonItem13
            // 
            this.spreadsheetCommandBarButtonItem13.CommandName = "CopySelection";
            this.spreadsheetCommandBarButtonItem13.Id = 23;
            this.spreadsheetCommandBarButtonItem13.Name = "spreadsheetCommandBarButtonItem13";
            this.spreadsheetCommandBarButtonItem13.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // spreadsheetCommandBarButtonItem14
            // 
            this.spreadsheetCommandBarButtonItem14.CommandName = "ShowPasteSpecialForm";
            this.spreadsheetCommandBarButtonItem14.Id = 24;
            this.spreadsheetCommandBarButtonItem14.Name = "spreadsheetCommandBarButtonItem14";
            this.spreadsheetCommandBarButtonItem14.RibbonStyle = ((DevExpress.XtraBars.Ribbon.RibbonItemStyles)((DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText | DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText)));
            // 
            // fontRibbonPageGroup1
            // 
            this.fontRibbonPageGroup1.ItemLinks.Add(this.barButtonGroup1);
            this.fontRibbonPageGroup1.ItemLinks.Add(this.barButtonGroup2);
            this.fontRibbonPageGroup1.ItemLinks.Add(this.barButtonGroup3);
            this.fontRibbonPageGroup1.ItemLinks.Add(this.barButtonGroup4);
            this.fontRibbonPageGroup1.Name = "fontRibbonPageGroup1";
            // 
            // changeFontNameItem1
            // 
            this.changeFontNameItem1.Edit = this.repositoryItemFontEdit1;
            this.changeFontNameItem1.EditWidth = 130;
            this.changeFontNameItem1.Id = 25;
            this.changeFontNameItem1.Name = "changeFontNameItem1";
            // 
            // changeFontSizeItem1
            // 
            this.changeFontSizeItem1.Edit = this.repositoryItemSpreadsheetFontSizeEdit1;
            this.changeFontSizeItem1.Id = 26;
            this.changeFontSizeItem1.Name = "changeFontSizeItem1";
            // 
            // spreadsheetCommandBarButtonItem15
            // 
            this.spreadsheetCommandBarButtonItem15.ButtonGroupTag = "{B0CA3FA8-82D6-4BC4-BD31-D9AE56C1D033}";
            this.spreadsheetCommandBarButtonItem15.CommandName = "FormatIncreaseFontSize";
            this.spreadsheetCommandBarButtonItem15.Id = 27;
            this.spreadsheetCommandBarButtonItem15.Name = "spreadsheetCommandBarButtonItem15";
            this.spreadsheetCommandBarButtonItem15.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarButtonItem16
            // 
            this.spreadsheetCommandBarButtonItem16.ButtonGroupTag = "{B0CA3FA8-82D6-4BC4-BD31-D9AE56C1D033}";
            this.spreadsheetCommandBarButtonItem16.CommandName = "FormatDecreaseFontSize";
            this.spreadsheetCommandBarButtonItem16.Id = 28;
            this.spreadsheetCommandBarButtonItem16.Name = "spreadsheetCommandBarButtonItem16";
            this.spreadsheetCommandBarButtonItem16.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarCheckItem1
            // 
            this.spreadsheetCommandBarCheckItem1.ButtonGroupTag = "{56C139FB-52E5-405B-A03F-FA7DCABD1D17}";
            this.spreadsheetCommandBarCheckItem1.CommandName = "FormatFontBold";
            this.spreadsheetCommandBarCheckItem1.Id = 29;
            this.spreadsheetCommandBarCheckItem1.Name = "spreadsheetCommandBarCheckItem1";
            this.spreadsheetCommandBarCheckItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarCheckItem2
            // 
            this.spreadsheetCommandBarCheckItem2.ButtonGroupTag = "{56C139FB-52E5-405B-A03F-FA7DCABD1D17}";
            this.spreadsheetCommandBarCheckItem2.CommandName = "FormatFontItalic";
            this.spreadsheetCommandBarCheckItem2.Id = 30;
            this.spreadsheetCommandBarCheckItem2.Name = "spreadsheetCommandBarCheckItem2";
            this.spreadsheetCommandBarCheckItem2.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarCheckItem3
            // 
            this.spreadsheetCommandBarCheckItem3.ButtonGroupTag = "{56C139FB-52E5-405B-A03F-FA7DCABD1D17}";
            this.spreadsheetCommandBarCheckItem3.CommandName = "FormatFontUnderline";
            this.spreadsheetCommandBarCheckItem3.Id = 31;
            this.spreadsheetCommandBarCheckItem3.Name = "spreadsheetCommandBarCheckItem3";
            this.spreadsheetCommandBarCheckItem3.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarCheckItem4
            // 
            this.spreadsheetCommandBarCheckItem4.ButtonGroupTag = "{56C139FB-52E5-405B-A03F-FA7DCABD1D17}";
            this.spreadsheetCommandBarCheckItem4.CommandName = "FormatFontStrikeout";
            this.spreadsheetCommandBarCheckItem4.Id = 32;
            this.spreadsheetCommandBarCheckItem4.Name = "spreadsheetCommandBarCheckItem4";
            this.spreadsheetCommandBarCheckItem4.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarSubItem1
            // 
            this.spreadsheetCommandBarSubItem1.ButtonGroupTag = "{DDB05A32-9207-4556-85CB-FE3403A197C7}";
            this.spreadsheetCommandBarSubItem1.CommandName = "FormatBordersCommandGroup";
            this.spreadsheetCommandBarSubItem1.Id = 33;
            this.spreadsheetCommandBarSubItem1.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem17),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem18),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem19),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem20),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem21),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem22),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem23),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem24),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem25),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem26),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem27),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem28),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem29),
            new DevExpress.XtraBars.LinkPersistInfo(this.changeBorderLineColorItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.changeBorderLineStyleItem1)});
            this.spreadsheetCommandBarSubItem1.Name = "spreadsheetCommandBarSubItem1";
            this.spreadsheetCommandBarSubItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarButtonItem17
            // 
            this.spreadsheetCommandBarButtonItem17.CommandName = "FormatBottomBorder";
            this.spreadsheetCommandBarButtonItem17.Id = 34;
            this.spreadsheetCommandBarButtonItem17.Name = "spreadsheetCommandBarButtonItem17";
            // 
            // spreadsheetCommandBarButtonItem18
            // 
            this.spreadsheetCommandBarButtonItem18.CommandName = "FormatTopBorder";
            this.spreadsheetCommandBarButtonItem18.Id = 35;
            this.spreadsheetCommandBarButtonItem18.Name = "spreadsheetCommandBarButtonItem18";
            // 
            // spreadsheetCommandBarButtonItem19
            // 
            this.spreadsheetCommandBarButtonItem19.CommandName = "FormatLeftBorder";
            this.spreadsheetCommandBarButtonItem19.Id = 36;
            this.spreadsheetCommandBarButtonItem19.Name = "spreadsheetCommandBarButtonItem19";
            // 
            // spreadsheetCommandBarButtonItem20
            // 
            this.spreadsheetCommandBarButtonItem20.CommandName = "FormatRightBorder";
            this.spreadsheetCommandBarButtonItem20.Id = 37;
            this.spreadsheetCommandBarButtonItem20.Name = "spreadsheetCommandBarButtonItem20";
            // 
            // spreadsheetCommandBarButtonItem21
            // 
            this.spreadsheetCommandBarButtonItem21.CommandName = "FormatNoBorders";
            this.spreadsheetCommandBarButtonItem21.Id = 38;
            this.spreadsheetCommandBarButtonItem21.Name = "spreadsheetCommandBarButtonItem21";
            // 
            // spreadsheetCommandBarButtonItem22
            // 
            this.spreadsheetCommandBarButtonItem22.CommandName = "FormatAllBorders";
            this.spreadsheetCommandBarButtonItem22.Id = 39;
            this.spreadsheetCommandBarButtonItem22.Name = "spreadsheetCommandBarButtonItem22";
            // 
            // spreadsheetCommandBarButtonItem23
            // 
            this.spreadsheetCommandBarButtonItem23.CommandName = "FormatOutsideBorders";
            this.spreadsheetCommandBarButtonItem23.Id = 40;
            this.spreadsheetCommandBarButtonItem23.Name = "spreadsheetCommandBarButtonItem23";
            // 
            // spreadsheetCommandBarButtonItem24
            // 
            this.spreadsheetCommandBarButtonItem24.CommandName = "FormatThickBorder";
            this.spreadsheetCommandBarButtonItem24.Id = 41;
            this.spreadsheetCommandBarButtonItem24.Name = "spreadsheetCommandBarButtonItem24";
            // 
            // spreadsheetCommandBarButtonItem25
            // 
            this.spreadsheetCommandBarButtonItem25.CommandName = "FormatBottomDoubleBorder";
            this.spreadsheetCommandBarButtonItem25.Id = 42;
            this.spreadsheetCommandBarButtonItem25.Name = "spreadsheetCommandBarButtonItem25";
            // 
            // spreadsheetCommandBarButtonItem26
            // 
            this.spreadsheetCommandBarButtonItem26.CommandName = "FormatBottomThickBorder";
            this.spreadsheetCommandBarButtonItem26.Id = 43;
            this.spreadsheetCommandBarButtonItem26.Name = "spreadsheetCommandBarButtonItem26";
            // 
            // spreadsheetCommandBarButtonItem27
            // 
            this.spreadsheetCommandBarButtonItem27.CommandName = "FormatTopAndBottomBorder";
            this.spreadsheetCommandBarButtonItem27.Id = 44;
            this.spreadsheetCommandBarButtonItem27.Name = "spreadsheetCommandBarButtonItem27";
            // 
            // spreadsheetCommandBarButtonItem28
            // 
            this.spreadsheetCommandBarButtonItem28.CommandName = "FormatTopAndThickBottomBorder";
            this.spreadsheetCommandBarButtonItem28.Id = 45;
            this.spreadsheetCommandBarButtonItem28.Name = "spreadsheetCommandBarButtonItem28";
            // 
            // spreadsheetCommandBarButtonItem29
            // 
            this.spreadsheetCommandBarButtonItem29.CommandName = "FormatTopAndDoubleBottomBorder";
            this.spreadsheetCommandBarButtonItem29.Id = 46;
            this.spreadsheetCommandBarButtonItem29.Name = "spreadsheetCommandBarButtonItem29";
            // 
            // changeBorderLineColorItem1
            // 
            this.changeBorderLineColorItem1.ActAsDropDown = true;
            this.changeBorderLineColorItem1.Id = 47;
            this.changeBorderLineColorItem1.Name = "changeBorderLineColorItem1";
            // 
            // changeBorderLineStyleItem1
            // 
            this.changeBorderLineStyleItem1.DropDownControl = this.commandBarGalleryDropDown1;
            this.changeBorderLineStyleItem1.Id = 48;
            this.changeBorderLineStyleItem1.Name = "changeBorderLineStyleItem1";
            // 
            // commandBarGalleryDropDown1
            // 
            this.commandBarGalleryDropDown1.Name = "commandBarGalleryDropDown1";
            this.commandBarGalleryDropDown1.Ribbon = this.ribbonControl1;
            // 
            // changeCellFillColorItem1
            // 
            this.changeCellFillColorItem1.Id = 49;
            this.changeCellFillColorItem1.Name = "changeCellFillColorItem1";
            // 
            // changeFontColorItem1
            // 
            this.changeFontColorItem1.Id = 50;
            this.changeFontColorItem1.Name = "changeFontColorItem1";
            // 
            // barButtonGroup1
            // 
            this.barButtonGroup1.Id = 11;
            this.barButtonGroup1.ItemLinks.Add(this.changeFontNameItem1);
            this.barButtonGroup1.ItemLinks.Add(this.changeFontSizeItem1);
            this.barButtonGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem15);
            this.barButtonGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem16);
            this.barButtonGroup1.Name = "barButtonGroup1";
            this.barButtonGroup1.Tag = "{B0CA3FA8-82D6-4BC4-BD31-D9AE56C1D033}";
            // 
            // repositoryItemFontEdit1
            // 
            this.repositoryItemFontEdit1.AutoHeight = false;
            this.repositoryItemFontEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemFontEdit1.Name = "repositoryItemFontEdit1";
            // 
            // repositoryItemSpreadsheetFontSizeEdit1
            // 
            this.repositoryItemSpreadsheetFontSizeEdit1.AutoHeight = false;
            this.repositoryItemSpreadsheetFontSizeEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemSpreadsheetFontSizeEdit1.Control = this.SpreadSheet;
            this.repositoryItemSpreadsheetFontSizeEdit1.Name = "repositoryItemSpreadsheetFontSizeEdit1";
            // 
            // barButtonGroup2
            // 
            this.barButtonGroup2.Id = 12;
            this.barButtonGroup2.ItemLinks.Add(this.spreadsheetCommandBarCheckItem1);
            this.barButtonGroup2.ItemLinks.Add(this.spreadsheetCommandBarCheckItem2);
            this.barButtonGroup2.ItemLinks.Add(this.spreadsheetCommandBarCheckItem3);
            this.barButtonGroup2.ItemLinks.Add(this.spreadsheetCommandBarCheckItem4);
            this.barButtonGroup2.Name = "barButtonGroup2";
            this.barButtonGroup2.Tag = "{56C139FB-52E5-405B-A03F-FA7DCABD1D17}";
            // 
            // barButtonGroup3
            // 
            this.barButtonGroup3.Id = 13;
            this.barButtonGroup3.ItemLinks.Add(this.spreadsheetCommandBarSubItem1);
            this.barButtonGroup3.Name = "barButtonGroup3";
            this.barButtonGroup3.Tag = "{DDB05A32-9207-4556-85CB-FE3403A197C7}";
            // 
            // barButtonGroup4
            // 
            this.barButtonGroup4.Id = 14;
            this.barButtonGroup4.ItemLinks.Add(this.changeCellFillColorItem1);
            this.barButtonGroup4.ItemLinks.Add(this.changeFontColorItem1);
            this.barButtonGroup4.Name = "barButtonGroup4";
            this.barButtonGroup4.Tag = "{C2275623-04A3-41E8-8D6A-EB5C7F8541D1}";
            // 
            // alignmentRibbonPageGroup1
            // 
            this.alignmentRibbonPageGroup1.ItemLinks.Add(this.barButtonGroup5);
            this.alignmentRibbonPageGroup1.ItemLinks.Add(this.barButtonGroup6);
            this.alignmentRibbonPageGroup1.ItemLinks.Add(this.barButtonGroup7);
            this.alignmentRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarCheckItem11);
            this.alignmentRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem2);
            this.alignmentRibbonPageGroup1.Name = "alignmentRibbonPageGroup1";
            // 
            // spreadsheetCommandBarCheckItem5
            // 
            this.spreadsheetCommandBarCheckItem5.ButtonGroupTag = "{03A0322B-12A2-4434-A487-8B5AAF64CCFC}";
            this.spreadsheetCommandBarCheckItem5.CommandName = "FormatAlignmentTop";
            this.spreadsheetCommandBarCheckItem5.Id = 51;
            this.spreadsheetCommandBarCheckItem5.Name = "spreadsheetCommandBarCheckItem5";
            this.spreadsheetCommandBarCheckItem5.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarCheckItem6
            // 
            this.spreadsheetCommandBarCheckItem6.ButtonGroupTag = "{03A0322B-12A2-4434-A487-8B5AAF64CCFC}";
            this.spreadsheetCommandBarCheckItem6.CommandName = "FormatAlignmentMiddle";
            this.spreadsheetCommandBarCheckItem6.Id = 52;
            this.spreadsheetCommandBarCheckItem6.Name = "spreadsheetCommandBarCheckItem6";
            this.spreadsheetCommandBarCheckItem6.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarCheckItem7
            // 
            this.spreadsheetCommandBarCheckItem7.ButtonGroupTag = "{03A0322B-12A2-4434-A487-8B5AAF64CCFC}";
            this.spreadsheetCommandBarCheckItem7.CommandName = "FormatAlignmentBottom";
            this.spreadsheetCommandBarCheckItem7.Id = 53;
            this.spreadsheetCommandBarCheckItem7.Name = "spreadsheetCommandBarCheckItem7";
            this.spreadsheetCommandBarCheckItem7.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarCheckItem8
            // 
            this.spreadsheetCommandBarCheckItem8.ButtonGroupTag = "{ECC693B7-EF59-4007-A0DB-A9550214A0F2}";
            this.spreadsheetCommandBarCheckItem8.CommandName = "FormatAlignmentLeft";
            this.spreadsheetCommandBarCheckItem8.Id = 54;
            this.spreadsheetCommandBarCheckItem8.Name = "spreadsheetCommandBarCheckItem8";
            this.spreadsheetCommandBarCheckItem8.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarCheckItem9
            // 
            this.spreadsheetCommandBarCheckItem9.ButtonGroupTag = "{ECC693B7-EF59-4007-A0DB-A9550214A0F2}";
            this.spreadsheetCommandBarCheckItem9.CommandName = "FormatAlignmentCenter";
            this.spreadsheetCommandBarCheckItem9.Id = 55;
            this.spreadsheetCommandBarCheckItem9.Name = "spreadsheetCommandBarCheckItem9";
            this.spreadsheetCommandBarCheckItem9.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarCheckItem10
            // 
            this.spreadsheetCommandBarCheckItem10.ButtonGroupTag = "{ECC693B7-EF59-4007-A0DB-A9550214A0F2}";
            this.spreadsheetCommandBarCheckItem10.CommandName = "FormatAlignmentRight";
            this.spreadsheetCommandBarCheckItem10.Id = 56;
            this.spreadsheetCommandBarCheckItem10.Name = "spreadsheetCommandBarCheckItem10";
            this.spreadsheetCommandBarCheckItem10.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarButtonItem30
            // 
            this.spreadsheetCommandBarButtonItem30.ButtonGroupTag = "{A5E37DED-106E-44FC-8044-CE3824C08225}";
            this.spreadsheetCommandBarButtonItem30.CommandName = "FormatDecreaseIndent";
            this.spreadsheetCommandBarButtonItem30.Id = 57;
            this.spreadsheetCommandBarButtonItem30.Name = "spreadsheetCommandBarButtonItem30";
            this.spreadsheetCommandBarButtonItem30.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarButtonItem31
            // 
            this.spreadsheetCommandBarButtonItem31.ButtonGroupTag = "{A5E37DED-106E-44FC-8044-CE3824C08225}";
            this.spreadsheetCommandBarButtonItem31.CommandName = "FormatIncreaseIndent";
            this.spreadsheetCommandBarButtonItem31.Id = 58;
            this.spreadsheetCommandBarButtonItem31.Name = "spreadsheetCommandBarButtonItem31";
            this.spreadsheetCommandBarButtonItem31.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarCheckItem11
            // 
            this.spreadsheetCommandBarCheckItem11.CommandName = "FormatWrapText";
            this.spreadsheetCommandBarCheckItem11.Id = 59;
            this.spreadsheetCommandBarCheckItem11.Name = "spreadsheetCommandBarCheckItem11";
            this.spreadsheetCommandBarCheckItem11.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // spreadsheetCommandBarSubItem2
            // 
            this.spreadsheetCommandBarSubItem2.CommandName = "EditingMergeCellsCommandGroup";
            this.spreadsheetCommandBarSubItem2.Id = 60;
            this.spreadsheetCommandBarSubItem2.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarCheckItem12),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem32),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem33),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem34)});
            this.spreadsheetCommandBarSubItem2.Name = "spreadsheetCommandBarSubItem2";
            this.spreadsheetCommandBarSubItem2.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // spreadsheetCommandBarCheckItem12
            // 
            this.spreadsheetCommandBarCheckItem12.CommandName = "EditingMergeAndCenterCells";
            this.spreadsheetCommandBarCheckItem12.Id = 61;
            this.spreadsheetCommandBarCheckItem12.Name = "spreadsheetCommandBarCheckItem12";
            // 
            // spreadsheetCommandBarButtonItem32
            // 
            this.spreadsheetCommandBarButtonItem32.CommandName = "EditingMergeCellsAcross";
            this.spreadsheetCommandBarButtonItem32.Id = 62;
            this.spreadsheetCommandBarButtonItem32.Name = "spreadsheetCommandBarButtonItem32";
            // 
            // spreadsheetCommandBarButtonItem33
            // 
            this.spreadsheetCommandBarButtonItem33.CommandName = "EditingMergeCells";
            this.spreadsheetCommandBarButtonItem33.Id = 63;
            this.spreadsheetCommandBarButtonItem33.Name = "spreadsheetCommandBarButtonItem33";
            // 
            // spreadsheetCommandBarButtonItem34
            // 
            this.spreadsheetCommandBarButtonItem34.CommandName = "EditingUnmergeCells";
            this.spreadsheetCommandBarButtonItem34.Id = 64;
            this.spreadsheetCommandBarButtonItem34.Name = "spreadsheetCommandBarButtonItem34";
            // 
            // barButtonGroup5
            // 
            this.barButtonGroup5.Id = 15;
            this.barButtonGroup5.ItemLinks.Add(this.spreadsheetCommandBarCheckItem5);
            this.barButtonGroup5.ItemLinks.Add(this.spreadsheetCommandBarCheckItem6);
            this.barButtonGroup5.ItemLinks.Add(this.spreadsheetCommandBarCheckItem7);
            this.barButtonGroup5.Name = "barButtonGroup5";
            this.barButtonGroup5.Tag = "{03A0322B-12A2-4434-A487-8B5AAF64CCFC}";
            // 
            // barButtonGroup6
            // 
            this.barButtonGroup6.Id = 16;
            this.barButtonGroup6.ItemLinks.Add(this.spreadsheetCommandBarCheckItem8);
            this.barButtonGroup6.ItemLinks.Add(this.spreadsheetCommandBarCheckItem9);
            this.barButtonGroup6.ItemLinks.Add(this.spreadsheetCommandBarCheckItem10);
            this.barButtonGroup6.Name = "barButtonGroup6";
            this.barButtonGroup6.Tag = "{ECC693B7-EF59-4007-A0DB-A9550214A0F2}";
            // 
            // barButtonGroup7
            // 
            this.barButtonGroup7.Id = 17;
            this.barButtonGroup7.ItemLinks.Add(this.spreadsheetCommandBarButtonItem30);
            this.barButtonGroup7.ItemLinks.Add(this.spreadsheetCommandBarButtonItem31);
            this.barButtonGroup7.Name = "barButtonGroup7";
            this.barButtonGroup7.Tag = "{A5E37DED-106E-44FC-8044-CE3824C08225}";
            // 
            // numberRibbonPageGroup1
            // 
            this.numberRibbonPageGroup1.ItemLinks.Add(this.barButtonGroup8);
            this.numberRibbonPageGroup1.ItemLinks.Add(this.barButtonGroup9);
            this.numberRibbonPageGroup1.ItemLinks.Add(this.barButtonGroup10);
            this.numberRibbonPageGroup1.Name = "numberRibbonPageGroup1";
            // 
            // changeNumberFormatItem1
            // 
            this.changeNumberFormatItem1.Edit = this.repositoryItemPopupGalleryEdit1;
            this.changeNumberFormatItem1.EditWidth = 130;
            this.changeNumberFormatItem1.Id = 65;
            this.changeNumberFormatItem1.Name = "changeNumberFormatItem1";
            // 
            // spreadsheetCommandBarSubItem3
            // 
            this.spreadsheetCommandBarSubItem3.ButtonGroupTag = "{508C2CE6-E1C8-4DD1-BA50-6C210FDB31B0}";
            this.spreadsheetCommandBarSubItem3.CommandName = "FormatNumberAccountingCommandGroup";
            this.spreadsheetCommandBarSubItem3.Id = 66;
            this.spreadsheetCommandBarSubItem3.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem35),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem36),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem37),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem38),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem39)});
            this.spreadsheetCommandBarSubItem3.Name = "spreadsheetCommandBarSubItem3";
            this.spreadsheetCommandBarSubItem3.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarButtonItem35
            // 
            this.spreadsheetCommandBarButtonItem35.CommandName = "FormatNumberAccountingUS";
            this.spreadsheetCommandBarButtonItem35.Id = 67;
            this.spreadsheetCommandBarButtonItem35.Name = "spreadsheetCommandBarButtonItem35";
            // 
            // spreadsheetCommandBarButtonItem36
            // 
            this.spreadsheetCommandBarButtonItem36.CommandName = "FormatNumberAccountingUK";
            this.spreadsheetCommandBarButtonItem36.Id = 68;
            this.spreadsheetCommandBarButtonItem36.Name = "spreadsheetCommandBarButtonItem36";
            // 
            // spreadsheetCommandBarButtonItem37
            // 
            this.spreadsheetCommandBarButtonItem37.CommandName = "FormatNumberAccountingEuro";
            this.spreadsheetCommandBarButtonItem37.Id = 69;
            this.spreadsheetCommandBarButtonItem37.Name = "spreadsheetCommandBarButtonItem37";
            // 
            // spreadsheetCommandBarButtonItem38
            // 
            this.spreadsheetCommandBarButtonItem38.CommandName = "FormatNumberAccountingPRC";
            this.spreadsheetCommandBarButtonItem38.Id = 70;
            this.spreadsheetCommandBarButtonItem38.Name = "spreadsheetCommandBarButtonItem38";
            // 
            // spreadsheetCommandBarButtonItem39
            // 
            this.spreadsheetCommandBarButtonItem39.CommandName = "FormatNumberAccountingSwiss";
            this.spreadsheetCommandBarButtonItem39.Id = 71;
            this.spreadsheetCommandBarButtonItem39.Name = "spreadsheetCommandBarButtonItem39";
            // 
            // spreadsheetCommandBarButtonItem40
            // 
            this.spreadsheetCommandBarButtonItem40.ButtonGroupTag = "{508C2CE6-E1C8-4DD1-BA50-6C210FDB31B0}";
            this.spreadsheetCommandBarButtonItem40.CommandName = "FormatNumberPercent";
            this.spreadsheetCommandBarButtonItem40.Id = 72;
            this.spreadsheetCommandBarButtonItem40.Name = "spreadsheetCommandBarButtonItem40";
            this.spreadsheetCommandBarButtonItem40.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarButtonItem41
            // 
            this.spreadsheetCommandBarButtonItem41.ButtonGroupTag = "{508C2CE6-E1C8-4DD1-BA50-6C210FDB31B0}";
            this.spreadsheetCommandBarButtonItem41.CommandName = "FormatNumberAccounting";
            this.spreadsheetCommandBarButtonItem41.Id = 73;
            this.spreadsheetCommandBarButtonItem41.Name = "spreadsheetCommandBarButtonItem41";
            this.spreadsheetCommandBarButtonItem41.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarButtonItem42
            // 
            this.spreadsheetCommandBarButtonItem42.ButtonGroupTag = "{BBAB348B-BDB2-487A-A883-EFB9982DC698}";
            this.spreadsheetCommandBarButtonItem42.CommandName = "FormatNumberIncreaseDecimal";
            this.spreadsheetCommandBarButtonItem42.Id = 74;
            this.spreadsheetCommandBarButtonItem42.Name = "spreadsheetCommandBarButtonItem42";
            this.spreadsheetCommandBarButtonItem42.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // spreadsheetCommandBarButtonItem43
            // 
            this.spreadsheetCommandBarButtonItem43.ButtonGroupTag = "{BBAB348B-BDB2-487A-A883-EFB9982DC698}";
            this.spreadsheetCommandBarButtonItem43.CommandName = "FormatNumberDecreaseDecimal";
            this.spreadsheetCommandBarButtonItem43.Id = 75;
            this.spreadsheetCommandBarButtonItem43.Name = "spreadsheetCommandBarButtonItem43";
            this.spreadsheetCommandBarButtonItem43.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            // 
            // barButtonGroup8
            // 
            this.barButtonGroup8.Id = 18;
            this.barButtonGroup8.ItemLinks.Add(this.changeNumberFormatItem1);
            this.barButtonGroup8.Name = "barButtonGroup8";
            this.barButtonGroup8.Tag = "{0B3A7A43-3079-4ce0-83A8-3789F5F6DC9F}";
            // 
            // repositoryItemPopupGalleryEdit1
            // 
            this.repositoryItemPopupGalleryEdit1.AutoHeight = false;
            this.repositoryItemPopupGalleryEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            // 
            // 
            // 
            this.repositoryItemPopupGalleryEdit1.Gallery.AllowFilter = false;
            this.repositoryItemPopupGalleryEdit1.Gallery.AutoFitColumns = false;
            this.repositoryItemPopupGalleryEdit1.Gallery.ColumnCount = 1;
            this.repositoryItemPopupGalleryEdit1.Gallery.FixedImageSize = false;
            spreadsheetCommandGalleryItem1.AlwaysUpdateDescription = true;
            spreadsheetCommandGalleryItem1.CaptionAsValue = true;
            spreadsheetCommandGalleryItem1.CommandName = "FormatNumberGeneral";
            spreadsheetCommandGalleryItem1.IsEmptyHint = true;
            spreadsheetCommandGalleryItem2.AlwaysUpdateDescription = true;
            spreadsheetCommandGalleryItem2.CaptionAsValue = true;
            spreadsheetCommandGalleryItem2.CommandName = "FormatNumberDecimal";
            spreadsheetCommandGalleryItem2.IsEmptyHint = true;
            spreadsheetCommandGalleryItem3.AlwaysUpdateDescription = true;
            spreadsheetCommandGalleryItem3.CaptionAsValue = true;
            spreadsheetCommandGalleryItem3.CommandName = "FormatNumberAccountingCurrency";
            spreadsheetCommandGalleryItem3.IsEmptyHint = true;
            spreadsheetCommandGalleryItem4.AlwaysUpdateDescription = true;
            spreadsheetCommandGalleryItem4.CaptionAsValue = true;
            spreadsheetCommandGalleryItem4.CommandName = "FormatNumberAccountingRegular";
            spreadsheetCommandGalleryItem4.IsEmptyHint = true;
            spreadsheetCommandGalleryItem5.AlwaysUpdateDescription = true;
            spreadsheetCommandGalleryItem5.CaptionAsValue = true;
            spreadsheetCommandGalleryItem5.CommandName = "FormatNumberShortDate";
            spreadsheetCommandGalleryItem5.IsEmptyHint = true;
            spreadsheetCommandGalleryItem6.AlwaysUpdateDescription = true;
            spreadsheetCommandGalleryItem6.CaptionAsValue = true;
            spreadsheetCommandGalleryItem6.CommandName = "FormatNumberLongDate";
            spreadsheetCommandGalleryItem6.IsEmptyHint = true;
            spreadsheetCommandGalleryItem7.AlwaysUpdateDescription = true;
            spreadsheetCommandGalleryItem7.CaptionAsValue = true;
            spreadsheetCommandGalleryItem7.CommandName = "FormatNumberTime";
            spreadsheetCommandGalleryItem7.IsEmptyHint = true;
            spreadsheetCommandGalleryItem8.AlwaysUpdateDescription = true;
            spreadsheetCommandGalleryItem8.CaptionAsValue = true;
            spreadsheetCommandGalleryItem8.CommandName = "FormatNumberPercentage";
            spreadsheetCommandGalleryItem8.IsEmptyHint = true;
            spreadsheetCommandGalleryItem9.AlwaysUpdateDescription = true;
            spreadsheetCommandGalleryItem9.CaptionAsValue = true;
            spreadsheetCommandGalleryItem9.CommandName = "FormatNumberFraction";
            spreadsheetCommandGalleryItem9.IsEmptyHint = true;
            spreadsheetCommandGalleryItem10.AlwaysUpdateDescription = true;
            spreadsheetCommandGalleryItem10.CaptionAsValue = true;
            spreadsheetCommandGalleryItem10.CommandName = "FormatNumberScientific";
            spreadsheetCommandGalleryItem10.IsEmptyHint = true;
            spreadsheetCommandGalleryItem11.AlwaysUpdateDescription = true;
            spreadsheetCommandGalleryItem11.CaptionAsValue = true;
            spreadsheetCommandGalleryItem11.CommandName = "FormatNumberText";
            spreadsheetCommandGalleryItem11.IsEmptyHint = true;
            galleryItemGroup1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem1,
            spreadsheetCommandGalleryItem2,
            spreadsheetCommandGalleryItem3,
            spreadsheetCommandGalleryItem4,
            spreadsheetCommandGalleryItem5,
            spreadsheetCommandGalleryItem6,
            spreadsheetCommandGalleryItem7,
            spreadsheetCommandGalleryItem8,
            spreadsheetCommandGalleryItem9,
            spreadsheetCommandGalleryItem10,
            spreadsheetCommandGalleryItem11});
            this.repositoryItemPopupGalleryEdit1.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            galleryItemGroup1});
            this.repositoryItemPopupGalleryEdit1.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft;
            this.repositoryItemPopupGalleryEdit1.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left;
            this.repositoryItemPopupGalleryEdit1.Gallery.RowCount = 11;
            this.repositoryItemPopupGalleryEdit1.Gallery.ShowGroupCaption = false;
            this.repositoryItemPopupGalleryEdit1.Gallery.ShowItemText = true;
            this.repositoryItemPopupGalleryEdit1.Gallery.ShowScrollBar = DevExpress.XtraBars.Ribbon.Gallery.ShowScrollBar.Hide;
            this.repositoryItemPopupGalleryEdit1.Gallery.StretchItems = true;
            this.repositoryItemPopupGalleryEdit1.Name = "repositoryItemPopupGalleryEdit1";
            this.repositoryItemPopupGalleryEdit1.ShowButtons = false;
            this.repositoryItemPopupGalleryEdit1.ShowPopupCloseButton = false;
            this.repositoryItemPopupGalleryEdit1.ShowSizeGrip = false;
            // 
            // barButtonGroup9
            // 
            this.barButtonGroup9.Id = 19;
            this.barButtonGroup9.ItemLinks.Add(this.spreadsheetCommandBarSubItem3);
            this.barButtonGroup9.ItemLinks.Add(this.spreadsheetCommandBarButtonItem40);
            this.barButtonGroup9.ItemLinks.Add(this.spreadsheetCommandBarButtonItem41);
            this.barButtonGroup9.Name = "barButtonGroup9";
            this.barButtonGroup9.Tag = "{508C2CE6-E1C8-4DD1-BA50-6C210FDB31B0}";
            // 
            // barButtonGroup10
            // 
            this.barButtonGroup10.Id = 20;
            this.barButtonGroup10.ItemLinks.Add(this.spreadsheetCommandBarButtonItem42);
            this.barButtonGroup10.ItemLinks.Add(this.spreadsheetCommandBarButtonItem43);
            this.barButtonGroup10.Name = "barButtonGroup10";
            this.barButtonGroup10.Tag = "{BBAB348B-BDB2-487A-A883-EFB9982DC698}";
            // 
            // stylesRibbonPageGroup1
            // 
            this.stylesRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem4);
            this.stylesRibbonPageGroup1.ItemLinks.Add(this.galleryFormatAsTableItem1);
            this.stylesRibbonPageGroup1.ItemLinks.Add(this.galleryChangeStyleItem1);
            this.stylesRibbonPageGroup1.Name = "stylesRibbonPageGroup1";
            // 
            // spreadsheetCommandBarSubItem4
            // 
            this.spreadsheetCommandBarSubItem4.CommandName = "ConditionalFormattingCommandGroup";
            this.spreadsheetCommandBarSubItem4.Id = 76;
            this.spreadsheetCommandBarSubItem4.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarSubItem5),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarSubItem6),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonGalleryDropDownItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonGalleryDropDownItem2),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonGalleryDropDownItem3),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarSubItem7)});
            this.spreadsheetCommandBarSubItem4.Name = "spreadsheetCommandBarSubItem4";
            // 
            // spreadsheetCommandBarSubItem5
            // 
            this.spreadsheetCommandBarSubItem5.CommandName = "ConditionalFormattingHighlightCellsRuleCommandGroup";
            this.spreadsheetCommandBarSubItem5.Id = 84;
            this.spreadsheetCommandBarSubItem5.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem44),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem45),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem46),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem47),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem48),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem49),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem50)});
            this.spreadsheetCommandBarSubItem5.Name = "spreadsheetCommandBarSubItem5";
            // 
            // spreadsheetCommandBarButtonItem44
            // 
            this.spreadsheetCommandBarButtonItem44.CommandName = "ConditionalFormattingGreaterThanRuleCommand";
            this.spreadsheetCommandBarButtonItem44.Id = 77;
            this.spreadsheetCommandBarButtonItem44.Name = "spreadsheetCommandBarButtonItem44";
            this.spreadsheetCommandBarButtonItem44.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem45
            // 
            this.spreadsheetCommandBarButtonItem45.CommandName = "ConditionalFormattingLessThanRuleCommand";
            this.spreadsheetCommandBarButtonItem45.Id = 78;
            this.spreadsheetCommandBarButtonItem45.Name = "spreadsheetCommandBarButtonItem45";
            this.spreadsheetCommandBarButtonItem45.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem46
            // 
            this.spreadsheetCommandBarButtonItem46.CommandName = "ConditionalFormattingBetweenRuleCommand";
            this.spreadsheetCommandBarButtonItem46.Id = 79;
            this.spreadsheetCommandBarButtonItem46.Name = "spreadsheetCommandBarButtonItem46";
            this.spreadsheetCommandBarButtonItem46.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem47
            // 
            this.spreadsheetCommandBarButtonItem47.CommandName = "ConditionalFormattingEqualToRuleCommand";
            this.spreadsheetCommandBarButtonItem47.Id = 80;
            this.spreadsheetCommandBarButtonItem47.Name = "spreadsheetCommandBarButtonItem47";
            this.spreadsheetCommandBarButtonItem47.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem48
            // 
            this.spreadsheetCommandBarButtonItem48.CommandName = "ConditionalFormattingTextContainsRuleCommand";
            this.spreadsheetCommandBarButtonItem48.Id = 81;
            this.spreadsheetCommandBarButtonItem48.Name = "spreadsheetCommandBarButtonItem48";
            this.spreadsheetCommandBarButtonItem48.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem49
            // 
            this.spreadsheetCommandBarButtonItem49.CommandName = "ConditionalFormattingDateOccurringRuleCommand";
            this.spreadsheetCommandBarButtonItem49.Id = 82;
            this.spreadsheetCommandBarButtonItem49.Name = "spreadsheetCommandBarButtonItem49";
            this.spreadsheetCommandBarButtonItem49.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem50
            // 
            this.spreadsheetCommandBarButtonItem50.CommandName = "ConditionalFormattingDuplicateValuesRuleCommand";
            this.spreadsheetCommandBarButtonItem50.Id = 83;
            this.spreadsheetCommandBarButtonItem50.Name = "spreadsheetCommandBarButtonItem50";
            this.spreadsheetCommandBarButtonItem50.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarSubItem6
            // 
            this.spreadsheetCommandBarSubItem6.CommandName = "ConditionalFormattingTopBottomRuleCommandGroup";
            this.spreadsheetCommandBarSubItem6.Id = 91;
            this.spreadsheetCommandBarSubItem6.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem51),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem52),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem53),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem54),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem55),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem56)});
            this.spreadsheetCommandBarSubItem6.Name = "spreadsheetCommandBarSubItem6";
            // 
            // spreadsheetCommandBarButtonItem51
            // 
            this.spreadsheetCommandBarButtonItem51.CommandName = "ConditionalFormattingTop10RuleCommand";
            this.spreadsheetCommandBarButtonItem51.Id = 85;
            this.spreadsheetCommandBarButtonItem51.Name = "spreadsheetCommandBarButtonItem51";
            this.spreadsheetCommandBarButtonItem51.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem52
            // 
            this.spreadsheetCommandBarButtonItem52.CommandName = "ConditionalFormattingTop10PercentRuleCommand";
            this.spreadsheetCommandBarButtonItem52.Id = 86;
            this.spreadsheetCommandBarButtonItem52.Name = "spreadsheetCommandBarButtonItem52";
            this.spreadsheetCommandBarButtonItem52.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem53
            // 
            this.spreadsheetCommandBarButtonItem53.CommandName = "ConditionalFormattingBottom10RuleCommand";
            this.spreadsheetCommandBarButtonItem53.Id = 87;
            this.spreadsheetCommandBarButtonItem53.Name = "spreadsheetCommandBarButtonItem53";
            this.spreadsheetCommandBarButtonItem53.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem54
            // 
            this.spreadsheetCommandBarButtonItem54.CommandName = "ConditionalFormattingBottom10PercentRuleCommand";
            this.spreadsheetCommandBarButtonItem54.Id = 88;
            this.spreadsheetCommandBarButtonItem54.Name = "spreadsheetCommandBarButtonItem54";
            this.spreadsheetCommandBarButtonItem54.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem55
            // 
            this.spreadsheetCommandBarButtonItem55.CommandName = "ConditionalFormattingAboveAverageRuleCommand";
            this.spreadsheetCommandBarButtonItem55.Id = 89;
            this.spreadsheetCommandBarButtonItem55.Name = "spreadsheetCommandBarButtonItem55";
            this.spreadsheetCommandBarButtonItem55.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem56
            // 
            this.spreadsheetCommandBarButtonItem56.CommandName = "ConditionalFormattingBelowAverageRuleCommand";
            this.spreadsheetCommandBarButtonItem56.Id = 90;
            this.spreadsheetCommandBarButtonItem56.Name = "spreadsheetCommandBarButtonItem56";
            this.spreadsheetCommandBarButtonItem56.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonGalleryDropDownItem1
            // 
            this.spreadsheetCommandBarButtonGalleryDropDownItem1.CommandName = "ConditionalFormattingDataBarsCommandGroup";
            this.spreadsheetCommandBarButtonGalleryDropDownItem1.DropDownControl = this.commandBarGalleryDropDown2;
            this.spreadsheetCommandBarButtonGalleryDropDownItem1.Id = 92;
            this.spreadsheetCommandBarButtonGalleryDropDownItem1.Name = "spreadsheetCommandBarButtonGalleryDropDownItem1";
            this.spreadsheetCommandBarButtonGalleryDropDownItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // commandBarGalleryDropDown2
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown2.Gallery.ColumnCount = 3;
            spreadsheetCommandGalleryItemGroup1.CommandName = "ConditionalFormattingDataBarsGradientFillCommandGroup";
            spreadsheetCommandGalleryItem12.CommandName = "ConditionalFormattingDataBarGradientBlue";
            spreadsheetCommandGalleryItem13.CommandName = "ConditionalFormattingDataBarGradientGreen";
            spreadsheetCommandGalleryItem14.CommandName = "ConditionalFormattingDataBarGradientRed";
            spreadsheetCommandGalleryItem15.CommandName = "ConditionalFormattingDataBarGradientOrange";
            spreadsheetCommandGalleryItem16.CommandName = "ConditionalFormattingDataBarGradientLightBlue";
            spreadsheetCommandGalleryItem17.CommandName = "ConditionalFormattingDataBarGradientPurple";
            spreadsheetCommandGalleryItemGroup1.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem12,
            spreadsheetCommandGalleryItem13,
            spreadsheetCommandGalleryItem14,
            spreadsheetCommandGalleryItem15,
            spreadsheetCommandGalleryItem16,
            spreadsheetCommandGalleryItem17});
            spreadsheetCommandGalleryItemGroup2.CommandName = "ConditionalFormattingDataBarsSolidFillCommandGroup";
            spreadsheetCommandGalleryItem18.CommandName = "ConditionalFormattingDataBarSolidBlue";
            spreadsheetCommandGalleryItem19.CommandName = "ConditionalFormattingDataBarSolidGreen";
            spreadsheetCommandGalleryItem20.CommandName = "ConditionalFormattingDataBarSolidRed";
            spreadsheetCommandGalleryItem21.CommandName = "ConditionalFormattingDataBarSolidOrange";
            spreadsheetCommandGalleryItem22.CommandName = "ConditionalFormattingDataBarSolidLightBlue";
            spreadsheetCommandGalleryItem23.CommandName = "ConditionalFormattingDataBarSolidPurple";
            spreadsheetCommandGalleryItemGroup2.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem18,
            spreadsheetCommandGalleryItem19,
            spreadsheetCommandGalleryItem20,
            spreadsheetCommandGalleryItem21,
            spreadsheetCommandGalleryItem22,
            spreadsheetCommandGalleryItem23});
            this.commandBarGalleryDropDown2.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            spreadsheetCommandGalleryItemGroup1,
            spreadsheetCommandGalleryItemGroup2});
            this.commandBarGalleryDropDown2.Gallery.RowCount = 4;
            this.commandBarGalleryDropDown2.Name = "commandBarGalleryDropDown2";
            this.commandBarGalleryDropDown2.Ribbon = this.ribbonControl1;
            // 
            // spreadsheetCommandBarButtonGalleryDropDownItem2
            // 
            this.spreadsheetCommandBarButtonGalleryDropDownItem2.CommandName = "ConditionalFormattingColorScalesCommandGroup";
            this.spreadsheetCommandBarButtonGalleryDropDownItem2.DropDownControl = this.commandBarGalleryDropDown3;
            this.spreadsheetCommandBarButtonGalleryDropDownItem2.Id = 93;
            this.spreadsheetCommandBarButtonGalleryDropDownItem2.Name = "spreadsheetCommandBarButtonGalleryDropDownItem2";
            this.spreadsheetCommandBarButtonGalleryDropDownItem2.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // commandBarGalleryDropDown3
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown3.Gallery.ColumnCount = 4;
            spreadsheetCommandGalleryItemGroup3.CommandName = "ConditionalFormattingColorScalesCommandGroup";
            spreadsheetCommandGalleryItem24.CommandName = "ConditionalFormattingColorScaleGreenYellowRed";
            spreadsheetCommandGalleryItem25.CommandName = "ConditionalFormattingColorScaleRedYellowGreen";
            spreadsheetCommandGalleryItem26.CommandName = "ConditionalFormattingColorScaleGreenWhiteRed";
            spreadsheetCommandGalleryItem27.CommandName = "ConditionalFormattingColorScaleRedWhiteGreen";
            spreadsheetCommandGalleryItem28.CommandName = "ConditionalFormattingColorScaleBlueWhiteRed";
            spreadsheetCommandGalleryItem29.CommandName = "ConditionalFormattingColorScaleRedWhiteBlue";
            spreadsheetCommandGalleryItem30.CommandName = "ConditionalFormattingColorScaleWhiteRed";
            spreadsheetCommandGalleryItem31.CommandName = "ConditionalFormattingColorScaleRedWhite";
            spreadsheetCommandGalleryItem32.CommandName = "ConditionalFormattingColorScaleGreenWhite";
            spreadsheetCommandGalleryItem33.CommandName = "ConditionalFormattingColorScaleWhiteGreen";
            spreadsheetCommandGalleryItem34.CommandName = "ConditionalFormattingColorScaleGreenYellow";
            spreadsheetCommandGalleryItem35.CommandName = "ConditionalFormattingColorScaleYellowGreen";
            spreadsheetCommandGalleryItemGroup3.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem24,
            spreadsheetCommandGalleryItem25,
            spreadsheetCommandGalleryItem26,
            spreadsheetCommandGalleryItem27,
            spreadsheetCommandGalleryItem28,
            spreadsheetCommandGalleryItem29,
            spreadsheetCommandGalleryItem30,
            spreadsheetCommandGalleryItem31,
            spreadsheetCommandGalleryItem32,
            spreadsheetCommandGalleryItem33,
            spreadsheetCommandGalleryItem34,
            spreadsheetCommandGalleryItem35});
            this.commandBarGalleryDropDown3.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            spreadsheetCommandGalleryItemGroup3});
            this.commandBarGalleryDropDown3.Gallery.ShowGroupCaption = false;
            this.commandBarGalleryDropDown3.Name = "commandBarGalleryDropDown3";
            this.commandBarGalleryDropDown3.Ribbon = this.ribbonControl1;
            // 
            // spreadsheetCommandBarButtonGalleryDropDownItem3
            // 
            this.spreadsheetCommandBarButtonGalleryDropDownItem3.CommandName = "ConditionalFormattingIconSetsCommandGroup";
            this.spreadsheetCommandBarButtonGalleryDropDownItem3.DropDownControl = this.commandBarGalleryDropDown4;
            this.spreadsheetCommandBarButtonGalleryDropDownItem3.Id = 94;
            this.spreadsheetCommandBarButtonGalleryDropDownItem3.Name = "spreadsheetCommandBarButtonGalleryDropDownItem3";
            this.spreadsheetCommandBarButtonGalleryDropDownItem3.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // commandBarGalleryDropDown4
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown4.Gallery.ColumnCount = 4;
            spreadsheetCommandGalleryItemGroup4.CommandName = "ConditionalFormattingIconSetsDirectionalCommandGroup";
            spreadsheetCommandGalleryItem36.CommandName = "ConditionalFormattingIconSetArrows3Colored";
            spreadsheetCommandGalleryItem37.CommandName = "ConditionalFormattingIconSetArrows3Grayed";
            spreadsheetCommandGalleryItem38.CommandName = "ConditionalFormattingIconSetArrows4Colored";
            spreadsheetCommandGalleryItem39.CommandName = "ConditionalFormattingIconSetArrows4Grayed";
            spreadsheetCommandGalleryItem40.CommandName = "ConditionalFormattingIconSetArrows5Colored";
            spreadsheetCommandGalleryItem41.CommandName = "ConditionalFormattingIconSetArrows5Grayed";
            spreadsheetCommandGalleryItem42.CommandName = "ConditionalFormattingIconSetTriangles3";
            spreadsheetCommandGalleryItemGroup4.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem36,
            spreadsheetCommandGalleryItem37,
            spreadsheetCommandGalleryItem38,
            spreadsheetCommandGalleryItem39,
            spreadsheetCommandGalleryItem40,
            spreadsheetCommandGalleryItem41,
            spreadsheetCommandGalleryItem42});
            spreadsheetCommandGalleryItemGroup5.CommandName = "ConditionalFormattingIconSetsShapesCommandGroup";
            spreadsheetCommandGalleryItem43.CommandName = "ConditionalFormattingIconSetTrafficLights3";
            spreadsheetCommandGalleryItem44.CommandName = "ConditionalFormattingIconSetTrafficLights3Rimmed";
            spreadsheetCommandGalleryItem45.CommandName = "ConditionalFormattingIconSetTrafficLights4";
            spreadsheetCommandGalleryItem46.CommandName = "ConditionalFormattingIconSetSigns3";
            spreadsheetCommandGalleryItem47.CommandName = "ConditionalFormattingIconSetRedToBlack";
            spreadsheetCommandGalleryItemGroup5.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem43,
            spreadsheetCommandGalleryItem44,
            spreadsheetCommandGalleryItem45,
            spreadsheetCommandGalleryItem46,
            spreadsheetCommandGalleryItem47});
            spreadsheetCommandGalleryItemGroup6.CommandName = "ConditionalFormattingIconSetsIndicatorsCommandGroup";
            spreadsheetCommandGalleryItem48.CommandName = "ConditionalFormattingIconSetSymbols3Circled";
            spreadsheetCommandGalleryItem49.CommandName = "ConditionalFormattingIconSetSymbols3";
            spreadsheetCommandGalleryItem50.CommandName = "ConditionalFormattingIconSetFlags3";
            spreadsheetCommandGalleryItemGroup6.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem48,
            spreadsheetCommandGalleryItem49,
            spreadsheetCommandGalleryItem50});
            spreadsheetCommandGalleryItemGroup7.CommandName = "ConditionalFormattingIconSetsRatingsCommandGroup";
            spreadsheetCommandGalleryItem51.CommandName = "ConditionalFormattingIconSetStars3";
            spreadsheetCommandGalleryItem52.CommandName = "ConditionalFormattingIconSetRatings4";
            spreadsheetCommandGalleryItem53.CommandName = "ConditionalFormattingIconSetRatings5";
            spreadsheetCommandGalleryItem54.CommandName = "ConditionalFormattingIconSetQuarters5";
            spreadsheetCommandGalleryItem55.CommandName = "ConditionalFormattingIconSetBoxes5";
            spreadsheetCommandGalleryItemGroup7.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem51,
            spreadsheetCommandGalleryItem52,
            spreadsheetCommandGalleryItem53,
            spreadsheetCommandGalleryItem54,
            spreadsheetCommandGalleryItem55});
            this.commandBarGalleryDropDown4.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            spreadsheetCommandGalleryItemGroup4,
            spreadsheetCommandGalleryItemGroup5,
            spreadsheetCommandGalleryItemGroup6,
            spreadsheetCommandGalleryItemGroup7});
            this.commandBarGalleryDropDown4.Gallery.RowCount = 7;
            this.commandBarGalleryDropDown4.Name = "commandBarGalleryDropDown4";
            this.commandBarGalleryDropDown4.Ribbon = this.ribbonControl1;
            // 
            // spreadsheetCommandBarSubItem7
            // 
            this.spreadsheetCommandBarSubItem7.CommandName = "ConditionalFormattingRemoveCommandGroup";
            this.spreadsheetCommandBarSubItem7.Id = 97;
            this.spreadsheetCommandBarSubItem7.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem57),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem58)});
            this.spreadsheetCommandBarSubItem7.Name = "spreadsheetCommandBarSubItem7";
            // 
            // spreadsheetCommandBarButtonItem57
            // 
            this.spreadsheetCommandBarButtonItem57.CommandName = "ConditionalFormattingRemoveFromSheet";
            this.spreadsheetCommandBarButtonItem57.Id = 95;
            this.spreadsheetCommandBarButtonItem57.Name = "spreadsheetCommandBarButtonItem57";
            // 
            // spreadsheetCommandBarButtonItem58
            // 
            this.spreadsheetCommandBarButtonItem58.CommandName = "ConditionalFormattingRemove";
            this.spreadsheetCommandBarButtonItem58.Id = 96;
            this.spreadsheetCommandBarButtonItem58.Name = "spreadsheetCommandBarButtonItem58";
            // 
            // galleryFormatAsTableItem1
            // 
            this.galleryFormatAsTableItem1.DropDownControl = this.commandBarGalleryDropDown5;
            this.galleryFormatAsTableItem1.Id = 98;
            this.galleryFormatAsTableItem1.Name = "galleryFormatAsTableItem1";
            // 
            // commandBarGalleryDropDown5
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown5.Gallery.AllowFilter = false;
            this.commandBarGalleryDropDown5.Gallery.ColumnCount = 7;
            this.commandBarGalleryDropDown5.Gallery.DrawImageBackground = false;
            this.commandBarGalleryDropDown5.Gallery.ItemAutoSizeMode = DevExpress.XtraBars.Ribbon.Gallery.GalleryItemAutoSizeMode.None;
            this.commandBarGalleryDropDown5.Gallery.ItemSize = new System.Drawing.Size(73, 58);
            this.commandBarGalleryDropDown5.Gallery.RowCount = 10;
            this.commandBarGalleryDropDown5.Name = "commandBarGalleryDropDown5";
            this.commandBarGalleryDropDown5.Ribbon = this.ribbonControl1;
            // 
            // galleryChangeStyleItem1
            // 
            // 
            // 
            // 
            this.galleryChangeStyleItem1.Gallery.DrawImageBackground = false;
            this.galleryChangeStyleItem1.Gallery.ImageSize = new System.Drawing.Size(65, 46);
            this.galleryChangeStyleItem1.Gallery.ItemAutoSizeMode = DevExpress.XtraBars.Ribbon.Gallery.GalleryItemAutoSizeMode.None;
            this.galleryChangeStyleItem1.Gallery.ItemSize = new System.Drawing.Size(106, 28);
            this.galleryChangeStyleItem1.Gallery.RowCount = 9;
            this.galleryChangeStyleItem1.Gallery.ShowItemText = true;
            this.galleryChangeStyleItem1.Id = 99;
            this.galleryChangeStyleItem1.Name = "galleryChangeStyleItem1";
            // 
            // cellsRibbonPageGroup1
            // 
            this.cellsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem8);
            this.cellsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem9);
            this.cellsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem10);
            this.cellsRibbonPageGroup1.Name = "cellsRibbonPageGroup1";
            // 
            // spreadsheetCommandBarSubItem8
            // 
            this.spreadsheetCommandBarSubItem8.CommandName = "InsertCellsCommandGroup";
            this.spreadsheetCommandBarSubItem8.Id = 100;
            this.spreadsheetCommandBarSubItem8.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem59),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem60),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem61)});
            this.spreadsheetCommandBarSubItem8.Name = "spreadsheetCommandBarSubItem8";
            // 
            // spreadsheetCommandBarButtonItem59
            // 
            this.spreadsheetCommandBarButtonItem59.CommandName = "InsertSheetRows";
            this.spreadsheetCommandBarButtonItem59.Id = 101;
            this.spreadsheetCommandBarButtonItem59.Name = "spreadsheetCommandBarButtonItem59";
            // 
            // spreadsheetCommandBarButtonItem60
            // 
            this.spreadsheetCommandBarButtonItem60.CommandName = "InsertSheetColumns";
            this.spreadsheetCommandBarButtonItem60.Id = 102;
            this.spreadsheetCommandBarButtonItem60.Name = "spreadsheetCommandBarButtonItem60";
            // 
            // spreadsheetCommandBarButtonItem61
            // 
            this.spreadsheetCommandBarButtonItem61.CommandName = "InsertSheet";
            this.spreadsheetCommandBarButtonItem61.Id = 103;
            this.spreadsheetCommandBarButtonItem61.Name = "spreadsheetCommandBarButtonItem61";
            // 
            // spreadsheetCommandBarSubItem9
            // 
            this.spreadsheetCommandBarSubItem9.CommandName = "RemoveCellsCommandGroup";
            this.spreadsheetCommandBarSubItem9.Id = 104;
            this.spreadsheetCommandBarSubItem9.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem62),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem63),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem64)});
            this.spreadsheetCommandBarSubItem9.Name = "spreadsheetCommandBarSubItem9";
            // 
            // spreadsheetCommandBarButtonItem62
            // 
            this.spreadsheetCommandBarButtonItem62.CommandName = "RemoveSheetRows";
            this.spreadsheetCommandBarButtonItem62.Id = 105;
            this.spreadsheetCommandBarButtonItem62.Name = "spreadsheetCommandBarButtonItem62";
            // 
            // spreadsheetCommandBarButtonItem63
            // 
            this.spreadsheetCommandBarButtonItem63.CommandName = "RemoveSheetColumns";
            this.spreadsheetCommandBarButtonItem63.Id = 106;
            this.spreadsheetCommandBarButtonItem63.Name = "spreadsheetCommandBarButtonItem63";
            // 
            // spreadsheetCommandBarButtonItem64
            // 
            this.spreadsheetCommandBarButtonItem64.CommandName = "RemoveSheet";
            this.spreadsheetCommandBarButtonItem64.Id = 107;
            this.spreadsheetCommandBarButtonItem64.Name = "spreadsheetCommandBarButtonItem64";
            // 
            // spreadsheetCommandBarSubItem10
            // 
            this.spreadsheetCommandBarSubItem10.CommandName = "FormatCommandGroup";
            this.spreadsheetCommandBarSubItem10.Id = 108;
            this.spreadsheetCommandBarSubItem10.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem65),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem66),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem67),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem68),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem69),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarSubItem11),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem76),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem77),
            new DevExpress.XtraBars.LinkPersistInfo(this.changeSheetTabColorItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem78),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarCheckItem13),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem79)});
            this.spreadsheetCommandBarSubItem10.Name = "spreadsheetCommandBarSubItem10";
            // 
            // spreadsheetCommandBarButtonItem65
            // 
            this.spreadsheetCommandBarButtonItem65.CommandName = "FormatRowHeight";
            this.spreadsheetCommandBarButtonItem65.Id = 109;
            this.spreadsheetCommandBarButtonItem65.Name = "spreadsheetCommandBarButtonItem65";
            // 
            // spreadsheetCommandBarButtonItem66
            // 
            this.spreadsheetCommandBarButtonItem66.CommandName = "FormatAutoFitRowHeight";
            this.spreadsheetCommandBarButtonItem66.Id = 110;
            this.spreadsheetCommandBarButtonItem66.Name = "spreadsheetCommandBarButtonItem66";
            // 
            // spreadsheetCommandBarButtonItem67
            // 
            this.spreadsheetCommandBarButtonItem67.CommandName = "FormatColumnWidth";
            this.spreadsheetCommandBarButtonItem67.Id = 111;
            this.spreadsheetCommandBarButtonItem67.Name = "spreadsheetCommandBarButtonItem67";
            // 
            // spreadsheetCommandBarButtonItem68
            // 
            this.spreadsheetCommandBarButtonItem68.CommandName = "FormatAutoFitColumnWidth";
            this.spreadsheetCommandBarButtonItem68.Id = 112;
            this.spreadsheetCommandBarButtonItem68.Name = "spreadsheetCommandBarButtonItem68";
            // 
            // spreadsheetCommandBarButtonItem69
            // 
            this.spreadsheetCommandBarButtonItem69.CommandName = "FormatDefaultColumnWidth";
            this.spreadsheetCommandBarButtonItem69.Id = 113;
            this.spreadsheetCommandBarButtonItem69.Name = "spreadsheetCommandBarButtonItem69";
            // 
            // spreadsheetCommandBarSubItem11
            // 
            this.spreadsheetCommandBarSubItem11.CommandName = "HideAndUnhideCommandGroup";
            this.spreadsheetCommandBarSubItem11.Id = 120;
            this.spreadsheetCommandBarSubItem11.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem70),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem71),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem72),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem73),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem74),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem75)});
            this.spreadsheetCommandBarSubItem11.Name = "spreadsheetCommandBarSubItem11";
            // 
            // spreadsheetCommandBarButtonItem70
            // 
            this.spreadsheetCommandBarButtonItem70.CommandName = "HideRows";
            this.spreadsheetCommandBarButtonItem70.Id = 114;
            this.spreadsheetCommandBarButtonItem70.Name = "spreadsheetCommandBarButtonItem70";
            // 
            // spreadsheetCommandBarButtonItem71
            // 
            this.spreadsheetCommandBarButtonItem71.CommandName = "HideColumns";
            this.spreadsheetCommandBarButtonItem71.Id = 115;
            this.spreadsheetCommandBarButtonItem71.Name = "spreadsheetCommandBarButtonItem71";
            // 
            // spreadsheetCommandBarButtonItem72
            // 
            this.spreadsheetCommandBarButtonItem72.CommandName = "HideSheet";
            this.spreadsheetCommandBarButtonItem72.Id = 116;
            this.spreadsheetCommandBarButtonItem72.Name = "spreadsheetCommandBarButtonItem72";
            // 
            // spreadsheetCommandBarButtonItem73
            // 
            this.spreadsheetCommandBarButtonItem73.CommandName = "UnhideRows";
            this.spreadsheetCommandBarButtonItem73.Id = 117;
            this.spreadsheetCommandBarButtonItem73.Name = "spreadsheetCommandBarButtonItem73";
            // 
            // spreadsheetCommandBarButtonItem74
            // 
            this.spreadsheetCommandBarButtonItem74.CommandName = "UnhideColumns";
            this.spreadsheetCommandBarButtonItem74.Id = 118;
            this.spreadsheetCommandBarButtonItem74.Name = "spreadsheetCommandBarButtonItem74";
            // 
            // spreadsheetCommandBarButtonItem75
            // 
            this.spreadsheetCommandBarButtonItem75.CommandName = "UnhideSheet";
            this.spreadsheetCommandBarButtonItem75.Id = 119;
            this.spreadsheetCommandBarButtonItem75.Name = "spreadsheetCommandBarButtonItem75";
            // 
            // spreadsheetCommandBarButtonItem76
            // 
            this.spreadsheetCommandBarButtonItem76.CommandName = "RenameSheet";
            this.spreadsheetCommandBarButtonItem76.Id = 121;
            this.spreadsheetCommandBarButtonItem76.Name = "spreadsheetCommandBarButtonItem76";
            // 
            // spreadsheetCommandBarButtonItem77
            // 
            this.spreadsheetCommandBarButtonItem77.CommandName = "MoveOrCopySheet";
            this.spreadsheetCommandBarButtonItem77.Id = 122;
            this.spreadsheetCommandBarButtonItem77.Name = "spreadsheetCommandBarButtonItem77";
            // 
            // changeSheetTabColorItem1
            // 
            this.changeSheetTabColorItem1.ActAsDropDown = true;
            this.changeSheetTabColorItem1.Id = 123;
            this.changeSheetTabColorItem1.Name = "changeSheetTabColorItem1";
            // 
            // spreadsheetCommandBarButtonItem78
            // 
            this.spreadsheetCommandBarButtonItem78.CommandName = "ReviewProtectSheet";
            this.spreadsheetCommandBarButtonItem78.Id = 124;
            this.spreadsheetCommandBarButtonItem78.Name = "spreadsheetCommandBarButtonItem78";
            // 
            // spreadsheetCommandBarCheckItem13
            // 
            this.spreadsheetCommandBarCheckItem13.CommandName = "FormatCellLocked";
            this.spreadsheetCommandBarCheckItem13.Id = 125;
            this.spreadsheetCommandBarCheckItem13.Name = "spreadsheetCommandBarCheckItem13";
            // 
            // spreadsheetCommandBarButtonItem79
            // 
            this.spreadsheetCommandBarButtonItem79.CommandName = "FormatCellsContextMenuItem";
            this.spreadsheetCommandBarButtonItem79.Id = 126;
            this.spreadsheetCommandBarButtonItem79.Name = "spreadsheetCommandBarButtonItem79";
            // 
            // editingRibbonPageGroup1
            // 
            this.editingRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem12);
            this.editingRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem13);
            this.editingRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem14);
            this.editingRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem15);
            this.editingRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem16);
            this.editingRibbonPageGroup1.Name = "editingRibbonPageGroup1";
            // 
            // spreadsheetCommandBarSubItem12
            // 
            this.spreadsheetCommandBarSubItem12.CommandName = "EditingAutoSumCommandGroup";
            this.spreadsheetCommandBarSubItem12.Id = 127;
            this.spreadsheetCommandBarSubItem12.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem80),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem81),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem82),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem83),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem84)});
            this.spreadsheetCommandBarSubItem12.Name = "spreadsheetCommandBarSubItem12";
            this.spreadsheetCommandBarSubItem12.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // spreadsheetCommandBarButtonItem80
            // 
            this.spreadsheetCommandBarButtonItem80.CommandName = "FunctionsInsertSum";
            this.spreadsheetCommandBarButtonItem80.Id = 128;
            this.spreadsheetCommandBarButtonItem80.Name = "spreadsheetCommandBarButtonItem80";
            // 
            // spreadsheetCommandBarButtonItem81
            // 
            this.spreadsheetCommandBarButtonItem81.CommandName = "FunctionsInsertAverage";
            this.spreadsheetCommandBarButtonItem81.Id = 129;
            this.spreadsheetCommandBarButtonItem81.Name = "spreadsheetCommandBarButtonItem81";
            // 
            // spreadsheetCommandBarButtonItem82
            // 
            this.spreadsheetCommandBarButtonItem82.CommandName = "FunctionsInsertCountNumbers";
            this.spreadsheetCommandBarButtonItem82.Id = 130;
            this.spreadsheetCommandBarButtonItem82.Name = "spreadsheetCommandBarButtonItem82";
            // 
            // spreadsheetCommandBarButtonItem83
            // 
            this.spreadsheetCommandBarButtonItem83.CommandName = "FunctionsInsertMax";
            this.spreadsheetCommandBarButtonItem83.Id = 131;
            this.spreadsheetCommandBarButtonItem83.Name = "spreadsheetCommandBarButtonItem83";
            // 
            // spreadsheetCommandBarButtonItem84
            // 
            this.spreadsheetCommandBarButtonItem84.CommandName = "FunctionsInsertMin";
            this.spreadsheetCommandBarButtonItem84.Id = 132;
            this.spreadsheetCommandBarButtonItem84.Name = "spreadsheetCommandBarButtonItem84";
            // 
            // spreadsheetCommandBarSubItem13
            // 
            this.spreadsheetCommandBarSubItem13.CommandName = "EditingFillCommandGroup";
            this.spreadsheetCommandBarSubItem13.Id = 133;
            this.spreadsheetCommandBarSubItem13.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem85),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem86),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem87),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem88)});
            this.spreadsheetCommandBarSubItem13.Name = "spreadsheetCommandBarSubItem13";
            this.spreadsheetCommandBarSubItem13.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // spreadsheetCommandBarButtonItem85
            // 
            this.spreadsheetCommandBarButtonItem85.CommandName = "EditingFillDown";
            this.spreadsheetCommandBarButtonItem85.Id = 134;
            this.spreadsheetCommandBarButtonItem85.Name = "spreadsheetCommandBarButtonItem85";
            // 
            // spreadsheetCommandBarButtonItem86
            // 
            this.spreadsheetCommandBarButtonItem86.CommandName = "EditingFillRight";
            this.spreadsheetCommandBarButtonItem86.Id = 135;
            this.spreadsheetCommandBarButtonItem86.Name = "spreadsheetCommandBarButtonItem86";
            // 
            // spreadsheetCommandBarButtonItem87
            // 
            this.spreadsheetCommandBarButtonItem87.CommandName = "EditingFillUp";
            this.spreadsheetCommandBarButtonItem87.Id = 136;
            this.spreadsheetCommandBarButtonItem87.Name = "spreadsheetCommandBarButtonItem87";
            // 
            // spreadsheetCommandBarButtonItem88
            // 
            this.spreadsheetCommandBarButtonItem88.CommandName = "EditingFillLeft";
            this.spreadsheetCommandBarButtonItem88.Id = 137;
            this.spreadsheetCommandBarButtonItem88.Name = "spreadsheetCommandBarButtonItem88";
            // 
            // spreadsheetCommandBarSubItem14
            // 
            this.spreadsheetCommandBarSubItem14.CommandName = "FormatClearCommandGroup";
            this.spreadsheetCommandBarSubItem14.Id = 138;
            this.spreadsheetCommandBarSubItem14.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem89),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem90),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem91),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem92),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem93),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem94)});
            this.spreadsheetCommandBarSubItem14.Name = "spreadsheetCommandBarSubItem14";
            this.spreadsheetCommandBarSubItem14.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // spreadsheetCommandBarButtonItem89
            // 
            this.spreadsheetCommandBarButtonItem89.CommandName = "FormatClearAll";
            this.spreadsheetCommandBarButtonItem89.Id = 139;
            this.spreadsheetCommandBarButtonItem89.Name = "spreadsheetCommandBarButtonItem89";
            // 
            // spreadsheetCommandBarButtonItem90
            // 
            this.spreadsheetCommandBarButtonItem90.CommandName = "FormatClearFormats";
            this.spreadsheetCommandBarButtonItem90.Id = 140;
            this.spreadsheetCommandBarButtonItem90.Name = "spreadsheetCommandBarButtonItem90";
            // 
            // spreadsheetCommandBarButtonItem91
            // 
            this.spreadsheetCommandBarButtonItem91.CommandName = "FormatClearContents";
            this.spreadsheetCommandBarButtonItem91.Id = 141;
            this.spreadsheetCommandBarButtonItem91.Name = "spreadsheetCommandBarButtonItem91";
            // 
            // spreadsheetCommandBarButtonItem92
            // 
            this.spreadsheetCommandBarButtonItem92.CommandName = "FormatClearComments";
            this.spreadsheetCommandBarButtonItem92.Id = 142;
            this.spreadsheetCommandBarButtonItem92.Name = "spreadsheetCommandBarButtonItem92";
            // 
            // spreadsheetCommandBarButtonItem93
            // 
            this.spreadsheetCommandBarButtonItem93.CommandName = "FormatClearHyperlinks";
            this.spreadsheetCommandBarButtonItem93.Id = 143;
            this.spreadsheetCommandBarButtonItem93.Name = "spreadsheetCommandBarButtonItem93";
            // 
            // spreadsheetCommandBarButtonItem94
            // 
            this.spreadsheetCommandBarButtonItem94.CommandName = "FormatRemoveHyperlinks";
            this.spreadsheetCommandBarButtonItem94.Id = 144;
            this.spreadsheetCommandBarButtonItem94.Name = "spreadsheetCommandBarButtonItem94";
            // 
            // spreadsheetCommandBarSubItem15
            // 
            this.spreadsheetCommandBarSubItem15.CommandName = "EditingSortAndFilterCommandGroup";
            this.spreadsheetCommandBarSubItem15.Id = 145;
            this.spreadsheetCommandBarSubItem15.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem95),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem96),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarCheckItem14),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem97),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem98)});
            this.spreadsheetCommandBarSubItem15.Name = "spreadsheetCommandBarSubItem15";
            // 
            // spreadsheetCommandBarButtonItem95
            // 
            this.spreadsheetCommandBarButtonItem95.CommandName = "DataSortAscending";
            this.spreadsheetCommandBarButtonItem95.Id = 146;
            this.spreadsheetCommandBarButtonItem95.Name = "spreadsheetCommandBarButtonItem95";
            // 
            // spreadsheetCommandBarButtonItem96
            // 
            this.spreadsheetCommandBarButtonItem96.CommandName = "DataSortDescending";
            this.spreadsheetCommandBarButtonItem96.Id = 147;
            this.spreadsheetCommandBarButtonItem96.Name = "spreadsheetCommandBarButtonItem96";
            // 
            // spreadsheetCommandBarCheckItem14
            // 
            this.spreadsheetCommandBarCheckItem14.CommandName = "DataFilterToggle";
            this.spreadsheetCommandBarCheckItem14.Id = 148;
            this.spreadsheetCommandBarCheckItem14.Name = "spreadsheetCommandBarCheckItem14";
            // 
            // spreadsheetCommandBarButtonItem97
            // 
            this.spreadsheetCommandBarButtonItem97.CommandName = "DataFilterClear";
            this.spreadsheetCommandBarButtonItem97.Id = 149;
            this.spreadsheetCommandBarButtonItem97.Name = "spreadsheetCommandBarButtonItem97";
            // 
            // spreadsheetCommandBarButtonItem98
            // 
            this.spreadsheetCommandBarButtonItem98.CommandName = "DataFilterReApply";
            this.spreadsheetCommandBarButtonItem98.Id = 150;
            this.spreadsheetCommandBarButtonItem98.Name = "spreadsheetCommandBarButtonItem98";
            // 
            // spreadsheetCommandBarSubItem16
            // 
            this.spreadsheetCommandBarSubItem16.CommandName = "EditingFindAndSelectCommandGroup";
            this.spreadsheetCommandBarSubItem16.Id = 151;
            this.spreadsheetCommandBarSubItem16.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem99),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem100),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem101),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem102),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem103),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem104),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem105)});
            this.spreadsheetCommandBarSubItem16.Name = "spreadsheetCommandBarSubItem16";
            // 
            // spreadsheetCommandBarButtonItem99
            // 
            this.spreadsheetCommandBarButtonItem99.CommandName = "EditingFind";
            this.spreadsheetCommandBarButtonItem99.Id = 152;
            this.spreadsheetCommandBarButtonItem99.Name = "spreadsheetCommandBarButtonItem99";
            // 
            // spreadsheetCommandBarButtonItem100
            // 
            this.spreadsheetCommandBarButtonItem100.CommandName = "EditingReplace";
            this.spreadsheetCommandBarButtonItem100.Id = 153;
            this.spreadsheetCommandBarButtonItem100.Name = "spreadsheetCommandBarButtonItem100";
            // 
            // spreadsheetCommandBarButtonItem101
            // 
            this.spreadsheetCommandBarButtonItem101.CommandName = "EditingSelectFormulas";
            this.spreadsheetCommandBarButtonItem101.Id = 154;
            this.spreadsheetCommandBarButtonItem101.Name = "spreadsheetCommandBarButtonItem101";
            // 
            // spreadsheetCommandBarButtonItem102
            // 
            this.spreadsheetCommandBarButtonItem102.CommandName = "EditingSelectComments";
            this.spreadsheetCommandBarButtonItem102.Id = 155;
            this.spreadsheetCommandBarButtonItem102.Name = "spreadsheetCommandBarButtonItem102";
            // 
            // spreadsheetCommandBarButtonItem103
            // 
            this.spreadsheetCommandBarButtonItem103.CommandName = "EditingSelectConditionalFormatting";
            this.spreadsheetCommandBarButtonItem103.Id = 156;
            this.spreadsheetCommandBarButtonItem103.Name = "spreadsheetCommandBarButtonItem103";
            // 
            // spreadsheetCommandBarButtonItem104
            // 
            this.spreadsheetCommandBarButtonItem104.CommandName = "EditingSelectConstants";
            this.spreadsheetCommandBarButtonItem104.Id = 157;
            this.spreadsheetCommandBarButtonItem104.Name = "spreadsheetCommandBarButtonItem104";
            // 
            // spreadsheetCommandBarButtonItem105
            // 
            this.spreadsheetCommandBarButtonItem105.CommandName = "EditingSelectDataValidation";
            this.spreadsheetCommandBarButtonItem105.Id = 158;
            this.spreadsheetCommandBarButtonItem105.Name = "spreadsheetCommandBarButtonItem105";
            // 
            // tablesRibbonPageGroup1
            // 
            this.tablesRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem106);
            this.tablesRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem107);
            this.tablesRibbonPageGroup1.Name = "tablesRibbonPageGroup1";
            // 
            // insertRibbonPage1
            // 
            this.insertRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.tablesRibbonPageGroup1,
            this.illustrationsRibbonPageGroup1,
            this.chartsRibbonPageGroup1,
            this.linksRibbonPageGroup1,
            this.symbolsRibbonPageGroup1});
            this.insertRibbonPage1.Name = "insertRibbonPage1";
            // 
            // spreadsheetCommandBarButtonItem106
            // 
            this.spreadsheetCommandBarButtonItem106.CommandName = "InsertPivotTable";
            this.spreadsheetCommandBarButtonItem106.Id = 159;
            this.spreadsheetCommandBarButtonItem106.Name = "spreadsheetCommandBarButtonItem106";
            // 
            // spreadsheetCommandBarButtonItem107
            // 
            this.spreadsheetCommandBarButtonItem107.CommandName = "InsertTable";
            this.spreadsheetCommandBarButtonItem107.Id = 160;
            this.spreadsheetCommandBarButtonItem107.Name = "spreadsheetCommandBarButtonItem107";
            // 
            // illustrationsRibbonPageGroup1
            // 
            this.illustrationsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem108);
            this.illustrationsRibbonPageGroup1.Name = "illustrationsRibbonPageGroup1";
            // 
            // spreadsheetCommandBarButtonItem108
            // 
            this.spreadsheetCommandBarButtonItem108.CommandName = "InsertPicture";
            this.spreadsheetCommandBarButtonItem108.Id = 161;
            this.spreadsheetCommandBarButtonItem108.Name = "spreadsheetCommandBarButtonItem108";
            // 
            // chartsRibbonPageGroup1
            // 
            this.chartsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem4);
            this.chartsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem5);
            this.chartsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem6);
            this.chartsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem7);
            this.chartsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem8);
            this.chartsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem9);
            this.chartsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem10);
            this.chartsRibbonPageGroup1.Name = "chartsRibbonPageGroup1";
            // 
            // spreadsheetCommandBarButtonGalleryDropDownItem4
            // 
            this.spreadsheetCommandBarButtonGalleryDropDownItem4.CommandName = "InsertChartColumnCommandGroup";
            this.spreadsheetCommandBarButtonGalleryDropDownItem4.DropDownControl = this.commandBarGalleryDropDown6;
            this.spreadsheetCommandBarButtonGalleryDropDownItem4.Id = 162;
            this.spreadsheetCommandBarButtonGalleryDropDownItem4.Name = "spreadsheetCommandBarButtonGalleryDropDownItem4";
            // 
            // commandBarGalleryDropDown6
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown6.Gallery.ColumnCount = 4;
            spreadsheetCommandGalleryItemGroup8.CommandName = "InsertChartColumn2DCommandGroup";
            spreadsheetCommandGalleryItem56.CommandName = "InsertChartColumnClustered2D";
            spreadsheetCommandGalleryItem57.CommandName = "InsertChartColumnStacked2D";
            spreadsheetCommandGalleryItem58.CommandName = "InsertChartColumnPercentStacked2D";
            spreadsheetCommandGalleryItemGroup8.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem56,
            spreadsheetCommandGalleryItem57,
            spreadsheetCommandGalleryItem58});
            spreadsheetCommandGalleryItemGroup9.CommandName = "InsertChartColumn3DCommandGroup";
            spreadsheetCommandGalleryItem59.CommandName = "InsertChartColumnClustered3D";
            spreadsheetCommandGalleryItem60.CommandName = "InsertChartColumnStacked3D";
            spreadsheetCommandGalleryItem61.CommandName = "InsertChartColumnPercentStacked3D";
            spreadsheetCommandGalleryItem62.CommandName = "InsertChartColumn3D";
            spreadsheetCommandGalleryItemGroup9.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem59,
            spreadsheetCommandGalleryItem60,
            spreadsheetCommandGalleryItem61,
            spreadsheetCommandGalleryItem62});
            spreadsheetCommandGalleryItemGroup10.CommandName = "InsertChartCylinderCommandGroup";
            spreadsheetCommandGalleryItem63.CommandName = "InsertChartCylinderClustered";
            spreadsheetCommandGalleryItem64.CommandName = "InsertChartCylinderStacked";
            spreadsheetCommandGalleryItem65.CommandName = "InsertChartCylinderPercentStacked";
            spreadsheetCommandGalleryItem66.CommandName = "InsertChartCylinder";
            spreadsheetCommandGalleryItemGroup10.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem63,
            spreadsheetCommandGalleryItem64,
            spreadsheetCommandGalleryItem65,
            spreadsheetCommandGalleryItem66});
            spreadsheetCommandGalleryItemGroup11.CommandName = "InsertChartConeCommandGroup";
            spreadsheetCommandGalleryItem67.CommandName = "InsertChartConeClustered";
            spreadsheetCommandGalleryItem68.CommandName = "InsertChartConeStacked";
            spreadsheetCommandGalleryItem69.CommandName = "InsertChartConePercentStacked";
            spreadsheetCommandGalleryItem70.CommandName = "InsertChartCone";
            spreadsheetCommandGalleryItemGroup11.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem67,
            spreadsheetCommandGalleryItem68,
            spreadsheetCommandGalleryItem69,
            spreadsheetCommandGalleryItem70});
            spreadsheetCommandGalleryItemGroup12.CommandName = "InsertChartPyramidCommandGroup";
            spreadsheetCommandGalleryItem71.CommandName = "InsertChartPyramidClustered";
            spreadsheetCommandGalleryItem72.CommandName = "InsertChartPyramidStacked";
            spreadsheetCommandGalleryItem73.CommandName = "InsertChartPyramidPercentStacked";
            spreadsheetCommandGalleryItem74.CommandName = "InsertChartPyramid";
            spreadsheetCommandGalleryItemGroup12.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem71,
            spreadsheetCommandGalleryItem72,
            spreadsheetCommandGalleryItem73,
            spreadsheetCommandGalleryItem74});
            this.commandBarGalleryDropDown6.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            spreadsheetCommandGalleryItemGroup8,
            spreadsheetCommandGalleryItemGroup9,
            spreadsheetCommandGalleryItemGroup10,
            spreadsheetCommandGalleryItemGroup11,
            spreadsheetCommandGalleryItemGroup12});
            this.commandBarGalleryDropDown6.Gallery.RowCount = 5;
            this.commandBarGalleryDropDown6.Name = "commandBarGalleryDropDown6";
            this.commandBarGalleryDropDown6.Ribbon = this.ribbonControl1;
            // 
            // spreadsheetCommandBarButtonGalleryDropDownItem5
            // 
            this.spreadsheetCommandBarButtonGalleryDropDownItem5.CommandName = "InsertChartLineCommandGroup";
            this.spreadsheetCommandBarButtonGalleryDropDownItem5.DropDownControl = this.commandBarGalleryDropDown7;
            this.spreadsheetCommandBarButtonGalleryDropDownItem5.Id = 163;
            this.spreadsheetCommandBarButtonGalleryDropDownItem5.Name = "spreadsheetCommandBarButtonGalleryDropDownItem5";
            // 
            // commandBarGalleryDropDown7
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown7.Gallery.ColumnCount = 3;
            spreadsheetCommandGalleryItemGroup13.CommandName = "InsertChartLine2DCommandGroup";
            spreadsheetCommandGalleryItem75.CommandName = "InsertChartLine";
            spreadsheetCommandGalleryItem76.CommandName = "InsertChartStackedLine";
            spreadsheetCommandGalleryItem77.CommandName = "InsertChartPercentStackedLine";
            spreadsheetCommandGalleryItem78.CommandName = "InsertChartLineWithMarkers";
            spreadsheetCommandGalleryItem79.CommandName = "InsertChartStackedLineWithMarkers";
            spreadsheetCommandGalleryItem80.CommandName = "InsertChartPercentStackedLineWithMarkers";
            spreadsheetCommandGalleryItemGroup13.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem75,
            spreadsheetCommandGalleryItem76,
            spreadsheetCommandGalleryItem77,
            spreadsheetCommandGalleryItem78,
            spreadsheetCommandGalleryItem79,
            spreadsheetCommandGalleryItem80});
            spreadsheetCommandGalleryItemGroup14.CommandName = "InsertChartLine3DCommandGroup";
            spreadsheetCommandGalleryItem81.CommandName = "InsertChartLine3D";
            spreadsheetCommandGalleryItemGroup14.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem81});
            this.commandBarGalleryDropDown7.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            spreadsheetCommandGalleryItemGroup13,
            spreadsheetCommandGalleryItemGroup14});
            this.commandBarGalleryDropDown7.Name = "commandBarGalleryDropDown7";
            this.commandBarGalleryDropDown7.Ribbon = this.ribbonControl1;
            // 
            // spreadsheetCommandBarButtonGalleryDropDownItem6
            // 
            this.spreadsheetCommandBarButtonGalleryDropDownItem6.CommandName = "InsertChartPieCommandGroup";
            this.spreadsheetCommandBarButtonGalleryDropDownItem6.DropDownControl = this.commandBarGalleryDropDown8;
            this.spreadsheetCommandBarButtonGalleryDropDownItem6.Id = 164;
            this.spreadsheetCommandBarButtonGalleryDropDownItem6.Name = "spreadsheetCommandBarButtonGalleryDropDownItem6";
            // 
            // commandBarGalleryDropDown8
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown8.Gallery.ColumnCount = 2;
            spreadsheetCommandGalleryItemGroup15.CommandName = "InsertChartPie2DCommandGroup";
            spreadsheetCommandGalleryItem82.CommandName = "InsertChartPie2D";
            spreadsheetCommandGalleryItem83.CommandName = "InsertChartPieExploded2D";
            spreadsheetCommandGalleryItemGroup15.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem82,
            spreadsheetCommandGalleryItem83});
            spreadsheetCommandGalleryItemGroup16.CommandName = "InsertChartPie3DCommandGroup";
            spreadsheetCommandGalleryItem84.CommandName = "InsertChartPie3D";
            spreadsheetCommandGalleryItem85.CommandName = "InsertChartPieExploded3D";
            spreadsheetCommandGalleryItemGroup16.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem84,
            spreadsheetCommandGalleryItem85});
            spreadsheetCommandGalleryItemGroup17.CommandName = "InsertChartDoughnut2DCommandGroup";
            spreadsheetCommandGalleryItem86.CommandName = "InsertChartDoughnut2D";
            spreadsheetCommandGalleryItem87.CommandName = "InsertChartDoughnutExploded2D";
            spreadsheetCommandGalleryItemGroup17.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem86,
            spreadsheetCommandGalleryItem87});
            this.commandBarGalleryDropDown8.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            spreadsheetCommandGalleryItemGroup15,
            spreadsheetCommandGalleryItemGroup16,
            spreadsheetCommandGalleryItemGroup17});
            this.commandBarGalleryDropDown8.Name = "commandBarGalleryDropDown8";
            this.commandBarGalleryDropDown8.Ribbon = this.ribbonControl1;
            // 
            // spreadsheetCommandBarButtonGalleryDropDownItem7
            // 
            this.spreadsheetCommandBarButtonGalleryDropDownItem7.CommandName = "InsertChartBarCommandGroup";
            this.spreadsheetCommandBarButtonGalleryDropDownItem7.DropDownControl = this.commandBarGalleryDropDown9;
            this.spreadsheetCommandBarButtonGalleryDropDownItem7.Id = 165;
            this.spreadsheetCommandBarButtonGalleryDropDownItem7.Name = "spreadsheetCommandBarButtonGalleryDropDownItem7";
            // 
            // commandBarGalleryDropDown9
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown9.Gallery.ColumnCount = 3;
            spreadsheetCommandGalleryItemGroup18.CommandName = "InsertChartBar2DCommandGroup";
            spreadsheetCommandGalleryItem88.CommandName = "InsertChartBarClustered2D";
            spreadsheetCommandGalleryItem89.CommandName = "InsertChartBarStacked2D";
            spreadsheetCommandGalleryItem90.CommandName = "InsertChartBarPercentStacked2D";
            spreadsheetCommandGalleryItemGroup18.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem88,
            spreadsheetCommandGalleryItem89,
            spreadsheetCommandGalleryItem90});
            spreadsheetCommandGalleryItemGroup19.CommandName = "InsertChartBar3DCommandGroup";
            spreadsheetCommandGalleryItem91.CommandName = "InsertChartBarClustered3D";
            spreadsheetCommandGalleryItem92.CommandName = "InsertChartBarStacked3D";
            spreadsheetCommandGalleryItem93.CommandName = "InsertChartBarPercentStacked3D";
            spreadsheetCommandGalleryItemGroup19.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem91,
            spreadsheetCommandGalleryItem92,
            spreadsheetCommandGalleryItem93});
            spreadsheetCommandGalleryItemGroup20.CommandName = "InsertChartHorizontalCylinderCommandGroup";
            spreadsheetCommandGalleryItem94.CommandName = "InsertChartHorizontalCylinderClustered";
            spreadsheetCommandGalleryItem95.CommandName = "InsertChartHorizontalCylinderStacked";
            spreadsheetCommandGalleryItem96.CommandName = "InsertChartHorizontalCylinderPercentStacked";
            spreadsheetCommandGalleryItemGroup20.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem94,
            spreadsheetCommandGalleryItem95,
            spreadsheetCommandGalleryItem96});
            spreadsheetCommandGalleryItemGroup21.CommandName = "InsertChartHorizontalConeCommandGroup";
            spreadsheetCommandGalleryItem97.CommandName = "InsertChartHorizontalConeClustered";
            spreadsheetCommandGalleryItem98.CommandName = "InsertChartHorizontalConeStacked";
            spreadsheetCommandGalleryItem99.CommandName = "InsertChartHorizontalConePercentStacked";
            spreadsheetCommandGalleryItemGroup21.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem97,
            spreadsheetCommandGalleryItem98,
            spreadsheetCommandGalleryItem99});
            spreadsheetCommandGalleryItemGroup22.CommandName = "InsertChartHorizontalPyramidCommandGroup";
            spreadsheetCommandGalleryItem100.CommandName = "InsertChartHorizontalPyramidClustered";
            spreadsheetCommandGalleryItem101.CommandName = "InsertChartHorizontalPyramidStacked";
            spreadsheetCommandGalleryItem102.CommandName = "InsertChartHorizontalPyramidPercentStacked";
            spreadsheetCommandGalleryItemGroup22.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem100,
            spreadsheetCommandGalleryItem101,
            spreadsheetCommandGalleryItem102});
            this.commandBarGalleryDropDown9.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            spreadsheetCommandGalleryItemGroup18,
            spreadsheetCommandGalleryItemGroup19,
            spreadsheetCommandGalleryItemGroup20,
            spreadsheetCommandGalleryItemGroup21,
            spreadsheetCommandGalleryItemGroup22});
            this.commandBarGalleryDropDown9.Gallery.RowCount = 5;
            this.commandBarGalleryDropDown9.Name = "commandBarGalleryDropDown9";
            this.commandBarGalleryDropDown9.Ribbon = this.ribbonControl1;
            // 
            // spreadsheetCommandBarButtonGalleryDropDownItem8
            // 
            this.spreadsheetCommandBarButtonGalleryDropDownItem8.CommandName = "InsertChartAreaCommandGroup";
            this.spreadsheetCommandBarButtonGalleryDropDownItem8.DropDownControl = this.commandBarGalleryDropDown10;
            this.spreadsheetCommandBarButtonGalleryDropDownItem8.Id = 166;
            this.spreadsheetCommandBarButtonGalleryDropDownItem8.Name = "spreadsheetCommandBarButtonGalleryDropDownItem8";
            // 
            // commandBarGalleryDropDown10
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown10.Gallery.ColumnCount = 3;
            spreadsheetCommandGalleryItemGroup23.CommandName = "InsertChartArea2DCommandGroup";
            spreadsheetCommandGalleryItem103.CommandName = "InsertChartArea";
            spreadsheetCommandGalleryItem104.CommandName = "InsertChartStackedArea";
            spreadsheetCommandGalleryItem105.CommandName = "InsertChartPercentStackedArea";
            spreadsheetCommandGalleryItemGroup23.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem103,
            spreadsheetCommandGalleryItem104,
            spreadsheetCommandGalleryItem105});
            spreadsheetCommandGalleryItemGroup24.CommandName = "InsertChartArea3DCommandGroup";
            spreadsheetCommandGalleryItem106.CommandName = "InsertChartArea3D";
            spreadsheetCommandGalleryItem107.CommandName = "InsertChartStackedArea3D";
            spreadsheetCommandGalleryItem108.CommandName = "InsertChartPercentStackedArea3D";
            spreadsheetCommandGalleryItemGroup24.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem106,
            spreadsheetCommandGalleryItem107,
            spreadsheetCommandGalleryItem108});
            this.commandBarGalleryDropDown10.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            spreadsheetCommandGalleryItemGroup23,
            spreadsheetCommandGalleryItemGroup24});
            this.commandBarGalleryDropDown10.Gallery.RowCount = 2;
            this.commandBarGalleryDropDown10.Name = "commandBarGalleryDropDown10";
            this.commandBarGalleryDropDown10.Ribbon = this.ribbonControl1;
            // 
            // spreadsheetCommandBarButtonGalleryDropDownItem9
            // 
            this.spreadsheetCommandBarButtonGalleryDropDownItem9.CommandName = "InsertChartScatterCommandGroup";
            this.spreadsheetCommandBarButtonGalleryDropDownItem9.DropDownControl = this.commandBarGalleryDropDown11;
            this.spreadsheetCommandBarButtonGalleryDropDownItem9.Id = 167;
            this.spreadsheetCommandBarButtonGalleryDropDownItem9.Name = "spreadsheetCommandBarButtonGalleryDropDownItem9";
            // 
            // commandBarGalleryDropDown11
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown11.Gallery.ColumnCount = 2;
            spreadsheetCommandGalleryItemGroup25.CommandName = "InsertChartScatterCommandGroup";
            spreadsheetCommandGalleryItem109.CommandName = "InsertChartScatterMarkers";
            spreadsheetCommandGalleryItem110.CommandName = "InsertChartScatterSmoothLinesAndMarkers";
            spreadsheetCommandGalleryItem111.CommandName = "InsertChartScatterSmoothLines";
            spreadsheetCommandGalleryItem112.CommandName = "InsertChartScatterLinesAndMarkers";
            spreadsheetCommandGalleryItem113.CommandName = "InsertChartScatterLines";
            spreadsheetCommandGalleryItemGroup25.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem109,
            spreadsheetCommandGalleryItem110,
            spreadsheetCommandGalleryItem111,
            spreadsheetCommandGalleryItem112,
            spreadsheetCommandGalleryItem113});
            spreadsheetCommandGalleryItemGroup26.CommandName = "InsertChartBubbleCommandGroup";
            spreadsheetCommandGalleryItem114.CommandName = "InsertChartBubble";
            spreadsheetCommandGalleryItem115.CommandName = "InsertChartBubble3D";
            spreadsheetCommandGalleryItemGroup26.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem114,
            spreadsheetCommandGalleryItem115});
            this.commandBarGalleryDropDown11.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            spreadsheetCommandGalleryItemGroup25,
            spreadsheetCommandGalleryItemGroup26});
            this.commandBarGalleryDropDown11.Gallery.RowCount = 4;
            this.commandBarGalleryDropDown11.Name = "commandBarGalleryDropDown11";
            this.commandBarGalleryDropDown11.Ribbon = this.ribbonControl1;
            // 
            // spreadsheetCommandBarButtonGalleryDropDownItem10
            // 
            this.spreadsheetCommandBarButtonGalleryDropDownItem10.CommandName = "InsertChartOtherCommandGroup";
            this.spreadsheetCommandBarButtonGalleryDropDownItem10.DropDownControl = this.commandBarGalleryDropDown12;
            this.spreadsheetCommandBarButtonGalleryDropDownItem10.Id = 168;
            this.spreadsheetCommandBarButtonGalleryDropDownItem10.Name = "spreadsheetCommandBarButtonGalleryDropDownItem10";
            // 
            // commandBarGalleryDropDown12
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown12.Gallery.ColumnCount = 4;
            spreadsheetCommandGalleryItemGroup27.CommandName = "InsertChartStockCommandGroup";
            spreadsheetCommandGalleryItem116.CommandName = "InsertChartStockHighLowClose";
            spreadsheetCommandGalleryItem117.CommandName = "InsertChartStockOpenHighLowClose";
            spreadsheetCommandGalleryItem118.CommandName = "InsertChartStockVolumeHighLowClose";
            spreadsheetCommandGalleryItem119.CommandName = "InsertChartStockVolumeOpenHighLowClose";
            spreadsheetCommandGalleryItemGroup27.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem116,
            spreadsheetCommandGalleryItem117,
            spreadsheetCommandGalleryItem118,
            spreadsheetCommandGalleryItem119});
            spreadsheetCommandGalleryItemGroup28.CommandName = "InsertChartRadarCommandGroup";
            spreadsheetCommandGalleryItem120.CommandName = "InsertChartRadar";
            spreadsheetCommandGalleryItem121.CommandName = "InsertChartRadarWithMarkers";
            spreadsheetCommandGalleryItem122.CommandName = "InsertChartRadarFilled";
            spreadsheetCommandGalleryItemGroup28.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem120,
            spreadsheetCommandGalleryItem121,
            spreadsheetCommandGalleryItem122});
            this.commandBarGalleryDropDown12.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            spreadsheetCommandGalleryItemGroup27,
            spreadsheetCommandGalleryItemGroup28});
            this.commandBarGalleryDropDown12.Gallery.RowCount = 2;
            this.commandBarGalleryDropDown12.Name = "commandBarGalleryDropDown12";
            this.commandBarGalleryDropDown12.Ribbon = this.ribbonControl1;
            // 
            // linksRibbonPageGroup1
            // 
            this.linksRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem109);
            this.linksRibbonPageGroup1.Name = "linksRibbonPageGroup1";
            // 
            // spreadsheetCommandBarButtonItem109
            // 
            this.spreadsheetCommandBarButtonItem109.CommandName = "InsertHyperlink";
            this.spreadsheetCommandBarButtonItem109.Id = 169;
            this.spreadsheetCommandBarButtonItem109.Name = "spreadsheetCommandBarButtonItem109";
            // 
            // symbolsRibbonPageGroup1
            // 
            this.symbolsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem110);
            this.symbolsRibbonPageGroup1.Name = "symbolsRibbonPageGroup1";
            // 
            // spreadsheetCommandBarButtonItem110
            // 
            this.spreadsheetCommandBarButtonItem110.CommandName = "InsertSymbol";
            this.spreadsheetCommandBarButtonItem110.Id = 170;
            this.spreadsheetCommandBarButtonItem110.Name = "spreadsheetCommandBarButtonItem110";
            // 
            // pageSetupRibbonPageGroup1
            // 
            this.pageSetupRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem17);
            this.pageSetupRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem18);
            this.pageSetupRibbonPageGroup1.ItemLinks.Add(this.pageSetupPaperKindItem1);
            this.pageSetupRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem19);
            this.pageSetupRibbonPageGroup1.Name = "pageSetupRibbonPageGroup1";
            // 
            // pageLayoutRibbonPage1
            // 
            this.pageLayoutRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.pageSetupRibbonPageGroup1,
            this.pageSetupShowRibbonPageGroup1,
            this.pageSetupPrintRibbonPageGroup1,
            this.arrangeRibbonPageGroup1});
            this.pageLayoutRibbonPage1.Name = "pageLayoutRibbonPage1";
            // 
            // spreadsheetCommandBarSubItem17
            // 
            this.spreadsheetCommandBarSubItem17.CommandName = "PageSetupMarginsCommandGroup";
            this.spreadsheetCommandBarSubItem17.Id = 171;
            this.spreadsheetCommandBarSubItem17.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarCheckItem15),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarCheckItem16),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarCheckItem17),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem111)});
            this.spreadsheetCommandBarSubItem17.Name = "spreadsheetCommandBarSubItem17";
            // 
            // spreadsheetCommandBarCheckItem15
            // 
            this.spreadsheetCommandBarCheckItem15.CaptionDependOnUnits = true;
            this.spreadsheetCommandBarCheckItem15.CommandName = "PageSetupMarginsNormal";
            this.spreadsheetCommandBarCheckItem15.Id = 172;
            this.spreadsheetCommandBarCheckItem15.Name = "spreadsheetCommandBarCheckItem15";
            // 
            // spreadsheetCommandBarCheckItem16
            // 
            this.spreadsheetCommandBarCheckItem16.CaptionDependOnUnits = true;
            this.spreadsheetCommandBarCheckItem16.CommandName = "PageSetupMarginsWide";
            this.spreadsheetCommandBarCheckItem16.Id = 173;
            this.spreadsheetCommandBarCheckItem16.Name = "spreadsheetCommandBarCheckItem16";
            // 
            // spreadsheetCommandBarCheckItem17
            // 
            this.spreadsheetCommandBarCheckItem17.CaptionDependOnUnits = true;
            this.spreadsheetCommandBarCheckItem17.CommandName = "PageSetupMarginsNarrow";
            this.spreadsheetCommandBarCheckItem17.Id = 174;
            this.spreadsheetCommandBarCheckItem17.Name = "spreadsheetCommandBarCheckItem17";
            // 
            // spreadsheetCommandBarButtonItem111
            // 
            this.spreadsheetCommandBarButtonItem111.CommandName = "PageSetupCustomMargins";
            this.spreadsheetCommandBarButtonItem111.Id = 175;
            this.spreadsheetCommandBarButtonItem111.Name = "spreadsheetCommandBarButtonItem111";
            // 
            // spreadsheetCommandBarSubItem18
            // 
            this.spreadsheetCommandBarSubItem18.CommandName = "PageSetupOrientationCommandGroup";
            this.spreadsheetCommandBarSubItem18.Id = 176;
            this.spreadsheetCommandBarSubItem18.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarCheckItem18),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarCheckItem19)});
            this.spreadsheetCommandBarSubItem18.Name = "spreadsheetCommandBarSubItem18";
            // 
            // spreadsheetCommandBarCheckItem18
            // 
            this.spreadsheetCommandBarCheckItem18.CommandName = "PageSetupOrientationPortrait";
            this.spreadsheetCommandBarCheckItem18.Id = 177;
            this.spreadsheetCommandBarCheckItem18.Name = "spreadsheetCommandBarCheckItem18";
            // 
            // spreadsheetCommandBarCheckItem19
            // 
            this.spreadsheetCommandBarCheckItem19.CommandName = "PageSetupOrientationLandscape";
            this.spreadsheetCommandBarCheckItem19.Id = 178;
            this.spreadsheetCommandBarCheckItem19.Name = "spreadsheetCommandBarCheckItem19";
            // 
            // pageSetupPaperKindItem1
            // 
            this.pageSetupPaperKindItem1.Id = 179;
            this.pageSetupPaperKindItem1.Name = "pageSetupPaperKindItem1";
            // 
            // spreadsheetCommandBarSubItem19
            // 
            this.spreadsheetCommandBarSubItem19.CommandName = "PageSetupPrintAreaCommandGroup";
            this.spreadsheetCommandBarSubItem19.Id = 180;
            this.spreadsheetCommandBarSubItem19.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem112),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem113),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem114)});
            this.spreadsheetCommandBarSubItem19.Name = "spreadsheetCommandBarSubItem19";
            // 
            // spreadsheetCommandBarButtonItem112
            // 
            this.spreadsheetCommandBarButtonItem112.CommandName = "PageSetupSetPrintArea";
            this.spreadsheetCommandBarButtonItem112.Id = 181;
            this.spreadsheetCommandBarButtonItem112.Name = "spreadsheetCommandBarButtonItem112";
            // 
            // spreadsheetCommandBarButtonItem113
            // 
            this.spreadsheetCommandBarButtonItem113.CommandName = "PageSetupClearPrintArea";
            this.spreadsheetCommandBarButtonItem113.Id = 182;
            this.spreadsheetCommandBarButtonItem113.Name = "spreadsheetCommandBarButtonItem113";
            // 
            // spreadsheetCommandBarButtonItem114
            // 
            this.spreadsheetCommandBarButtonItem114.CommandName = "PageSetupAddPrintArea";
            this.spreadsheetCommandBarButtonItem114.Id = 183;
            this.spreadsheetCommandBarButtonItem114.Name = "spreadsheetCommandBarButtonItem114";
            // 
            // pageSetupShowRibbonPageGroup1
            // 
            this.pageSetupShowRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarCheckItem20);
            this.pageSetupShowRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarCheckItem21);
            this.pageSetupShowRibbonPageGroup1.Name = "pageSetupShowRibbonPageGroup1";
            // 
            // spreadsheetCommandBarCheckItem20
            // 
            this.spreadsheetCommandBarCheckItem20.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText;
            this.spreadsheetCommandBarCheckItem20.CommandName = "ViewShowGridlines";
            this.spreadsheetCommandBarCheckItem20.Id = 184;
            this.spreadsheetCommandBarCheckItem20.Name = "spreadsheetCommandBarCheckItem20";
            // 
            // spreadsheetCommandBarCheckItem21
            // 
            this.spreadsheetCommandBarCheckItem21.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText;
            this.spreadsheetCommandBarCheckItem21.CommandName = "ViewShowHeadings";
            this.spreadsheetCommandBarCheckItem21.Id = 185;
            this.spreadsheetCommandBarCheckItem21.Name = "spreadsheetCommandBarCheckItem21";
            // 
            // pageSetupPrintRibbonPageGroup1
            // 
            this.pageSetupPrintRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarCheckItem22);
            this.pageSetupPrintRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarCheckItem23);
            this.pageSetupPrintRibbonPageGroup1.Name = "pageSetupPrintRibbonPageGroup1";
            // 
            // spreadsheetCommandBarCheckItem22
            // 
            this.spreadsheetCommandBarCheckItem22.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText;
            this.spreadsheetCommandBarCheckItem22.CommandName = "PageSetupPrintGridlines";
            this.spreadsheetCommandBarCheckItem22.Id = 186;
            this.spreadsheetCommandBarCheckItem22.Name = "spreadsheetCommandBarCheckItem22";
            // 
            // spreadsheetCommandBarCheckItem23
            // 
            this.spreadsheetCommandBarCheckItem23.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText;
            this.spreadsheetCommandBarCheckItem23.CommandName = "PageSetupPrintHeadings";
            this.spreadsheetCommandBarCheckItem23.Id = 187;
            this.spreadsheetCommandBarCheckItem23.Name = "spreadsheetCommandBarCheckItem23";
            // 
            // arrangeRibbonPageGroup1
            // 
            this.arrangeRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem20);
            this.arrangeRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem21);
            this.arrangeRibbonPageGroup1.Name = "arrangeRibbonPageGroup1";
            // 
            // spreadsheetCommandBarSubItem20
            // 
            this.spreadsheetCommandBarSubItem20.CommandName = "ArrangeBringForwardCommandGroup";
            this.spreadsheetCommandBarSubItem20.Id = 188;
            this.spreadsheetCommandBarSubItem20.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem115),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem116)});
            this.spreadsheetCommandBarSubItem20.Name = "spreadsheetCommandBarSubItem20";
            // 
            // spreadsheetCommandBarButtonItem115
            // 
            this.spreadsheetCommandBarButtonItem115.CommandName = "ArrangeBringForward";
            this.spreadsheetCommandBarButtonItem115.Id = 189;
            this.spreadsheetCommandBarButtonItem115.Name = "spreadsheetCommandBarButtonItem115";
            // 
            // spreadsheetCommandBarButtonItem116
            // 
            this.spreadsheetCommandBarButtonItem116.CommandName = "ArrangeBringToFront";
            this.spreadsheetCommandBarButtonItem116.Id = 190;
            this.spreadsheetCommandBarButtonItem116.Name = "spreadsheetCommandBarButtonItem116";
            // 
            // spreadsheetCommandBarSubItem21
            // 
            this.spreadsheetCommandBarSubItem21.CommandName = "ArrangeSendBackwardCommandGroup";
            this.spreadsheetCommandBarSubItem21.Id = 191;
            this.spreadsheetCommandBarSubItem21.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem117),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem118)});
            this.spreadsheetCommandBarSubItem21.Name = "spreadsheetCommandBarSubItem21";
            // 
            // spreadsheetCommandBarButtonItem117
            // 
            this.spreadsheetCommandBarButtonItem117.CommandName = "ArrangeSendBackward";
            this.spreadsheetCommandBarButtonItem117.Id = 192;
            this.spreadsheetCommandBarButtonItem117.Name = "spreadsheetCommandBarButtonItem117";
            // 
            // spreadsheetCommandBarButtonItem118
            // 
            this.spreadsheetCommandBarButtonItem118.CommandName = "ArrangeSendToBack";
            this.spreadsheetCommandBarButtonItem118.Id = 193;
            this.spreadsheetCommandBarButtonItem118.Name = "spreadsheetCommandBarButtonItem118";
            // 
            // functionLibraryRibbonPageGroup1
            // 
            this.functionLibraryRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem22);
            this.functionLibraryRibbonPageGroup1.ItemLinks.Add(this.functionsFinancialItem1);
            this.functionLibraryRibbonPageGroup1.ItemLinks.Add(this.functionsLogicalItem1);
            this.functionLibraryRibbonPageGroup1.ItemLinks.Add(this.functionsTextItem1);
            this.functionLibraryRibbonPageGroup1.ItemLinks.Add(this.functionsDateAndTimeItem1);
            this.functionLibraryRibbonPageGroup1.ItemLinks.Add(this.functionsLookupAndReferenceItem1);
            this.functionLibraryRibbonPageGroup1.ItemLinks.Add(this.functionsMathAndTrigonometryItem1);
            this.functionLibraryRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem23);
            this.functionLibraryRibbonPageGroup1.Name = "functionLibraryRibbonPageGroup1";
            // 
            // formulasRibbonPage1
            // 
            this.formulasRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.functionLibraryRibbonPageGroup1,
            this.formulaDefinedNamesRibbonPageGroup1,
            this.formulaAuditingRibbonPageGroup1,
            this.formulaCalculationRibbonPageGroup1});
            this.formulasRibbonPage1.Name = "formulasRibbonPage1";
            // 
            // spreadsheetCommandBarSubItem22
            // 
            this.spreadsheetCommandBarSubItem22.CommandName = "FunctionsAutoSumCommandGroup";
            this.spreadsheetCommandBarSubItem22.Id = 194;
            this.spreadsheetCommandBarSubItem22.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem80),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem81),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem82),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem83),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem84)});
            this.spreadsheetCommandBarSubItem22.Name = "spreadsheetCommandBarSubItem22";
            // 
            // spreadsheetCommandBarButtonItem119
            // 
            this.spreadsheetCommandBarButtonItem119.CommandName = "FunctionsInsertSum";
            this.spreadsheetCommandBarButtonItem119.Id = -1;
            this.spreadsheetCommandBarButtonItem119.Name = "spreadsheetCommandBarButtonItem119";
            // 
            // spreadsheetCommandBarButtonItem120
            // 
            this.spreadsheetCommandBarButtonItem120.CommandName = "FunctionsInsertAverage";
            this.spreadsheetCommandBarButtonItem120.Id = -1;
            this.spreadsheetCommandBarButtonItem120.Name = "spreadsheetCommandBarButtonItem120";
            // 
            // spreadsheetCommandBarButtonItem121
            // 
            this.spreadsheetCommandBarButtonItem121.CommandName = "FunctionsInsertCountNumbers";
            this.spreadsheetCommandBarButtonItem121.Id = -1;
            this.spreadsheetCommandBarButtonItem121.Name = "spreadsheetCommandBarButtonItem121";
            // 
            // spreadsheetCommandBarButtonItem122
            // 
            this.spreadsheetCommandBarButtonItem122.CommandName = "FunctionsInsertMax";
            this.spreadsheetCommandBarButtonItem122.Id = -1;
            this.spreadsheetCommandBarButtonItem122.Name = "spreadsheetCommandBarButtonItem122";
            // 
            // spreadsheetCommandBarButtonItem123
            // 
            this.spreadsheetCommandBarButtonItem123.CommandName = "FunctionsInsertMin";
            this.spreadsheetCommandBarButtonItem123.Id = -1;
            this.spreadsheetCommandBarButtonItem123.Name = "spreadsheetCommandBarButtonItem123";
            // 
            // functionsFinancialItem1
            // 
            this.functionsFinancialItem1.Id = 195;
            this.functionsFinancialItem1.Name = "functionsFinancialItem1";
            // 
            // functionsLogicalItem1
            // 
            this.functionsLogicalItem1.Id = 196;
            this.functionsLogicalItem1.Name = "functionsLogicalItem1";
            // 
            // functionsTextItem1
            // 
            this.functionsTextItem1.Id = 197;
            this.functionsTextItem1.Name = "functionsTextItem1";
            // 
            // functionsDateAndTimeItem1
            // 
            this.functionsDateAndTimeItem1.Id = 198;
            this.functionsDateAndTimeItem1.Name = "functionsDateAndTimeItem1";
            // 
            // functionsLookupAndReferenceItem1
            // 
            this.functionsLookupAndReferenceItem1.Id = 199;
            this.functionsLookupAndReferenceItem1.Name = "functionsLookupAndReferenceItem1";
            // 
            // functionsMathAndTrigonometryItem1
            // 
            this.functionsMathAndTrigonometryItem1.Id = 200;
            this.functionsMathAndTrigonometryItem1.Name = "functionsMathAndTrigonometryItem1";
            // 
            // spreadsheetCommandBarSubItem23
            // 
            this.spreadsheetCommandBarSubItem23.CommandName = "FunctionsMoreCommandGroup";
            this.spreadsheetCommandBarSubItem23.Id = 201;
            this.spreadsheetCommandBarSubItem23.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.functionsStatisticalItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.functionsEngineeringItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.functionsInformationItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.functionsCompatibilityItem1),
            new DevExpress.XtraBars.LinkPersistInfo(this.functionsWebItem1)});
            this.spreadsheetCommandBarSubItem23.Name = "spreadsheetCommandBarSubItem23";
            // 
            // functionsStatisticalItem1
            // 
            this.functionsStatisticalItem1.Id = 202;
            this.functionsStatisticalItem1.Name = "functionsStatisticalItem1";
            // 
            // functionsEngineeringItem1
            // 
            this.functionsEngineeringItem1.Id = 203;
            this.functionsEngineeringItem1.Name = "functionsEngineeringItem1";
            // 
            // functionsInformationItem1
            // 
            this.functionsInformationItem1.Id = 204;
            this.functionsInformationItem1.Name = "functionsInformationItem1";
            // 
            // functionsCompatibilityItem1
            // 
            this.functionsCompatibilityItem1.Id = 205;
            this.functionsCompatibilityItem1.Name = "functionsCompatibilityItem1";
            // 
            // functionsWebItem1
            // 
            this.functionsWebItem1.Id = 206;
            this.functionsWebItem1.Name = "functionsWebItem1";
            // 
            // formulaDefinedNamesRibbonPageGroup1
            // 
            this.formulaDefinedNamesRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem124);
            this.formulaDefinedNamesRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem125);
            this.formulaDefinedNamesRibbonPageGroup1.ItemLinks.Add(this.definedNameListItem1);
            this.formulaDefinedNamesRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem126);
            this.formulaDefinedNamesRibbonPageGroup1.Name = "formulaDefinedNamesRibbonPageGroup1";
            // 
            // spreadsheetCommandBarButtonItem124
            // 
            this.spreadsheetCommandBarButtonItem124.CommandName = "FormulasShowNameManager";
            this.spreadsheetCommandBarButtonItem124.Id = 207;
            this.spreadsheetCommandBarButtonItem124.Name = "spreadsheetCommandBarButtonItem124";
            // 
            // spreadsheetCommandBarButtonItem125
            // 
            this.spreadsheetCommandBarButtonItem125.CommandName = "FormulasDefineNameCommand";
            this.spreadsheetCommandBarButtonItem125.Id = 208;
            this.spreadsheetCommandBarButtonItem125.Name = "spreadsheetCommandBarButtonItem125";
            this.spreadsheetCommandBarButtonItem125.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // definedNameListItem1
            // 
            this.definedNameListItem1.Id = 209;
            this.definedNameListItem1.Name = "definedNameListItem1";
            this.definedNameListItem1.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // spreadsheetCommandBarButtonItem126
            // 
            this.spreadsheetCommandBarButtonItem126.CommandName = "FormulasCreateDefinedNamesFromSelection";
            this.spreadsheetCommandBarButtonItem126.Id = 210;
            this.spreadsheetCommandBarButtonItem126.Name = "spreadsheetCommandBarButtonItem126";
            this.spreadsheetCommandBarButtonItem126.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // formulaAuditingRibbonPageGroup1
            // 
            this.formulaAuditingRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarCheckItem24);
            this.formulaAuditingRibbonPageGroup1.Name = "formulaAuditingRibbonPageGroup1";
            // 
            // spreadsheetCommandBarCheckItem24
            // 
            this.spreadsheetCommandBarCheckItem24.CommandName = "ViewShowFormulas";
            this.spreadsheetCommandBarCheckItem24.Id = 211;
            this.spreadsheetCommandBarCheckItem24.Name = "spreadsheetCommandBarCheckItem24";
            // 
            // formulaCalculationRibbonPageGroup1
            // 
            this.formulaCalculationRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem24);
            this.formulaCalculationRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem127);
            this.formulaCalculationRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem128);
            this.formulaCalculationRibbonPageGroup1.Name = "formulaCalculationRibbonPageGroup1";
            // 
            // spreadsheetCommandBarSubItem24
            // 
            this.spreadsheetCommandBarSubItem24.CommandName = "FormulasCalculationOptionsCommandGroup";
            this.spreadsheetCommandBarSubItem24.Id = 212;
            this.spreadsheetCommandBarSubItem24.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarCheckItem25),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarCheckItem26)});
            this.spreadsheetCommandBarSubItem24.Name = "spreadsheetCommandBarSubItem24";
            // 
            // spreadsheetCommandBarCheckItem25
            // 
            this.spreadsheetCommandBarCheckItem25.CommandName = "FormulasCalculationModeAutomatic";
            this.spreadsheetCommandBarCheckItem25.Id = 213;
            this.spreadsheetCommandBarCheckItem25.Name = "spreadsheetCommandBarCheckItem25";
            // 
            // spreadsheetCommandBarCheckItem26
            // 
            this.spreadsheetCommandBarCheckItem26.CommandName = "FormulasCalculationModeManual";
            this.spreadsheetCommandBarCheckItem26.Id = 214;
            this.spreadsheetCommandBarCheckItem26.Name = "spreadsheetCommandBarCheckItem26";
            // 
            // spreadsheetCommandBarButtonItem127
            // 
            this.spreadsheetCommandBarButtonItem127.CommandName = "FormulasCalculateNow";
            this.spreadsheetCommandBarButtonItem127.Id = 215;
            this.spreadsheetCommandBarButtonItem127.Name = "spreadsheetCommandBarButtonItem127";
            this.spreadsheetCommandBarButtonItem127.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // spreadsheetCommandBarButtonItem128
            // 
            this.spreadsheetCommandBarButtonItem128.CommandName = "FormulasCalculateSheet";
            this.spreadsheetCommandBarButtonItem128.Id = 216;
            this.spreadsheetCommandBarButtonItem128.Name = "spreadsheetCommandBarButtonItem128";
            this.spreadsheetCommandBarButtonItem128.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // sortAndFilterRibbonPageGroup1
            // 
            this.sortAndFilterRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem95);
            this.sortAndFilterRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem96);
            this.sortAndFilterRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarCheckItem14);
            this.sortAndFilterRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem97);
            this.sortAndFilterRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem98);
            this.sortAndFilterRibbonPageGroup1.Name = "sortAndFilterRibbonPageGroup1";
            // 
            // dataRibbonPage1
            // 
            this.dataRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.sortAndFilterRibbonPageGroup1,
            this.dataToolsRibbonPageGroup1,
            this.outlineRibbonPageGroup1});
            this.dataRibbonPage1.Name = "dataRibbonPage1";
            // 
            // dataToolsRibbonPageGroup1
            // 
            this.dataToolsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem25);
            this.dataToolsRibbonPageGroup1.Name = "dataToolsRibbonPageGroup1";
            // 
            // spreadsheetCommandBarSubItem25
            // 
            this.spreadsheetCommandBarSubItem25.CommandName = "DataToolsDataValidationCommandGroup";
            this.spreadsheetCommandBarSubItem25.Id = 217;
            this.spreadsheetCommandBarSubItem25.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem129),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem130),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem131)});
            this.spreadsheetCommandBarSubItem25.Name = "spreadsheetCommandBarSubItem25";
            // 
            // spreadsheetCommandBarButtonItem129
            // 
            this.spreadsheetCommandBarButtonItem129.CommandName = "DataToolsDataValidation";
            this.spreadsheetCommandBarButtonItem129.Id = 218;
            this.spreadsheetCommandBarButtonItem129.Name = "spreadsheetCommandBarButtonItem129";
            // 
            // spreadsheetCommandBarButtonItem130
            // 
            this.spreadsheetCommandBarButtonItem130.CommandName = "DataToolsCircleInvalidData";
            this.spreadsheetCommandBarButtonItem130.Id = 219;
            this.spreadsheetCommandBarButtonItem130.Name = "spreadsheetCommandBarButtonItem130";
            // 
            // spreadsheetCommandBarButtonItem131
            // 
            this.spreadsheetCommandBarButtonItem131.CommandName = "DataToolsClearValidationCircles";
            this.spreadsheetCommandBarButtonItem131.Id = 220;
            this.spreadsheetCommandBarButtonItem131.Name = "spreadsheetCommandBarButtonItem131";
            // 
            // outlineRibbonPageGroup1
            // 
            this.outlineRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem26);
            this.outlineRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem27);
            this.outlineRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem136);
            this.outlineRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem137);
            this.outlineRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem138);
            this.outlineRibbonPageGroup1.Name = "outlineRibbonPageGroup1";
            // 
            // spreadsheetCommandBarSubItem26
            // 
            this.spreadsheetCommandBarSubItem26.CommandName = "OutlineGroupCommandGroup";
            this.spreadsheetCommandBarSubItem26.Id = 221;
            this.spreadsheetCommandBarSubItem26.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem132),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem133)});
            this.spreadsheetCommandBarSubItem26.Name = "spreadsheetCommandBarSubItem26";
            this.spreadsheetCommandBarSubItem26.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem132
            // 
            this.spreadsheetCommandBarButtonItem132.CommandName = "GroupOutline";
            this.spreadsheetCommandBarButtonItem132.Id = 222;
            this.spreadsheetCommandBarButtonItem132.Name = "spreadsheetCommandBarButtonItem132";
            // 
            // spreadsheetCommandBarButtonItem133
            // 
            this.spreadsheetCommandBarButtonItem133.CommandName = "AutoOutline";
            this.spreadsheetCommandBarButtonItem133.Id = 223;
            this.spreadsheetCommandBarButtonItem133.Name = "spreadsheetCommandBarButtonItem133";
            // 
            // spreadsheetCommandBarSubItem27
            // 
            this.spreadsheetCommandBarSubItem27.CommandName = "OutlineUngroupCommandGroup";
            this.spreadsheetCommandBarSubItem27.Id = 224;
            this.spreadsheetCommandBarSubItem27.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem134),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem135)});
            this.spreadsheetCommandBarSubItem27.Name = "spreadsheetCommandBarSubItem27";
            this.spreadsheetCommandBarSubItem27.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem134
            // 
            this.spreadsheetCommandBarButtonItem134.CommandName = "UngroupOutline";
            this.spreadsheetCommandBarButtonItem134.Id = 225;
            this.spreadsheetCommandBarButtonItem134.Name = "spreadsheetCommandBarButtonItem134";
            // 
            // spreadsheetCommandBarButtonItem135
            // 
            this.spreadsheetCommandBarButtonItem135.CommandName = "ClearOutline";
            this.spreadsheetCommandBarButtonItem135.Id = 226;
            this.spreadsheetCommandBarButtonItem135.Name = "spreadsheetCommandBarButtonItem135";
            // 
            // spreadsheetCommandBarButtonItem136
            // 
            this.spreadsheetCommandBarButtonItem136.CommandName = "Subtotal";
            this.spreadsheetCommandBarButtonItem136.Id = 227;
            this.spreadsheetCommandBarButtonItem136.Name = "spreadsheetCommandBarButtonItem136";
            this.spreadsheetCommandBarButtonItem136.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem137
            // 
            this.spreadsheetCommandBarButtonItem137.CommandName = "ShowDetail";
            this.spreadsheetCommandBarButtonItem137.Id = 228;
            this.spreadsheetCommandBarButtonItem137.Name = "spreadsheetCommandBarButtonItem137";
            this.spreadsheetCommandBarButtonItem137.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // spreadsheetCommandBarButtonItem138
            // 
            this.spreadsheetCommandBarButtonItem138.CommandName = "HideDetail";
            this.spreadsheetCommandBarButtonItem138.Id = 229;
            this.spreadsheetCommandBarButtonItem138.Name = "spreadsheetCommandBarButtonItem138";
            this.spreadsheetCommandBarButtonItem138.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // commentsRibbonPageGroup1
            // 
            this.commentsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem139);
            this.commentsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem140);
            this.commentsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem141);
            this.commentsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem142);
            this.commentsRibbonPageGroup1.Name = "commentsRibbonPageGroup1";
            // 
            // reviewRibbonPage1
            // 
            this.reviewRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.commentsRibbonPageGroup1,
            this.changesRibbonPageGroup1});
            this.reviewRibbonPage1.Name = "reviewRibbonPage1";
            // 
            // spreadsheetCommandBarButtonItem139
            // 
            this.spreadsheetCommandBarButtonItem139.CommandName = "ReviewInsertComment";
            this.spreadsheetCommandBarButtonItem139.Id = 230;
            this.spreadsheetCommandBarButtonItem139.Name = "spreadsheetCommandBarButtonItem139";
            // 
            // spreadsheetCommandBarButtonItem140
            // 
            this.spreadsheetCommandBarButtonItem140.CommandName = "ReviewEditComment";
            this.spreadsheetCommandBarButtonItem140.Id = 231;
            this.spreadsheetCommandBarButtonItem140.Name = "spreadsheetCommandBarButtonItem140";
            // 
            // spreadsheetCommandBarButtonItem141
            // 
            this.spreadsheetCommandBarButtonItem141.CommandName = "ReviewDeleteComment";
            this.spreadsheetCommandBarButtonItem141.Id = 232;
            this.spreadsheetCommandBarButtonItem141.Name = "spreadsheetCommandBarButtonItem141";
            // 
            // spreadsheetCommandBarButtonItem142
            // 
            this.spreadsheetCommandBarButtonItem142.CommandName = "ReviewShowHideComment";
            this.spreadsheetCommandBarButtonItem142.Id = 233;
            this.spreadsheetCommandBarButtonItem142.Name = "spreadsheetCommandBarButtonItem142";
            this.spreadsheetCommandBarButtonItem142.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // changesRibbonPageGroup1
            // 
            this.changesRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem78);
            this.changesRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem143);
            this.changesRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem144);
            this.changesRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem145);
            this.changesRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem146);
            this.changesRibbonPageGroup1.Name = "changesRibbonPageGroup1";
            // 
            // spreadsheetCommandBarButtonItem143
            // 
            this.spreadsheetCommandBarButtonItem143.CommandName = "ReviewUnprotectSheet";
            this.spreadsheetCommandBarButtonItem143.Id = 234;
            this.spreadsheetCommandBarButtonItem143.Name = "spreadsheetCommandBarButtonItem143";
            // 
            // spreadsheetCommandBarButtonItem144
            // 
            this.spreadsheetCommandBarButtonItem144.CommandName = "ReviewProtectWorkbook";
            this.spreadsheetCommandBarButtonItem144.Id = 235;
            this.spreadsheetCommandBarButtonItem144.Name = "spreadsheetCommandBarButtonItem144";
            // 
            // spreadsheetCommandBarButtonItem145
            // 
            this.spreadsheetCommandBarButtonItem145.CommandName = "ReviewUnprotectWorkbook";
            this.spreadsheetCommandBarButtonItem145.Id = 236;
            this.spreadsheetCommandBarButtonItem145.Name = "spreadsheetCommandBarButtonItem145";
            // 
            // spreadsheetCommandBarButtonItem146
            // 
            this.spreadsheetCommandBarButtonItem146.CommandName = "ReviewShowProtectedRangeManager";
            this.spreadsheetCommandBarButtonItem146.Id = 237;
            this.spreadsheetCommandBarButtonItem146.Name = "spreadsheetCommandBarButtonItem146";
            // 
            // showRibbonPageGroup1
            // 
            this.showRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarCheckItem20);
            this.showRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarCheckItem21);
            this.showRibbonPageGroup1.Name = "showRibbonPageGroup1";
            // 
            // viewRibbonPage1
            // 
            this.viewRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.showRibbonPageGroup1,
            this.zoomRibbonPageGroup1,
            this.windowRibbonPageGroup1});
            this.viewRibbonPage1.Name = "viewRibbonPage1";
            // 
            // zoomRibbonPageGroup1
            // 
            this.zoomRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem147);
            this.zoomRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem148);
            this.zoomRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem149);
            this.zoomRibbonPageGroup1.Name = "zoomRibbonPageGroup1";
            // 
            // spreadsheetCommandBarButtonItem147
            // 
            this.spreadsheetCommandBarButtonItem147.CommandName = "ViewZoomOut";
            this.spreadsheetCommandBarButtonItem147.Id = 238;
            this.spreadsheetCommandBarButtonItem147.Name = "spreadsheetCommandBarButtonItem147";
            // 
            // spreadsheetCommandBarButtonItem148
            // 
            this.spreadsheetCommandBarButtonItem148.CommandName = "ViewZoomIn";
            this.spreadsheetCommandBarButtonItem148.Id = 239;
            this.spreadsheetCommandBarButtonItem148.Name = "spreadsheetCommandBarButtonItem148";
            // 
            // spreadsheetCommandBarButtonItem149
            // 
            this.spreadsheetCommandBarButtonItem149.CommandName = "ViewZoom100Percent";
            this.spreadsheetCommandBarButtonItem149.Id = 240;
            this.spreadsheetCommandBarButtonItem149.Name = "spreadsheetCommandBarButtonItem149";
            // 
            // windowRibbonPageGroup1
            // 
            this.windowRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem28);
            this.windowRibbonPageGroup1.Name = "windowRibbonPageGroup1";
            // 
            // spreadsheetCommandBarSubItem28
            // 
            this.spreadsheetCommandBarSubItem28.CommandName = "ViewFreezePanesCommandGroup";
            this.spreadsheetCommandBarSubItem28.Id = 241;
            this.spreadsheetCommandBarSubItem28.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem150),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem151),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem152),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem153)});
            this.spreadsheetCommandBarSubItem28.Name = "spreadsheetCommandBarSubItem28";
            // 
            // spreadsheetCommandBarButtonItem150
            // 
            this.spreadsheetCommandBarButtonItem150.CommandName = "ViewFreezePanes";
            this.spreadsheetCommandBarButtonItem150.Id = 242;
            this.spreadsheetCommandBarButtonItem150.Name = "spreadsheetCommandBarButtonItem150";
            // 
            // spreadsheetCommandBarButtonItem151
            // 
            this.spreadsheetCommandBarButtonItem151.CommandName = "ViewUnfreezePanes";
            this.spreadsheetCommandBarButtonItem151.Id = 243;
            this.spreadsheetCommandBarButtonItem151.Name = "spreadsheetCommandBarButtonItem151";
            // 
            // spreadsheetCommandBarButtonItem152
            // 
            this.spreadsheetCommandBarButtonItem152.CommandName = "ViewFreezeTopRow";
            this.spreadsheetCommandBarButtonItem152.Id = 244;
            this.spreadsheetCommandBarButtonItem152.Name = "spreadsheetCommandBarButtonItem152";
            // 
            // spreadsheetCommandBarButtonItem153
            // 
            this.spreadsheetCommandBarButtonItem153.CommandName = "ViewFreezeFirstColumn";
            this.spreadsheetCommandBarButtonItem153.Id = 245;
            this.spreadsheetCommandBarButtonItem153.Name = "spreadsheetCommandBarButtonItem153";
            // 
            // chartsDesignTypeRibbonPageGroup1
            // 
            this.chartsDesignTypeRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem154);
            this.chartsDesignTypeRibbonPageGroup1.Name = "chartsDesignTypeRibbonPageGroup1";
            // 
            // chartsDesignRibbonPage1
            // 
            this.chartsDesignRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.chartsDesignTypeRibbonPageGroup1,
            this.chartsDesignDataRibbonPageGroup1,
            this.chartsDesignLayoutsRibbonPageGroup1,
            this.chartsDesignStylesRibbonPageGroup1});
            this.chartsDesignRibbonPage1.Name = "chartsDesignRibbonPage1";
            this.chartsDesignRibbonPage1.Visible = false;
            // 
            // chartToolsRibbonPageCategory1
            // 
            this.chartToolsRibbonPageCategory1.Control = this.SpreadSheet;
            this.chartToolsRibbonPageCategory1.Name = "chartToolsRibbonPageCategory1";
            this.chartToolsRibbonPageCategory1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.chartsDesignRibbonPage1,
            this.chartsLayoutRibbonPage1,
            this.chartsFormatRibbonPage1});
            this.chartToolsRibbonPageCategory1.Visible = false;
            // 
            // spreadsheetCommandBarButtonItem154
            // 
            this.spreadsheetCommandBarButtonItem154.CommandName = "ChartChangeType";
            this.spreadsheetCommandBarButtonItem154.Id = 246;
            this.spreadsheetCommandBarButtonItem154.Name = "spreadsheetCommandBarButtonItem154";
            // 
            // chartsDesignDataRibbonPageGroup1
            // 
            this.chartsDesignDataRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem155);
            this.chartsDesignDataRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem156);
            this.chartsDesignDataRibbonPageGroup1.Name = "chartsDesignDataRibbonPageGroup1";
            // 
            // spreadsheetCommandBarButtonItem155
            // 
            this.spreadsheetCommandBarButtonItem155.CommandName = "ChartSwitchRowColumn";
            this.spreadsheetCommandBarButtonItem155.Id = 247;
            this.spreadsheetCommandBarButtonItem155.Name = "spreadsheetCommandBarButtonItem155";
            // 
            // spreadsheetCommandBarButtonItem156
            // 
            this.spreadsheetCommandBarButtonItem156.CommandName = "ChartSelectData";
            this.spreadsheetCommandBarButtonItem156.Id = 248;
            this.spreadsheetCommandBarButtonItem156.Name = "spreadsheetCommandBarButtonItem156";
            // 
            // chartsDesignLayoutsRibbonPageGroup1
            // 
            this.chartsDesignLayoutsRibbonPageGroup1.ItemLinks.Add(this.galleryChartLayoutItem1);
            this.chartsDesignLayoutsRibbonPageGroup1.Name = "chartsDesignLayoutsRibbonPageGroup1";
            // 
            // galleryChartLayoutItem1
            // 
            // 
            // 
            // 
            this.galleryChartLayoutItem1.Gallery.ColumnCount = 6;
            this.galleryChartLayoutItem1.Gallery.DrawImageBackground = false;
            this.galleryChartLayoutItem1.Gallery.ImageSize = new System.Drawing.Size(48, 48);
            this.galleryChartLayoutItem1.Gallery.RowCount = 2;
            this.galleryChartLayoutItem1.Id = 249;
            this.galleryChartLayoutItem1.Name = "galleryChartLayoutItem1";
            // 
            // chartsDesignStylesRibbonPageGroup1
            // 
            this.chartsDesignStylesRibbonPageGroup1.ItemLinks.Add(this.galleryChartStyleItem1);
            this.chartsDesignStylesRibbonPageGroup1.Name = "chartsDesignStylesRibbonPageGroup1";
            // 
            // galleryChartStyleItem1
            // 
            // 
            // 
            // 
            this.galleryChartStyleItem1.Gallery.ColumnCount = 8;
            this.galleryChartStyleItem1.Gallery.DrawImageBackground = false;
            this.galleryChartStyleItem1.Gallery.ImageSize = new System.Drawing.Size(65, 46);
            this.galleryChartStyleItem1.Gallery.ItemAutoSizeMode = DevExpress.XtraBars.Ribbon.Gallery.GalleryItemAutoSizeMode.None;
            this.galleryChartStyleItem1.Gallery.ItemSize = new System.Drawing.Size(93, 56);
            this.galleryChartStyleItem1.Gallery.MinimumColumnCount = 4;
            this.galleryChartStyleItem1.Gallery.RowCount = 6;
            this.galleryChartStyleItem1.Id = 250;
            this.galleryChartStyleItem1.Name = "galleryChartStyleItem1";
            // 
            // chartsLayoutLabelsRibbonPageGroup1
            // 
            this.chartsLayoutLabelsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem11);
            this.chartsLayoutLabelsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem29);
            this.chartsLayoutLabelsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem14);
            this.chartsLayoutLabelsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem15);
            this.chartsLayoutLabelsRibbonPageGroup1.Name = "chartsLayoutLabelsRibbonPageGroup1";
            // 
            // chartsLayoutRibbonPage1
            // 
            this.chartsLayoutRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.chartsLayoutLabelsRibbonPageGroup1,
            this.chartsLayoutAxesRibbonPageGroup1,
            this.chartsLayoutAnalysisRibbonPageGroup1});
            this.chartsLayoutRibbonPage1.Name = "chartsLayoutRibbonPage1";
            this.chartsLayoutRibbonPage1.Visible = false;
            // 
            // spreadsheetCommandBarButtonGalleryDropDownItem11
            // 
            this.spreadsheetCommandBarButtonGalleryDropDownItem11.CommandName = "ChartTitleCommandGroup";
            this.spreadsheetCommandBarButtonGalleryDropDownItem11.DropDownControl = this.commandBarGalleryDropDown13;
            this.spreadsheetCommandBarButtonGalleryDropDownItem11.Id = 251;
            this.spreadsheetCommandBarButtonGalleryDropDownItem11.Name = "spreadsheetCommandBarButtonGalleryDropDownItem11";
            // 
            // commandBarGalleryDropDown13
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown13.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Both;
            this.commandBarGalleryDropDown13.Gallery.ColumnCount = 1;
            spreadsheetCommandGalleryItemGroup29.CommandName = "ChartTitleCommandGroup";
            spreadsheetCommandGalleryItem123.CommandName = "ChartTitleNone";
            spreadsheetCommandGalleryItem124.CommandName = "ChartTitleCenteredOverlay";
            spreadsheetCommandGalleryItem125.CommandName = "ChartTitleAbove";
            spreadsheetCommandGalleryItemGroup29.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem123,
            spreadsheetCommandGalleryItem124,
            spreadsheetCommandGalleryItem125});
            this.commandBarGalleryDropDown13.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            spreadsheetCommandGalleryItemGroup29});
            this.commandBarGalleryDropDown13.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft;
            this.commandBarGalleryDropDown13.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left;
            this.commandBarGalleryDropDown13.Gallery.ShowGroupCaption = false;
            this.commandBarGalleryDropDown13.Gallery.ShowItemText = true;
            this.commandBarGalleryDropDown13.Name = "commandBarGalleryDropDown13";
            this.commandBarGalleryDropDown13.Ribbon = this.ribbonControl1;
            // 
            // spreadsheetCommandBarSubItem29
            // 
            this.spreadsheetCommandBarSubItem29.CommandName = "ChartAxisTitlesCommandGroup";
            this.spreadsheetCommandBarSubItem29.Id = 252;
            this.spreadsheetCommandBarSubItem29.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonGalleryDropDownItem12),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonGalleryDropDownItem13)});
            this.spreadsheetCommandBarSubItem29.Name = "spreadsheetCommandBarSubItem29";
            // 
            // spreadsheetCommandBarButtonGalleryDropDownItem12
            // 
            this.spreadsheetCommandBarButtonGalleryDropDownItem12.CommandName = "ChartPrimaryHorizontalAxisTitleCommandGroup";
            this.spreadsheetCommandBarButtonGalleryDropDownItem12.DropDownControl = this.commandBarGalleryDropDown14;
            this.spreadsheetCommandBarButtonGalleryDropDownItem12.Id = 253;
            this.spreadsheetCommandBarButtonGalleryDropDownItem12.Name = "spreadsheetCommandBarButtonGalleryDropDownItem12";
            // 
            // commandBarGalleryDropDown14
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown14.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Both;
            this.commandBarGalleryDropDown14.Gallery.ColumnCount = 1;
            spreadsheetCommandGalleryItemGroup30.CommandName = "ChartPrimaryHorizontalAxisTitleCommandGroup";
            spreadsheetCommandGalleryItem126.CommandName = "ChartPrimaryHorizontalAxisTitleNone";
            spreadsheetCommandGalleryItem127.CommandName = "ChartPrimaryHorizontalAxisTitleBelow";
            spreadsheetCommandGalleryItemGroup30.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem126,
            spreadsheetCommandGalleryItem127});
            this.commandBarGalleryDropDown14.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            spreadsheetCommandGalleryItemGroup30});
            this.commandBarGalleryDropDown14.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft;
            this.commandBarGalleryDropDown14.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left;
            this.commandBarGalleryDropDown14.Gallery.RowCount = 2;
            this.commandBarGalleryDropDown14.Gallery.ShowGroupCaption = false;
            this.commandBarGalleryDropDown14.Gallery.ShowItemText = true;
            this.commandBarGalleryDropDown14.Name = "commandBarGalleryDropDown14";
            this.commandBarGalleryDropDown14.Ribbon = this.ribbonControl1;
            // 
            // spreadsheetCommandBarButtonGalleryDropDownItem13
            // 
            this.spreadsheetCommandBarButtonGalleryDropDownItem13.CommandName = "ChartPrimaryVerticalAxisTitleCommandGroup";
            this.spreadsheetCommandBarButtonGalleryDropDownItem13.DropDownControl = this.commandBarGalleryDropDown15;
            this.spreadsheetCommandBarButtonGalleryDropDownItem13.Id = 254;
            this.spreadsheetCommandBarButtonGalleryDropDownItem13.Name = "spreadsheetCommandBarButtonGalleryDropDownItem13";
            // 
            // commandBarGalleryDropDown15
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown15.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Both;
            this.commandBarGalleryDropDown15.Gallery.ColumnCount = 1;
            spreadsheetCommandGalleryItemGroup31.CommandName = "ChartPrimaryVerticalAxisTitleCommandGroup";
            spreadsheetCommandGalleryItem128.CommandName = "ChartPrimaryVerticalAxisTitleNone";
            spreadsheetCommandGalleryItem129.CommandName = "ChartPrimaryVerticalAxisTitleRotated";
            spreadsheetCommandGalleryItem130.CommandName = "ChartPrimaryVerticalAxisTitleVertical";
            spreadsheetCommandGalleryItem131.CommandName = "ChartPrimaryVerticalAxisTitleHorizontal";
            spreadsheetCommandGalleryItemGroup31.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem128,
            spreadsheetCommandGalleryItem129,
            spreadsheetCommandGalleryItem130,
            spreadsheetCommandGalleryItem131});
            this.commandBarGalleryDropDown15.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            spreadsheetCommandGalleryItemGroup31});
            this.commandBarGalleryDropDown15.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft;
            this.commandBarGalleryDropDown15.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left;
            this.commandBarGalleryDropDown15.Gallery.RowCount = 4;
            this.commandBarGalleryDropDown15.Gallery.ShowGroupCaption = false;
            this.commandBarGalleryDropDown15.Gallery.ShowItemText = true;
            this.commandBarGalleryDropDown15.Name = "commandBarGalleryDropDown15";
            this.commandBarGalleryDropDown15.Ribbon = this.ribbonControl1;
            // 
            // spreadsheetCommandBarButtonGalleryDropDownItem14
            // 
            this.spreadsheetCommandBarButtonGalleryDropDownItem14.CommandName = "ChartLegendCommandGroup";
            this.spreadsheetCommandBarButtonGalleryDropDownItem14.DropDownControl = this.commandBarGalleryDropDown16;
            this.spreadsheetCommandBarButtonGalleryDropDownItem14.Id = 255;
            this.spreadsheetCommandBarButtonGalleryDropDownItem14.Name = "spreadsheetCommandBarButtonGalleryDropDownItem14";
            // 
            // commandBarGalleryDropDown16
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown16.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Both;
            this.commandBarGalleryDropDown16.Gallery.ColumnCount = 1;
            spreadsheetCommandGalleryItemGroup32.CommandName = "ChartLegendCommandGroup";
            spreadsheetCommandGalleryItem132.CommandName = "ChartLegendNone";
            spreadsheetCommandGalleryItem133.CommandName = "ChartLegendAtRight";
            spreadsheetCommandGalleryItem134.CommandName = "ChartLegendAtTop";
            spreadsheetCommandGalleryItem135.CommandName = "ChartLegendAtLeft";
            spreadsheetCommandGalleryItem136.CommandName = "ChartLegendAtBottom";
            spreadsheetCommandGalleryItem137.CommandName = "ChartLegendOverlayAtRight";
            spreadsheetCommandGalleryItem138.CommandName = "ChartLegendOverlayAtLeft";
            spreadsheetCommandGalleryItemGroup32.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem132,
            spreadsheetCommandGalleryItem133,
            spreadsheetCommandGalleryItem134,
            spreadsheetCommandGalleryItem135,
            spreadsheetCommandGalleryItem136,
            spreadsheetCommandGalleryItem137,
            spreadsheetCommandGalleryItem138});
            this.commandBarGalleryDropDown16.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            spreadsheetCommandGalleryItemGroup32});
            this.commandBarGalleryDropDown16.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft;
            this.commandBarGalleryDropDown16.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left;
            this.commandBarGalleryDropDown16.Gallery.RowCount = 7;
            this.commandBarGalleryDropDown16.Gallery.ShowGroupCaption = false;
            this.commandBarGalleryDropDown16.Gallery.ShowItemText = true;
            this.commandBarGalleryDropDown16.Name = "commandBarGalleryDropDown16";
            this.commandBarGalleryDropDown16.Ribbon = this.ribbonControl1;
            // 
            // spreadsheetCommandBarButtonGalleryDropDownItem15
            // 
            this.spreadsheetCommandBarButtonGalleryDropDownItem15.CommandName = "ChartDataLabelsCommandGroup";
            this.spreadsheetCommandBarButtonGalleryDropDownItem15.DropDownControl = this.commandBarGalleryDropDown17;
            this.spreadsheetCommandBarButtonGalleryDropDownItem15.Id = 256;
            this.spreadsheetCommandBarButtonGalleryDropDownItem15.Name = "spreadsheetCommandBarButtonGalleryDropDownItem15";
            // 
            // commandBarGalleryDropDown17
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown17.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Both;
            this.commandBarGalleryDropDown17.Gallery.ColumnCount = 1;
            spreadsheetCommandGalleryItemGroup33.CommandName = "ChartDataLabelsCommandGroup";
            spreadsheetCommandGalleryItem139.CommandName = "ChartDataLabelsNone";
            spreadsheetCommandGalleryItem140.CommandName = "ChartDataLabelsDefault";
            spreadsheetCommandGalleryItem141.CommandName = "ChartDataLabelsCenter";
            spreadsheetCommandGalleryItem142.CommandName = "ChartDataLabelsInsideEnd";
            spreadsheetCommandGalleryItem143.CommandName = "ChartDataLabelsInsideBase";
            spreadsheetCommandGalleryItem144.CommandName = "ChartDataLabelsOutsideEnd";
            spreadsheetCommandGalleryItem145.CommandName = "ChartDataLabelsBestFit";
            spreadsheetCommandGalleryItem146.CommandName = "ChartDataLabelsLeft";
            spreadsheetCommandGalleryItem147.CommandName = "ChartDataLabelsRight";
            spreadsheetCommandGalleryItem148.CommandName = "ChartDataLabelsAbove";
            spreadsheetCommandGalleryItem149.CommandName = "ChartDataLabelsBelow";
            spreadsheetCommandGalleryItemGroup33.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem139,
            spreadsheetCommandGalleryItem140,
            spreadsheetCommandGalleryItem141,
            spreadsheetCommandGalleryItem142,
            spreadsheetCommandGalleryItem143,
            spreadsheetCommandGalleryItem144,
            spreadsheetCommandGalleryItem145,
            spreadsheetCommandGalleryItem146,
            spreadsheetCommandGalleryItem147,
            spreadsheetCommandGalleryItem148,
            spreadsheetCommandGalleryItem149});
            this.commandBarGalleryDropDown17.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            spreadsheetCommandGalleryItemGroup33});
            this.commandBarGalleryDropDown17.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft;
            this.commandBarGalleryDropDown17.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left;
            this.commandBarGalleryDropDown17.Gallery.RowCount = 11;
            this.commandBarGalleryDropDown17.Gallery.ShowGroupCaption = false;
            this.commandBarGalleryDropDown17.Gallery.ShowItemText = true;
            this.commandBarGalleryDropDown17.Name = "commandBarGalleryDropDown17";
            this.commandBarGalleryDropDown17.Ribbon = this.ribbonControl1;
            // 
            // chartsLayoutAxesRibbonPageGroup1
            // 
            this.chartsLayoutAxesRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem30);
            this.chartsLayoutAxesRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem31);
            this.chartsLayoutAxesRibbonPageGroup1.Name = "chartsLayoutAxesRibbonPageGroup1";
            // 
            // spreadsheetCommandBarSubItem30
            // 
            this.spreadsheetCommandBarSubItem30.CommandName = "ChartAxesCommandGroup";
            this.spreadsheetCommandBarSubItem30.Id = 257;
            this.spreadsheetCommandBarSubItem30.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonGalleryDropDownItem16),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonGalleryDropDownItem17)});
            this.spreadsheetCommandBarSubItem30.Name = "spreadsheetCommandBarSubItem30";
            // 
            // spreadsheetCommandBarButtonGalleryDropDownItem16
            // 
            this.spreadsheetCommandBarButtonGalleryDropDownItem16.CommandName = "ChartPrimaryHorizontalAxisCommandGroup";
            this.spreadsheetCommandBarButtonGalleryDropDownItem16.DropDownControl = this.commandBarGalleryDropDown18;
            this.spreadsheetCommandBarButtonGalleryDropDownItem16.Id = 258;
            this.spreadsheetCommandBarButtonGalleryDropDownItem16.Name = "spreadsheetCommandBarButtonGalleryDropDownItem16";
            // 
            // commandBarGalleryDropDown18
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown18.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Both;
            this.commandBarGalleryDropDown18.Gallery.ColumnCount = 1;
            spreadsheetCommandGalleryItemGroup34.CommandName = "ChartPrimaryHorizontalAxisCommandGroup";
            spreadsheetCommandGalleryItem150.CommandName = "ChartHidePrimaryHorizontalAxis";
            spreadsheetCommandGalleryItem151.CommandName = "ChartPrimaryHorizontalAxisLeftToRight";
            spreadsheetCommandGalleryItem152.CommandName = "ChartPrimaryHorizontalAxisHideLabels";
            spreadsheetCommandGalleryItem153.CommandName = "ChartPrimaryHorizontalAxisRightToLeft";
            spreadsheetCommandGalleryItem154.CommandName = "ChartPrimaryHorizontalAxisDefault";
            spreadsheetCommandGalleryItem155.CommandName = "ChartPrimaryHorizontalAxisScaleThousands";
            spreadsheetCommandGalleryItem156.CommandName = "ChartPrimaryHorizontalAxisScaleMillions";
            spreadsheetCommandGalleryItem157.CommandName = "ChartPrimaryHorizontalAxisScaleBillions";
            spreadsheetCommandGalleryItem158.CommandName = "ChartPrimaryHorizontalAxisScaleLogarithm";
            spreadsheetCommandGalleryItemGroup34.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem150,
            spreadsheetCommandGalleryItem151,
            spreadsheetCommandGalleryItem152,
            spreadsheetCommandGalleryItem153,
            spreadsheetCommandGalleryItem154,
            spreadsheetCommandGalleryItem155,
            spreadsheetCommandGalleryItem156,
            spreadsheetCommandGalleryItem157,
            spreadsheetCommandGalleryItem158});
            this.commandBarGalleryDropDown18.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            spreadsheetCommandGalleryItemGroup34});
            this.commandBarGalleryDropDown18.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft;
            this.commandBarGalleryDropDown18.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left;
            this.commandBarGalleryDropDown18.Gallery.RowCount = 9;
            this.commandBarGalleryDropDown18.Gallery.ShowGroupCaption = false;
            this.commandBarGalleryDropDown18.Gallery.ShowItemText = true;
            this.commandBarGalleryDropDown18.Name = "commandBarGalleryDropDown18";
            this.commandBarGalleryDropDown18.Ribbon = this.ribbonControl1;
            // 
            // spreadsheetCommandBarButtonGalleryDropDownItem17
            // 
            this.spreadsheetCommandBarButtonGalleryDropDownItem17.CommandName = "ChartPrimaryVerticalAxisCommandGroup";
            this.spreadsheetCommandBarButtonGalleryDropDownItem17.DropDownControl = this.commandBarGalleryDropDown19;
            this.spreadsheetCommandBarButtonGalleryDropDownItem17.Id = 259;
            this.spreadsheetCommandBarButtonGalleryDropDownItem17.Name = "spreadsheetCommandBarButtonGalleryDropDownItem17";
            // 
            // commandBarGalleryDropDown19
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown19.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Both;
            this.commandBarGalleryDropDown19.Gallery.ColumnCount = 1;
            spreadsheetCommandGalleryItemGroup35.CommandName = "ChartPrimaryVerticalAxisCommandGroup";
            spreadsheetCommandGalleryItem159.CommandName = "ChartHidePrimaryVerticalAxis";
            spreadsheetCommandGalleryItem160.CommandName = "ChartPrimaryVerticalAxisLeftToRight";
            spreadsheetCommandGalleryItem161.CommandName = "ChartPrimaryVerticalAxisHideLabels";
            spreadsheetCommandGalleryItem162.CommandName = "ChartPrimaryVerticalAxisRightToLeft";
            spreadsheetCommandGalleryItem163.CommandName = "ChartPrimaryVerticalAxisDefault";
            spreadsheetCommandGalleryItem164.CommandName = "ChartPrimaryVerticalAxisScaleThousands";
            spreadsheetCommandGalleryItem165.CommandName = "ChartPrimaryVerticalAxisScaleMillions";
            spreadsheetCommandGalleryItem166.CommandName = "ChartPrimaryVerticalAxisScaleBillions";
            spreadsheetCommandGalleryItem167.CommandName = "ChartPrimaryVerticalAxisScaleLogarithm";
            spreadsheetCommandGalleryItemGroup35.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem159,
            spreadsheetCommandGalleryItem160,
            spreadsheetCommandGalleryItem161,
            spreadsheetCommandGalleryItem162,
            spreadsheetCommandGalleryItem163,
            spreadsheetCommandGalleryItem164,
            spreadsheetCommandGalleryItem165,
            spreadsheetCommandGalleryItem166,
            spreadsheetCommandGalleryItem167});
            this.commandBarGalleryDropDown19.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            spreadsheetCommandGalleryItemGroup35});
            this.commandBarGalleryDropDown19.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft;
            this.commandBarGalleryDropDown19.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left;
            this.commandBarGalleryDropDown19.Gallery.RowCount = 9;
            this.commandBarGalleryDropDown19.Gallery.ShowGroupCaption = false;
            this.commandBarGalleryDropDown19.Gallery.ShowItemText = true;
            this.commandBarGalleryDropDown19.Name = "commandBarGalleryDropDown19";
            this.commandBarGalleryDropDown19.Ribbon = this.ribbonControl1;
            // 
            // spreadsheetCommandBarSubItem31
            // 
            this.spreadsheetCommandBarSubItem31.CommandName = "ChartGridlinesCommandGroup";
            this.spreadsheetCommandBarSubItem31.Id = 260;
            this.spreadsheetCommandBarSubItem31.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonGalleryDropDownItem18),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonGalleryDropDownItem19)});
            this.spreadsheetCommandBarSubItem31.Name = "spreadsheetCommandBarSubItem31";
            // 
            // spreadsheetCommandBarButtonGalleryDropDownItem18
            // 
            this.spreadsheetCommandBarButtonGalleryDropDownItem18.CommandName = "ChartPrimaryHorizontalGridlinesCommandGroup";
            this.spreadsheetCommandBarButtonGalleryDropDownItem18.DropDownControl = this.commandBarGalleryDropDown20;
            this.spreadsheetCommandBarButtonGalleryDropDownItem18.Id = 261;
            this.spreadsheetCommandBarButtonGalleryDropDownItem18.Name = "spreadsheetCommandBarButtonGalleryDropDownItem18";
            // 
            // commandBarGalleryDropDown20
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown20.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Both;
            this.commandBarGalleryDropDown20.Gallery.ColumnCount = 1;
            spreadsheetCommandGalleryItemGroup36.CommandName = "ChartPrimaryHorizontalGridlinesCommandGroup";
            spreadsheetCommandGalleryItem168.CommandName = "ChartPrimaryHorizontalGridlinesNone";
            spreadsheetCommandGalleryItem169.CommandName = "ChartPrimaryHorizontalGridlinesMajor";
            spreadsheetCommandGalleryItem170.CommandName = "ChartPrimaryHorizontalGridlinesMinor";
            spreadsheetCommandGalleryItem171.CommandName = "ChartPrimaryHorizontalGridlinesMajorAndMinor";
            spreadsheetCommandGalleryItemGroup36.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem168,
            spreadsheetCommandGalleryItem169,
            spreadsheetCommandGalleryItem170,
            spreadsheetCommandGalleryItem171});
            this.commandBarGalleryDropDown20.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            spreadsheetCommandGalleryItemGroup36});
            this.commandBarGalleryDropDown20.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft;
            this.commandBarGalleryDropDown20.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left;
            this.commandBarGalleryDropDown20.Gallery.RowCount = 4;
            this.commandBarGalleryDropDown20.Gallery.ShowGroupCaption = false;
            this.commandBarGalleryDropDown20.Gallery.ShowItemText = true;
            this.commandBarGalleryDropDown20.Name = "commandBarGalleryDropDown20";
            this.commandBarGalleryDropDown20.Ribbon = this.ribbonControl1;
            // 
            // spreadsheetCommandBarButtonGalleryDropDownItem19
            // 
            this.spreadsheetCommandBarButtonGalleryDropDownItem19.CommandName = "ChartPrimaryVerticalGridlinesCommandGroup";
            this.spreadsheetCommandBarButtonGalleryDropDownItem19.DropDownControl = this.commandBarGalleryDropDown21;
            this.spreadsheetCommandBarButtonGalleryDropDownItem19.Id = 262;
            this.spreadsheetCommandBarButtonGalleryDropDownItem19.Name = "spreadsheetCommandBarButtonGalleryDropDownItem19";
            // 
            // commandBarGalleryDropDown21
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown21.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Both;
            this.commandBarGalleryDropDown21.Gallery.ColumnCount = 1;
            spreadsheetCommandGalleryItemGroup37.CommandName = "ChartPrimaryVerticalGridlinesCommandGroup";
            spreadsheetCommandGalleryItem172.CommandName = "ChartPrimaryVerticalGridlinesNone";
            spreadsheetCommandGalleryItem173.CommandName = "ChartPrimaryVerticalGridlinesMajor";
            spreadsheetCommandGalleryItem174.CommandName = "ChartPrimaryVerticalGridlinesMinor";
            spreadsheetCommandGalleryItem175.CommandName = "ChartPrimaryVerticalGridlinesMajorAndMinor";
            spreadsheetCommandGalleryItemGroup37.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem172,
            spreadsheetCommandGalleryItem173,
            spreadsheetCommandGalleryItem174,
            spreadsheetCommandGalleryItem175});
            this.commandBarGalleryDropDown21.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            spreadsheetCommandGalleryItemGroup37});
            this.commandBarGalleryDropDown21.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft;
            this.commandBarGalleryDropDown21.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left;
            this.commandBarGalleryDropDown21.Gallery.RowCount = 4;
            this.commandBarGalleryDropDown21.Gallery.ShowGroupCaption = false;
            this.commandBarGalleryDropDown21.Gallery.ShowItemText = true;
            this.commandBarGalleryDropDown21.Name = "commandBarGalleryDropDown21";
            this.commandBarGalleryDropDown21.Ribbon = this.ribbonControl1;
            // 
            // chartsLayoutAnalysisRibbonPageGroup1
            // 
            this.chartsLayoutAnalysisRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem20);
            this.chartsLayoutAnalysisRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem21);
            this.chartsLayoutAnalysisRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonGalleryDropDownItem22);
            this.chartsLayoutAnalysisRibbonPageGroup1.Name = "chartsLayoutAnalysisRibbonPageGroup1";
            // 
            // spreadsheetCommandBarButtonGalleryDropDownItem20
            // 
            this.spreadsheetCommandBarButtonGalleryDropDownItem20.CommandName = "ChartLinesCommandGroup";
            this.spreadsheetCommandBarButtonGalleryDropDownItem20.DropDownControl = this.commandBarGalleryDropDown22;
            this.spreadsheetCommandBarButtonGalleryDropDownItem20.Id = 263;
            this.spreadsheetCommandBarButtonGalleryDropDownItem20.Name = "spreadsheetCommandBarButtonGalleryDropDownItem20";
            // 
            // commandBarGalleryDropDown22
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown22.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Both;
            this.commandBarGalleryDropDown22.Gallery.ColumnCount = 1;
            spreadsheetCommandGalleryItemGroup38.CommandName = "ChartLinesCommandGroup";
            spreadsheetCommandGalleryItem176.CommandName = "ChartLinesNone";
            spreadsheetCommandGalleryItem177.CommandName = "ChartShowDropLines";
            spreadsheetCommandGalleryItem178.CommandName = "ChartShowHighLowLines";
            spreadsheetCommandGalleryItem179.CommandName = "ChartShowDropLinesAndHighLowLines";
            spreadsheetCommandGalleryItem180.CommandName = "ChartShowSeriesLines";
            spreadsheetCommandGalleryItemGroup38.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem176,
            spreadsheetCommandGalleryItem177,
            spreadsheetCommandGalleryItem178,
            spreadsheetCommandGalleryItem179,
            spreadsheetCommandGalleryItem180});
            this.commandBarGalleryDropDown22.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            spreadsheetCommandGalleryItemGroup38});
            this.commandBarGalleryDropDown22.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft;
            this.commandBarGalleryDropDown22.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left;
            this.commandBarGalleryDropDown22.Gallery.RowCount = 5;
            this.commandBarGalleryDropDown22.Gallery.ShowGroupCaption = false;
            this.commandBarGalleryDropDown22.Gallery.ShowItemText = true;
            this.commandBarGalleryDropDown22.Name = "commandBarGalleryDropDown22";
            this.commandBarGalleryDropDown22.Ribbon = this.ribbonControl1;
            // 
            // spreadsheetCommandBarButtonGalleryDropDownItem21
            // 
            this.spreadsheetCommandBarButtonGalleryDropDownItem21.CommandName = "ChartUpDownBarsCommandGroup";
            this.spreadsheetCommandBarButtonGalleryDropDownItem21.DropDownControl = this.commandBarGalleryDropDown23;
            this.spreadsheetCommandBarButtonGalleryDropDownItem21.Id = 264;
            this.spreadsheetCommandBarButtonGalleryDropDownItem21.Name = "spreadsheetCommandBarButtonGalleryDropDownItem21";
            // 
            // commandBarGalleryDropDown23
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown23.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Both;
            this.commandBarGalleryDropDown23.Gallery.ColumnCount = 1;
            spreadsheetCommandGalleryItemGroup39.CommandName = "ChartUpDownBarsCommandGroup";
            spreadsheetCommandGalleryItem181.CommandName = "ChartHideUpDownBars";
            spreadsheetCommandGalleryItem182.CommandName = "ChartShowUpDownBars";
            spreadsheetCommandGalleryItemGroup39.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem181,
            spreadsheetCommandGalleryItem182});
            this.commandBarGalleryDropDown23.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            spreadsheetCommandGalleryItemGroup39});
            this.commandBarGalleryDropDown23.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft;
            this.commandBarGalleryDropDown23.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left;
            this.commandBarGalleryDropDown23.Gallery.RowCount = 2;
            this.commandBarGalleryDropDown23.Gallery.ShowGroupCaption = false;
            this.commandBarGalleryDropDown23.Gallery.ShowItemText = true;
            this.commandBarGalleryDropDown23.Name = "commandBarGalleryDropDown23";
            this.commandBarGalleryDropDown23.Ribbon = this.ribbonControl1;
            // 
            // spreadsheetCommandBarButtonGalleryDropDownItem22
            // 
            this.spreadsheetCommandBarButtonGalleryDropDownItem22.CommandName = "ChartErrorBarsCommandGroup";
            this.spreadsheetCommandBarButtonGalleryDropDownItem22.DropDownControl = this.commandBarGalleryDropDown24;
            this.spreadsheetCommandBarButtonGalleryDropDownItem22.Id = 265;
            this.spreadsheetCommandBarButtonGalleryDropDownItem22.Name = "spreadsheetCommandBarButtonGalleryDropDownItem22";
            // 
            // commandBarGalleryDropDown24
            // 
            // 
            // 
            // 
            this.commandBarGalleryDropDown24.Gallery.AutoSize = DevExpress.XtraBars.Ribbon.GallerySizeMode.Both;
            this.commandBarGalleryDropDown24.Gallery.ColumnCount = 1;
            spreadsheetCommandGalleryItemGroup40.CommandName = "ChartErrorBarsCommandGroup";
            spreadsheetCommandGalleryItem183.CommandName = "ChartErrorBarsNone";
            spreadsheetCommandGalleryItem184.CommandName = "ChartErrorBarsStandardError";
            spreadsheetCommandGalleryItem185.CommandName = "ChartErrorBarsPercentage";
            spreadsheetCommandGalleryItem186.CommandName = "ChartErrorBarsStandardDeviation";
            spreadsheetCommandGalleryItemGroup40.Items.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItem[] {
            spreadsheetCommandGalleryItem183,
            spreadsheetCommandGalleryItem184,
            spreadsheetCommandGalleryItem185,
            spreadsheetCommandGalleryItem186});
            this.commandBarGalleryDropDown24.Gallery.Groups.AddRange(new DevExpress.XtraBars.Ribbon.GalleryItemGroup[] {
            spreadsheetCommandGalleryItemGroup40});
            this.commandBarGalleryDropDown24.Gallery.ItemImageLayout = DevExpress.Utils.Drawing.ImageLayoutMode.MiddleLeft;
            this.commandBarGalleryDropDown24.Gallery.ItemImageLocation = DevExpress.Utils.Locations.Left;
            this.commandBarGalleryDropDown24.Gallery.RowCount = 4;
            this.commandBarGalleryDropDown24.Gallery.ShowGroupCaption = false;
            this.commandBarGalleryDropDown24.Gallery.ShowItemText = true;
            this.commandBarGalleryDropDown24.Name = "commandBarGalleryDropDown24";
            this.commandBarGalleryDropDown24.Ribbon = this.ribbonControl1;
            // 
            // chartsFormatArrangeRibbonPageGroup1
            // 
            this.chartsFormatArrangeRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem20);
            this.chartsFormatArrangeRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem21);
            this.chartsFormatArrangeRibbonPageGroup1.Name = "chartsFormatArrangeRibbonPageGroup1";
            // 
            // chartsFormatRibbonPage1
            // 
            this.chartsFormatRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.chartsFormatArrangeRibbonPageGroup1});
            this.chartsFormatRibbonPage1.Name = "chartsFormatRibbonPage1";
            this.chartsFormatRibbonPage1.Visible = false;
            // 
            // tablePropertiesRibbonPageGroup1
            // 
            this.tablePropertiesRibbonPageGroup1.ItemLinks.Add(this.barStaticItem1);
            this.tablePropertiesRibbonPageGroup1.ItemLinks.Add(this.renameTableItem1);
            this.tablePropertiesRibbonPageGroup1.Name = "tablePropertiesRibbonPageGroup1";
            // 
            // tableToolsDesignRibbonPage1
            // 
            this.tableToolsDesignRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.tablePropertiesRibbonPageGroup1,
            this.tableToolsRibbonPageGroup1,
            this.tableStyleOptionsRibbonPageGroup1,
            this.tableStylesRibbonPageGroup1});
            this.tableToolsDesignRibbonPage1.Name = "tableToolsDesignRibbonPage1";
            this.tableToolsDesignRibbonPage1.Visible = false;
            // 
            // tableToolsRibbonPageCategory1
            // 
            this.tableToolsRibbonPageCategory1.Control = this.SpreadSheet;
            this.tableToolsRibbonPageCategory1.Name = "tableToolsRibbonPageCategory1";
            this.tableToolsRibbonPageCategory1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.tableToolsDesignRibbonPage1});
            this.tableToolsRibbonPageCategory1.Visible = false;
            // 
            // barStaticItem1
            // 
            this.barStaticItem1.Caption = "Table Name:";
            this.barStaticItem1.Id = 266;
            this.barStaticItem1.Name = "barStaticItem1";
            this.barStaticItem1.TextAlignment = System.Drawing.StringAlignment.Near;
            // 
            // renameTableItem1
            // 
            this.renameTableItem1.Edit = this.repositoryItemTextEdit1;
            this.renameTableItem1.EditWidth = 80;
            this.renameTableItem1.Id = 267;
            this.renameTableItem1.Name = "renameTableItem1";
            // 
            // repositoryItemTextEdit1
            // 
            this.repositoryItemTextEdit1.AutoHeight = false;
            this.repositoryItemTextEdit1.Name = "repositoryItemTextEdit1";
            // 
            // tableToolsRibbonPageGroup1
            // 
            this.tableToolsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarCheckItem27);
            this.tableToolsRibbonPageGroup1.Name = "tableToolsRibbonPageGroup1";
            // 
            // spreadsheetCommandBarCheckItem27
            // 
            this.spreadsheetCommandBarCheckItem27.CommandName = "TableToolsConvertToRange";
            this.spreadsheetCommandBarCheckItem27.Id = 268;
            this.spreadsheetCommandBarCheckItem27.Name = "spreadsheetCommandBarCheckItem27";
            this.spreadsheetCommandBarCheckItem27.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // tableStyleOptionsRibbonPageGroup1
            // 
            this.tableStyleOptionsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarCheckItem28);
            this.tableStyleOptionsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarCheckItem29);
            this.tableStyleOptionsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarCheckItem30);
            this.tableStyleOptionsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarCheckItem31);
            this.tableStyleOptionsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarCheckItem32);
            this.tableStyleOptionsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarCheckItem33);
            this.tableStyleOptionsRibbonPageGroup1.Name = "tableStyleOptionsRibbonPageGroup1";
            // 
            // spreadsheetCommandBarCheckItem28
            // 
            this.spreadsheetCommandBarCheckItem28.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText;
            this.spreadsheetCommandBarCheckItem28.CommandName = "TableToolsToggleHeaderRow";
            this.spreadsheetCommandBarCheckItem28.Id = 269;
            this.spreadsheetCommandBarCheckItem28.Name = "spreadsheetCommandBarCheckItem28";
            // 
            // spreadsheetCommandBarCheckItem29
            // 
            this.spreadsheetCommandBarCheckItem29.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText;
            this.spreadsheetCommandBarCheckItem29.CommandName = "TableToolsToggleTotalRow";
            this.spreadsheetCommandBarCheckItem29.Id = 270;
            this.spreadsheetCommandBarCheckItem29.Name = "spreadsheetCommandBarCheckItem29";
            // 
            // spreadsheetCommandBarCheckItem30
            // 
            this.spreadsheetCommandBarCheckItem30.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText;
            this.spreadsheetCommandBarCheckItem30.CommandName = "TableToolsToggleBandedColumns";
            this.spreadsheetCommandBarCheckItem30.Id = 271;
            this.spreadsheetCommandBarCheckItem30.Name = "spreadsheetCommandBarCheckItem30";
            // 
            // spreadsheetCommandBarCheckItem31
            // 
            this.spreadsheetCommandBarCheckItem31.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText;
            this.spreadsheetCommandBarCheckItem31.CommandName = "TableToolsToggleFirstColumn";
            this.spreadsheetCommandBarCheckItem31.Id = 272;
            this.spreadsheetCommandBarCheckItem31.Name = "spreadsheetCommandBarCheckItem31";
            // 
            // spreadsheetCommandBarCheckItem32
            // 
            this.spreadsheetCommandBarCheckItem32.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText;
            this.spreadsheetCommandBarCheckItem32.CommandName = "TableToolsToggleLastColumn";
            this.spreadsheetCommandBarCheckItem32.Id = 273;
            this.spreadsheetCommandBarCheckItem32.Name = "spreadsheetCommandBarCheckItem32";
            // 
            // spreadsheetCommandBarCheckItem33
            // 
            this.spreadsheetCommandBarCheckItem33.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText;
            this.spreadsheetCommandBarCheckItem33.CommandName = "TableToolsToggleBandedRows";
            this.spreadsheetCommandBarCheckItem33.Id = 274;
            this.spreadsheetCommandBarCheckItem33.Name = "spreadsheetCommandBarCheckItem33";
            // 
            // tableStylesRibbonPageGroup1
            // 
            this.tableStylesRibbonPageGroup1.ItemLinks.Add(this.galleryTableStylesItem1);
            this.tableStylesRibbonPageGroup1.Name = "tableStylesRibbonPageGroup1";
            // 
            // galleryTableStylesItem1
            // 
            // 
            // 
            // 
            this.galleryTableStylesItem1.Gallery.ColumnCount = 7;
            this.galleryTableStylesItem1.Gallery.DrawImageBackground = false;
            this.galleryTableStylesItem1.Gallery.ImageSize = new System.Drawing.Size(65, 46);
            this.galleryTableStylesItem1.Gallery.ItemAutoSizeMode = DevExpress.XtraBars.Ribbon.Gallery.GalleryItemAutoSizeMode.None;
            this.galleryTableStylesItem1.Gallery.ItemSize = new System.Drawing.Size(73, 58);
            this.galleryTableStylesItem1.Gallery.RowCount = 10;
            this.galleryTableStylesItem1.Id = 275;
            this.galleryTableStylesItem1.Name = "galleryTableStylesItem1";
            // 
            // pictureFormatArrangeRibbonPageGroup1
            // 
            this.pictureFormatArrangeRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem20);
            this.pictureFormatArrangeRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem21);
            this.pictureFormatArrangeRibbonPageGroup1.Name = "pictureFormatArrangeRibbonPageGroup1";
            // 
            // pictureFormatRibbonPage1
            // 
            this.pictureFormatRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.pictureFormatArrangeRibbonPageGroup1});
            this.pictureFormatRibbonPage1.Name = "pictureFormatRibbonPage1";
            this.pictureFormatRibbonPage1.Visible = false;
            // 
            // pictureToolsRibbonPageCategory1
            // 
            this.pictureToolsRibbonPageCategory1.Control = this.SpreadSheet;
            this.pictureToolsRibbonPageCategory1.Name = "pictureToolsRibbonPageCategory1";
            this.pictureToolsRibbonPageCategory1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.pictureFormatRibbonPage1});
            this.pictureToolsRibbonPageCategory1.Visible = false;
            // 
            // drawingFormatArrangeRibbonPageGroup1
            // 
            this.drawingFormatArrangeRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem20);
            this.drawingFormatArrangeRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem21);
            this.drawingFormatArrangeRibbonPageGroup1.Name = "drawingFormatArrangeRibbonPageGroup1";
            // 
            // drawingFormatRibbonPage1
            // 
            this.drawingFormatRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.drawingFormatArrangeRibbonPageGroup1});
            this.drawingFormatRibbonPage1.Name = "drawingFormatRibbonPage1";
            this.drawingFormatRibbonPage1.Visible = false;
            // 
            // drawingToolsRibbonPageCategory1
            // 
            this.drawingToolsRibbonPageCategory1.Control = this.SpreadSheet;
            this.drawingToolsRibbonPageCategory1.Name = "drawingToolsRibbonPageCategory1";
            this.drawingToolsRibbonPageCategory1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.drawingFormatRibbonPage1});
            this.drawingToolsRibbonPageCategory1.Visible = false;
            // 
            // pivotTableAnalyzePivotTableRibbonPageGroup1
            // 
            this.pivotTableAnalyzePivotTableRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem157);
            this.pivotTableAnalyzePivotTableRibbonPageGroup1.Name = "pivotTableAnalyzePivotTableRibbonPageGroup1";
            // 
            // pivotTableAnalyzeRibbonPage1
            // 
            this.pivotTableAnalyzeRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.pivotTableAnalyzePivotTableRibbonPageGroup1,
            this.pivotTableAnalyzeActiveFieldRibbonPageGroup1,
            this.pivotTableAnalyzeDataRibbonPageGroup1,
            this.pivotTableAnalyzeActionsRibbonPageGroup1,
            this.pivotTableAnalyzeShowRibbonPageGroup1});
            this.pivotTableAnalyzeRibbonPage1.Name = "pivotTableAnalyzeRibbonPage1";
            this.pivotTableAnalyzeRibbonPage1.Visible = false;
            // 
            // pivotTableToolsRibbonPageCategory1
            // 
            this.pivotTableToolsRibbonPageCategory1.Control = this.SpreadSheet;
            this.pivotTableToolsRibbonPageCategory1.Name = "pivotTableToolsRibbonPageCategory1";
            this.pivotTableToolsRibbonPageCategory1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.pivotTableAnalyzeRibbonPage1,
            this.pivotTableDesignRibbonPage1});
            this.pivotTableToolsRibbonPageCategory1.Visible = false;
            // 
            // spreadsheetCommandBarButtonItem157
            // 
            this.spreadsheetCommandBarButtonItem157.CommandName = "OptionsPivotTable";
            this.spreadsheetCommandBarButtonItem157.Id = 276;
            this.spreadsheetCommandBarButtonItem157.Name = "spreadsheetCommandBarButtonItem157";
            // 
            // pivotTableAnalyzeActiveFieldRibbonPageGroup1
            // 
            this.pivotTableAnalyzeActiveFieldRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem158);
            this.pivotTableAnalyzeActiveFieldRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem159);
            this.pivotTableAnalyzeActiveFieldRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem160);
            this.pivotTableAnalyzeActiveFieldRibbonPageGroup1.Name = "pivotTableAnalyzeActiveFieldRibbonPageGroup1";
            // 
            // spreadsheetCommandBarButtonItem158
            // 
            this.spreadsheetCommandBarButtonItem158.CommandName = "SelectFieldTypePivotTable";
            this.spreadsheetCommandBarButtonItem158.Id = 277;
            this.spreadsheetCommandBarButtonItem158.Name = "spreadsheetCommandBarButtonItem158";
            // 
            // spreadsheetCommandBarButtonItem159
            // 
            this.spreadsheetCommandBarButtonItem159.CommandName = "PivotTableExpandField";
            this.spreadsheetCommandBarButtonItem159.Id = 278;
            this.spreadsheetCommandBarButtonItem159.Name = "spreadsheetCommandBarButtonItem159";
            this.spreadsheetCommandBarButtonItem159.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // spreadsheetCommandBarButtonItem160
            // 
            this.spreadsheetCommandBarButtonItem160.CommandName = "PivotTableCollapseField";
            this.spreadsheetCommandBarButtonItem160.Id = 279;
            this.spreadsheetCommandBarButtonItem160.Name = "spreadsheetCommandBarButtonItem160";
            this.spreadsheetCommandBarButtonItem160.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithText;
            // 
            // pivotTableAnalyzeDataRibbonPageGroup1
            // 
            this.pivotTableAnalyzeDataRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem32);
            this.pivotTableAnalyzeDataRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem163);
            this.pivotTableAnalyzeDataRibbonPageGroup1.Name = "pivotTableAnalyzeDataRibbonPageGroup1";
            // 
            // spreadsheetCommandBarSubItem32
            // 
            this.spreadsheetCommandBarSubItem32.CommandName = "PivotTableDataRefreshGroup";
            this.spreadsheetCommandBarSubItem32.Id = 280;
            this.spreadsheetCommandBarSubItem32.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem161),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem162)});
            this.spreadsheetCommandBarSubItem32.Name = "spreadsheetCommandBarSubItem32";
            // 
            // spreadsheetCommandBarButtonItem161
            // 
            this.spreadsheetCommandBarButtonItem161.CommandName = "RefreshPivotTable";
            this.spreadsheetCommandBarButtonItem161.Id = 281;
            this.spreadsheetCommandBarButtonItem161.Name = "spreadsheetCommandBarButtonItem161";
            // 
            // spreadsheetCommandBarButtonItem162
            // 
            this.spreadsheetCommandBarButtonItem162.CommandName = "RefreshAllPivotTable";
            this.spreadsheetCommandBarButtonItem162.Id = 282;
            this.spreadsheetCommandBarButtonItem162.Name = "spreadsheetCommandBarButtonItem162";
            // 
            // spreadsheetCommandBarButtonItem163
            // 
            this.spreadsheetCommandBarButtonItem163.CommandName = "ChangeDataSourcePivotTable";
            this.spreadsheetCommandBarButtonItem163.Id = 283;
            this.spreadsheetCommandBarButtonItem163.Name = "spreadsheetCommandBarButtonItem163";
            // 
            // pivotTableAnalyzeActionsRibbonPageGroup1
            // 
            this.pivotTableAnalyzeActionsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem33);
            this.pivotTableAnalyzeActionsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem34);
            this.pivotTableAnalyzeActionsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarButtonItem169);
            this.pivotTableAnalyzeActionsRibbonPageGroup1.Name = "pivotTableAnalyzeActionsRibbonPageGroup1";
            // 
            // spreadsheetCommandBarSubItem33
            // 
            this.spreadsheetCommandBarSubItem33.CommandName = "PivotTableActionsClearGroup";
            this.spreadsheetCommandBarSubItem33.Id = 284;
            this.spreadsheetCommandBarSubItem33.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem164),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem165)});
            this.spreadsheetCommandBarSubItem33.Name = "spreadsheetCommandBarSubItem33";
            // 
            // spreadsheetCommandBarButtonItem164
            // 
            this.spreadsheetCommandBarButtonItem164.CommandName = "ClearAllPivotTable";
            this.spreadsheetCommandBarButtonItem164.Id = 285;
            this.spreadsheetCommandBarButtonItem164.Name = "spreadsheetCommandBarButtonItem164";
            // 
            // spreadsheetCommandBarButtonItem165
            // 
            this.spreadsheetCommandBarButtonItem165.CommandName = "ClearFiltersPivotTable";
            this.spreadsheetCommandBarButtonItem165.Id = 286;
            this.spreadsheetCommandBarButtonItem165.Name = "spreadsheetCommandBarButtonItem165";
            // 
            // spreadsheetCommandBarSubItem34
            // 
            this.spreadsheetCommandBarSubItem34.CommandName = "PivotTableActionsSelectGroup";
            this.spreadsheetCommandBarSubItem34.Id = 287;
            this.spreadsheetCommandBarSubItem34.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem166),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem167),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem168)});
            this.spreadsheetCommandBarSubItem34.Name = "spreadsheetCommandBarSubItem34";
            // 
            // spreadsheetCommandBarButtonItem166
            // 
            this.spreadsheetCommandBarButtonItem166.CommandName = "SelectValuesPivotTable";
            this.spreadsheetCommandBarButtonItem166.Id = 288;
            this.spreadsheetCommandBarButtonItem166.Name = "spreadsheetCommandBarButtonItem166";
            // 
            // spreadsheetCommandBarButtonItem167
            // 
            this.spreadsheetCommandBarButtonItem167.CommandName = "SelectLabelsPivotTable";
            this.spreadsheetCommandBarButtonItem167.Id = 289;
            this.spreadsheetCommandBarButtonItem167.Name = "spreadsheetCommandBarButtonItem167";
            // 
            // spreadsheetCommandBarButtonItem168
            // 
            this.spreadsheetCommandBarButtonItem168.CommandName = "SelectEntirePivotTable";
            this.spreadsheetCommandBarButtonItem168.Id = 290;
            this.spreadsheetCommandBarButtonItem168.Name = "spreadsheetCommandBarButtonItem168";
            // 
            // spreadsheetCommandBarButtonItem169
            // 
            this.spreadsheetCommandBarButtonItem169.CommandName = "MovePivotTable";
            this.spreadsheetCommandBarButtonItem169.Id = 291;
            this.spreadsheetCommandBarButtonItem169.Name = "spreadsheetCommandBarButtonItem169";
            // 
            // pivotTableAnalyzeShowRibbonPageGroup1
            // 
            this.pivotTableAnalyzeShowRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarCheckItem34);
            this.pivotTableAnalyzeShowRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarCheckItem35);
            this.pivotTableAnalyzeShowRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarCheckItem36);
            this.pivotTableAnalyzeShowRibbonPageGroup1.Name = "pivotTableAnalyzeShowRibbonPageGroup1";
            // 
            // spreadsheetCommandBarCheckItem34
            // 
            this.spreadsheetCommandBarCheckItem34.CommandName = "FieldListPanelPivotTable";
            this.spreadsheetCommandBarCheckItem34.Id = 292;
            this.spreadsheetCommandBarCheckItem34.Name = "spreadsheetCommandBarCheckItem34";
            // 
            // spreadsheetCommandBarCheckItem35
            // 
            this.spreadsheetCommandBarCheckItem35.CommandName = "ShowPivotTableExpandCollapseButtons";
            this.spreadsheetCommandBarCheckItem35.Id = 293;
            this.spreadsheetCommandBarCheckItem35.Name = "spreadsheetCommandBarCheckItem35";
            // 
            // spreadsheetCommandBarCheckItem36
            // 
            this.spreadsheetCommandBarCheckItem36.CommandName = "ShowPivotTableFieldHeaders";
            this.spreadsheetCommandBarCheckItem36.Id = 294;
            this.spreadsheetCommandBarCheckItem36.Name = "spreadsheetCommandBarCheckItem36";
            // 
            // pivotTableDesignLayoutRibbonPageGroup1
            // 
            this.pivotTableDesignLayoutRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem35);
            this.pivotTableDesignLayoutRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem36);
            this.pivotTableDesignLayoutRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem37);
            this.pivotTableDesignLayoutRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarSubItem38);
            this.pivotTableDesignLayoutRibbonPageGroup1.Name = "pivotTableDesignLayoutRibbonPageGroup1";
            // 
            // pivotTableDesignRibbonPage1
            // 
            this.pivotTableDesignRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.pivotTableDesignLayoutRibbonPageGroup1,
            this.pivotTableDesignPivotTableStyleOptionsRibbonPageGroup1,
            this.pivotTableDesignPivotTableStylesRibbonPageGroup1});
            this.pivotTableDesignRibbonPage1.Name = "pivotTableDesignRibbonPage1";
            this.pivotTableDesignRibbonPage1.Visible = false;
            // 
            // spreadsheetCommandBarSubItem35
            // 
            this.spreadsheetCommandBarSubItem35.CommandName = "PivotTableLayoutSubtotalsGroup";
            this.spreadsheetCommandBarSubItem35.Id = 295;
            this.spreadsheetCommandBarSubItem35.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem170),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem171),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem172)});
            this.spreadsheetCommandBarSubItem35.Name = "spreadsheetCommandBarSubItem35";
            // 
            // spreadsheetCommandBarButtonItem170
            // 
            this.spreadsheetCommandBarButtonItem170.CommandName = "PivotTableDoNotShowSubtotals";
            this.spreadsheetCommandBarButtonItem170.Id = 296;
            this.spreadsheetCommandBarButtonItem170.Name = "spreadsheetCommandBarButtonItem170";
            this.spreadsheetCommandBarButtonItem170.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem171
            // 
            this.spreadsheetCommandBarButtonItem171.CommandName = "PivotTableShowAllSubtotalsAtBottom";
            this.spreadsheetCommandBarButtonItem171.Id = 297;
            this.spreadsheetCommandBarButtonItem171.Name = "spreadsheetCommandBarButtonItem171";
            this.spreadsheetCommandBarButtonItem171.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem172
            // 
            this.spreadsheetCommandBarButtonItem172.CommandName = "PivotTableShowAllSubtotalsAtTop";
            this.spreadsheetCommandBarButtonItem172.Id = 298;
            this.spreadsheetCommandBarButtonItem172.Name = "spreadsheetCommandBarButtonItem172";
            this.spreadsheetCommandBarButtonItem172.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarSubItem36
            // 
            this.spreadsheetCommandBarSubItem36.CommandName = "PivotTableLayoutGrandTotalsGroup";
            this.spreadsheetCommandBarSubItem36.Id = 299;
            this.spreadsheetCommandBarSubItem36.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem173),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem174),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem175),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem176)});
            this.spreadsheetCommandBarSubItem36.Name = "spreadsheetCommandBarSubItem36";
            // 
            // spreadsheetCommandBarButtonItem173
            // 
            this.spreadsheetCommandBarButtonItem173.CommandName = "PivotTableGrandTotalsOffRowsColumns";
            this.spreadsheetCommandBarButtonItem173.Id = 300;
            this.spreadsheetCommandBarButtonItem173.Name = "spreadsheetCommandBarButtonItem173";
            this.spreadsheetCommandBarButtonItem173.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem174
            // 
            this.spreadsheetCommandBarButtonItem174.CommandName = "PivotTableGrandTotalsOnRowsColumns";
            this.spreadsheetCommandBarButtonItem174.Id = 301;
            this.spreadsheetCommandBarButtonItem174.Name = "spreadsheetCommandBarButtonItem174";
            this.spreadsheetCommandBarButtonItem174.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem175
            // 
            this.spreadsheetCommandBarButtonItem175.CommandName = "PivotTableGrandTotalsOnRowsOnly";
            this.spreadsheetCommandBarButtonItem175.Id = 302;
            this.spreadsheetCommandBarButtonItem175.Name = "spreadsheetCommandBarButtonItem175";
            this.spreadsheetCommandBarButtonItem175.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem176
            // 
            this.spreadsheetCommandBarButtonItem176.CommandName = "PivotTableGrandTotalsOnColumnsOnly";
            this.spreadsheetCommandBarButtonItem176.Id = 303;
            this.spreadsheetCommandBarButtonItem176.Name = "spreadsheetCommandBarButtonItem176";
            this.spreadsheetCommandBarButtonItem176.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarSubItem37
            // 
            this.spreadsheetCommandBarSubItem37.CommandName = "PivotTableLayoutReportLayoutGroup";
            this.spreadsheetCommandBarSubItem37.Id = 304;
            this.spreadsheetCommandBarSubItem37.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem177),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem178),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem179),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem180),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem181)});
            this.spreadsheetCommandBarSubItem37.Name = "spreadsheetCommandBarSubItem37";
            // 
            // spreadsheetCommandBarButtonItem177
            // 
            this.spreadsheetCommandBarButtonItem177.CommandName = "PivotTableShowCompactForm";
            this.spreadsheetCommandBarButtonItem177.Id = 305;
            this.spreadsheetCommandBarButtonItem177.Name = "spreadsheetCommandBarButtonItem177";
            this.spreadsheetCommandBarButtonItem177.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem178
            // 
            this.spreadsheetCommandBarButtonItem178.CommandName = "PivotTableShowOutlineForm";
            this.spreadsheetCommandBarButtonItem178.Id = 306;
            this.spreadsheetCommandBarButtonItem178.Name = "spreadsheetCommandBarButtonItem178";
            this.spreadsheetCommandBarButtonItem178.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem179
            // 
            this.spreadsheetCommandBarButtonItem179.CommandName = "PivotTableShowTabularForm";
            this.spreadsheetCommandBarButtonItem179.Id = 307;
            this.spreadsheetCommandBarButtonItem179.Name = "spreadsheetCommandBarButtonItem179";
            this.spreadsheetCommandBarButtonItem179.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem180
            // 
            this.spreadsheetCommandBarButtonItem180.CommandName = "PivotTableRepeatAllItemLabels";
            this.spreadsheetCommandBarButtonItem180.Id = 308;
            this.spreadsheetCommandBarButtonItem180.Name = "spreadsheetCommandBarButtonItem180";
            this.spreadsheetCommandBarButtonItem180.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem181
            // 
            this.spreadsheetCommandBarButtonItem181.CommandName = "PivotTableDoNotRepeatItemLabels";
            this.spreadsheetCommandBarButtonItem181.Id = 309;
            this.spreadsheetCommandBarButtonItem181.Name = "spreadsheetCommandBarButtonItem181";
            this.spreadsheetCommandBarButtonItem181.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarSubItem38
            // 
            this.spreadsheetCommandBarSubItem38.CommandName = "PivotTableLayoutBlankRowsGroup";
            this.spreadsheetCommandBarSubItem38.Id = 310;
            this.spreadsheetCommandBarSubItem38.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem182),
            new DevExpress.XtraBars.LinkPersistInfo(this.spreadsheetCommandBarButtonItem183)});
            this.spreadsheetCommandBarSubItem38.Name = "spreadsheetCommandBarSubItem38";
            // 
            // spreadsheetCommandBarButtonItem182
            // 
            this.spreadsheetCommandBarButtonItem182.CommandName = "PivotTableInsertBlankLineEachItem";
            this.spreadsheetCommandBarButtonItem182.Id = 311;
            this.spreadsheetCommandBarButtonItem182.Name = "spreadsheetCommandBarButtonItem182";
            this.spreadsheetCommandBarButtonItem182.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // spreadsheetCommandBarButtonItem183
            // 
            this.spreadsheetCommandBarButtonItem183.CommandName = "PivotTableRemoveBlankLineEachItem";
            this.spreadsheetCommandBarButtonItem183.Id = 312;
            this.spreadsheetCommandBarButtonItem183.Name = "spreadsheetCommandBarButtonItem183";
            this.spreadsheetCommandBarButtonItem183.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.Large;
            // 
            // pivotTableDesignPivotTableStyleOptionsRibbonPageGroup1
            // 
            this.pivotTableDesignPivotTableStyleOptionsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarCheckItem37);
            this.pivotTableDesignPivotTableStyleOptionsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarCheckItem38);
            this.pivotTableDesignPivotTableStyleOptionsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarCheckItem39);
            this.pivotTableDesignPivotTableStyleOptionsRibbonPageGroup1.ItemLinks.Add(this.spreadsheetCommandBarCheckItem40);
            this.pivotTableDesignPivotTableStyleOptionsRibbonPageGroup1.ItemsLayout = DevExpress.XtraBars.Ribbon.RibbonPageGroupItemsLayout.TwoRows;
            this.pivotTableDesignPivotTableStyleOptionsRibbonPageGroup1.Name = "pivotTableDesignPivotTableStyleOptionsRibbonPageGroup1";
            // 
            // spreadsheetCommandBarCheckItem37
            // 
            this.spreadsheetCommandBarCheckItem37.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText;
            this.spreadsheetCommandBarCheckItem37.CommandName = "PivotTableToggleRowHeaders";
            this.spreadsheetCommandBarCheckItem37.Id = 313;
            this.spreadsheetCommandBarCheckItem37.Name = "spreadsheetCommandBarCheckItem37";
            // 
            // spreadsheetCommandBarCheckItem38
            // 
            this.spreadsheetCommandBarCheckItem38.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText;
            this.spreadsheetCommandBarCheckItem38.CommandName = "PivotTableToggleColumnHeaders";
            this.spreadsheetCommandBarCheckItem38.Id = 314;
            this.spreadsheetCommandBarCheckItem38.Name = "spreadsheetCommandBarCheckItem38";
            // 
            // spreadsheetCommandBarCheckItem39
            // 
            this.spreadsheetCommandBarCheckItem39.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText;
            this.spreadsheetCommandBarCheckItem39.CommandName = "PivotTableToggleBandedRows";
            this.spreadsheetCommandBarCheckItem39.Id = 315;
            this.spreadsheetCommandBarCheckItem39.Name = "spreadsheetCommandBarCheckItem39";
            // 
            // spreadsheetCommandBarCheckItem40
            // 
            this.spreadsheetCommandBarCheckItem40.CheckBoxVisibility = DevExpress.XtraBars.CheckBoxVisibility.BeforeText;
            this.spreadsheetCommandBarCheckItem40.CommandName = "PivotTableToggleBandedColumns";
            this.spreadsheetCommandBarCheckItem40.Id = 316;
            this.spreadsheetCommandBarCheckItem40.Name = "spreadsheetCommandBarCheckItem40";
            // 
            // pivotTableDesignPivotTableStylesRibbonPageGroup1
            // 
            this.pivotTableDesignPivotTableStylesRibbonPageGroup1.ItemLinks.Add(this.galleryPivotStylesItem1);
            this.pivotTableDesignPivotTableStylesRibbonPageGroup1.Name = "pivotTableDesignPivotTableStylesRibbonPageGroup1";
            // 
            // galleryPivotStylesItem1
            // 
            // 
            // 
            // 
            this.galleryPivotStylesItem1.Gallery.ColumnCount = 7;
            this.galleryPivotStylesItem1.Gallery.DrawImageBackground = false;
            this.galleryPivotStylesItem1.Gallery.ImageSize = new System.Drawing.Size(65, 46);
            this.galleryPivotStylesItem1.Gallery.ItemAutoSizeMode = DevExpress.XtraBars.Ribbon.Gallery.GalleryItemAutoSizeMode.None;
            this.galleryPivotStylesItem1.Gallery.ItemSize = new System.Drawing.Size(73, 61);
            this.galleryPivotStylesItem1.Gallery.RowCount = 10;
            this.galleryPivotStylesItem1.Id = 317;
            this.galleryPivotStylesItem1.Name = "galleryPivotStylesItem1";
            // 
            // UserControl1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.SpreadSheet);
            this.Controls.Add(this.ribbonControl1);
            this.Name = "UserControl1";
            this.Size = new System.Drawing.Size(1221, 860);
            ((System.ComponentModel.ISupportInitialize)(this.ribbonControl1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.spreadsheetBarController1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemFontEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpreadsheetFontSizeEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemPopupGalleryEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.commandBarGalleryDropDown24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl1;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem1;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem2;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem3;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem4;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem5;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem6;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem7;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem8;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem9;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem10;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem11;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem12;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem13;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem14;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup1;
        private DevExpress.XtraSpreadsheet.UI.ChangeFontNameItem changeFontNameItem1;
        private DevExpress.XtraEditors.Repository.RepositoryItemFontEdit repositoryItemFontEdit1;
        private DevExpress.XtraSpreadsheet.UI.ChangeFontSizeItem changeFontSizeItem1;
        private DevExpress.XtraSpreadsheet.Design.RepositoryItemSpreadsheetFontSizeEdit repositoryItemSpreadsheetFontSizeEdit1;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem15;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem16;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup2;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem1;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem2;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem3;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem4;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup3;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem1;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem17;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem18;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem19;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem20;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem21;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem22;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem23;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem24;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem25;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem26;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem27;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem28;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem29;
        private DevExpress.XtraSpreadsheet.UI.ChangeBorderLineColorItem changeBorderLineColorItem1;
        private DevExpress.XtraSpreadsheet.UI.ChangeBorderLineStyleItem changeBorderLineStyleItem1;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown1;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup4;
        private DevExpress.XtraSpreadsheet.UI.ChangeCellFillColorItem changeCellFillColorItem1;
        private DevExpress.XtraSpreadsheet.UI.ChangeFontColorItem changeFontColorItem1;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup5;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem5;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem6;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem7;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup6;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem8;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem9;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem10;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup7;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem30;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem31;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem11;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem2;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem12;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem32;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem33;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem34;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup8;
        private DevExpress.XtraSpreadsheet.UI.ChangeNumberFormatItem changeNumberFormatItem1;
        private DevExpress.XtraEditors.Repository.RepositoryItemPopupGalleryEdit repositoryItemPopupGalleryEdit1;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup9;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem3;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem35;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem36;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem37;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem38;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem39;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem40;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem41;
        private DevExpress.XtraBars.BarButtonGroup barButtonGroup10;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem42;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem43;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem4;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem5;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem44;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem45;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem46;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem47;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem48;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem49;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem50;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem6;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem51;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem52;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem53;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem54;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem55;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem56;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem spreadsheetCommandBarButtonGalleryDropDownItem1;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown2;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem spreadsheetCommandBarButtonGalleryDropDownItem2;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown3;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem spreadsheetCommandBarButtonGalleryDropDownItem3;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown4;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem7;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem57;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem58;
        private DevExpress.XtraSpreadsheet.UI.GalleryFormatAsTableItem galleryFormatAsTableItem1;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown5;
        private DevExpress.XtraSpreadsheet.UI.GalleryChangeStyleItem galleryChangeStyleItem1;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem8;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem59;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem60;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem61;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem9;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem62;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem63;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem64;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem10;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem65;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem66;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem67;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem68;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem69;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem11;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem70;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem71;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem72;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem73;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem74;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem75;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem76;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem77;
        private DevExpress.XtraSpreadsheet.UI.ChangeSheetTabColorItem changeSheetTabColorItem1;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem78;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem13;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem79;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem12;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem80;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem81;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem82;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem83;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem84;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem13;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem85;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem86;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem87;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem88;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem14;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem89;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem90;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem91;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem92;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem93;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem94;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem15;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem95;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem96;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem14;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem97;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem98;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem16;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem99;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem100;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem101;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem102;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem103;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem104;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem105;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem106;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem107;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem108;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem spreadsheetCommandBarButtonGalleryDropDownItem4;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown6;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem spreadsheetCommandBarButtonGalleryDropDownItem5;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown7;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem spreadsheetCommandBarButtonGalleryDropDownItem6;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown8;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem spreadsheetCommandBarButtonGalleryDropDownItem7;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown9;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem spreadsheetCommandBarButtonGalleryDropDownItem8;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown10;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem spreadsheetCommandBarButtonGalleryDropDownItem9;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown11;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem spreadsheetCommandBarButtonGalleryDropDownItem10;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown12;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem109;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem110;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem17;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem15;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem16;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem17;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem111;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem18;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem18;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem19;
        private DevExpress.XtraSpreadsheet.UI.PageSetupPaperKindItem pageSetupPaperKindItem1;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem19;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem112;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem113;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem114;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem20;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem21;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem22;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem23;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem20;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem115;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem116;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem21;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem117;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem118;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem22;
        private DevExpress.XtraSpreadsheet.UI.FunctionsFinancialItem functionsFinancialItem1;
        private DevExpress.XtraSpreadsheet.UI.FunctionsLogicalItem functionsLogicalItem1;
        private DevExpress.XtraSpreadsheet.UI.FunctionsTextItem functionsTextItem1;
        private DevExpress.XtraSpreadsheet.UI.FunctionsDateAndTimeItem functionsDateAndTimeItem1;
        private DevExpress.XtraSpreadsheet.UI.FunctionsLookupAndReferenceItem functionsLookupAndReferenceItem1;
        private DevExpress.XtraSpreadsheet.UI.FunctionsMathAndTrigonometryItem functionsMathAndTrigonometryItem1;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem23;
        private DevExpress.XtraSpreadsheet.UI.FunctionsStatisticalItem functionsStatisticalItem1;
        private DevExpress.XtraSpreadsheet.UI.FunctionsEngineeringItem functionsEngineeringItem1;
        private DevExpress.XtraSpreadsheet.UI.FunctionsInformationItem functionsInformationItem1;
        private DevExpress.XtraSpreadsheet.UI.FunctionsCompatibilityItem functionsCompatibilityItem1;
        private DevExpress.XtraSpreadsheet.UI.FunctionsWebItem functionsWebItem1;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem124;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem125;
        private DevExpress.XtraSpreadsheet.UI.DefinedNameListItem definedNameListItem1;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem126;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem24;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem24;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem25;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem26;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem127;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem128;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem25;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem129;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem130;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem131;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem26;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem132;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem133;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem27;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem134;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem135;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem136;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem137;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem138;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem139;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem140;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem141;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem142;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem143;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem144;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem145;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem146;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem147;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem148;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem149;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem28;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem150;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem151;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem152;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem153;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem154;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem155;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem156;
        private DevExpress.XtraSpreadsheet.UI.GalleryChartLayoutItem galleryChartLayoutItem1;
        private DevExpress.XtraSpreadsheet.UI.GalleryChartStyleItem galleryChartStyleItem1;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem spreadsheetCommandBarButtonGalleryDropDownItem11;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown13;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem29;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem spreadsheetCommandBarButtonGalleryDropDownItem12;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown14;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem spreadsheetCommandBarButtonGalleryDropDownItem13;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown15;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem spreadsheetCommandBarButtonGalleryDropDownItem14;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown16;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem spreadsheetCommandBarButtonGalleryDropDownItem15;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown17;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem30;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem spreadsheetCommandBarButtonGalleryDropDownItem16;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown18;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem spreadsheetCommandBarButtonGalleryDropDownItem17;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown19;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem31;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem spreadsheetCommandBarButtonGalleryDropDownItem18;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown20;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem spreadsheetCommandBarButtonGalleryDropDownItem19;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown21;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem spreadsheetCommandBarButtonGalleryDropDownItem20;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown22;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem spreadsheetCommandBarButtonGalleryDropDownItem21;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown23;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonGalleryDropDownItem spreadsheetCommandBarButtonGalleryDropDownItem22;
        private DevExpress.XtraBars.Commands.CommandBarGalleryDropDown commandBarGalleryDropDown24;
        private DevExpress.XtraBars.BarStaticItem barStaticItem1;
        private DevExpress.XtraSpreadsheet.UI.RenameTableItem renameTableItem1;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit1;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem27;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem28;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem29;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem30;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem31;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem32;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem33;
        private DevExpress.XtraSpreadsheet.UI.GalleryTableStylesItem galleryTableStylesItem1;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem157;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem158;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem159;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem160;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem32;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem161;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem162;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem163;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem33;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem164;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem165;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem34;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem166;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem167;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem168;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem169;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem34;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem35;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem36;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem35;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem170;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem171;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem172;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem36;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem173;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem174;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem175;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem176;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem37;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem177;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem178;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem179;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem180;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem181;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarSubItem spreadsheetCommandBarSubItem38;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem182;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem183;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem37;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem38;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem39;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarCheckItem spreadsheetCommandBarCheckItem40;
        private DevExpress.XtraSpreadsheet.UI.GalleryPivotStylesItem galleryPivotStylesItem1;
        private DevExpress.XtraSpreadsheet.UI.ChartToolsRibbonPageCategory chartToolsRibbonPageCategory1;
        private DevExpress.XtraSpreadsheet.UI.ChartsDesignRibbonPage chartsDesignRibbonPage1;
        private DevExpress.XtraSpreadsheet.UI.ChartsDesignTypeRibbonPageGroup chartsDesignTypeRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.ChartsDesignDataRibbonPageGroup chartsDesignDataRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.ChartsDesignLayoutsRibbonPageGroup chartsDesignLayoutsRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.ChartsDesignStylesRibbonPageGroup chartsDesignStylesRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.ChartsLayoutRibbonPage chartsLayoutRibbonPage1;
        private DevExpress.XtraSpreadsheet.UI.ChartsLayoutLabelsRibbonPageGroup chartsLayoutLabelsRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.ChartsLayoutAxesRibbonPageGroup chartsLayoutAxesRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.ChartsLayoutAnalysisRibbonPageGroup chartsLayoutAnalysisRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.ChartsFormatRibbonPage chartsFormatRibbonPage1;
        private DevExpress.XtraSpreadsheet.UI.ChartsFormatArrangeRibbonPageGroup chartsFormatArrangeRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.TableToolsRibbonPageCategory tableToolsRibbonPageCategory1;
        private DevExpress.XtraSpreadsheet.UI.TableToolsDesignRibbonPage tableToolsDesignRibbonPage1;
        private DevExpress.XtraSpreadsheet.UI.TablePropertiesRibbonPageGroup tablePropertiesRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.TableToolsRibbonPageGroup tableToolsRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.TableStyleOptionsRibbonPageGroup tableStyleOptionsRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.TableStylesRibbonPageGroup tableStylesRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.PictureToolsRibbonPageCategory pictureToolsRibbonPageCategory1;
        private DevExpress.XtraSpreadsheet.UI.PictureFormatRibbonPage pictureFormatRibbonPage1;
        private DevExpress.XtraSpreadsheet.UI.PictureFormatArrangeRibbonPageGroup pictureFormatArrangeRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.DrawingToolsRibbonPageCategory drawingToolsRibbonPageCategory1;
        private DevExpress.XtraSpreadsheet.UI.DrawingFormatRibbonPage drawingFormatRibbonPage1;
        private DevExpress.XtraSpreadsheet.UI.DrawingFormatArrangeRibbonPageGroup drawingFormatArrangeRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.PivotTableToolsRibbonPageCategory pivotTableToolsRibbonPageCategory1;
        private DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeRibbonPage pivotTableAnalyzeRibbonPage1;
        private DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzePivotTableRibbonPageGroup pivotTableAnalyzePivotTableRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeActiveFieldRibbonPageGroup pivotTableAnalyzeActiveFieldRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeDataRibbonPageGroup pivotTableAnalyzeDataRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeActionsRibbonPageGroup pivotTableAnalyzeActionsRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.PivotTableAnalyzeShowRibbonPageGroup pivotTableAnalyzeShowRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.PivotTableDesignRibbonPage pivotTableDesignRibbonPage1;
        private DevExpress.XtraSpreadsheet.UI.PivotTableDesignLayoutRibbonPageGroup pivotTableDesignLayoutRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.PivotTableDesignPivotTableStyleOptionsRibbonPageGroup pivotTableDesignPivotTableStyleOptionsRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.PivotTableDesignPivotTableStylesRibbonPageGroup pivotTableDesignPivotTableStylesRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.FileRibbonPage fileRibbonPage1;
        private DevExpress.XtraSpreadsheet.UI.CommonRibbonPageGroup commonRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.InfoRibbonPageGroup infoRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.HomeRibbonPage homeRibbonPage1;
        private DevExpress.XtraSpreadsheet.UI.ClipboardRibbonPageGroup clipboardRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.FontRibbonPageGroup fontRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.AlignmentRibbonPageGroup alignmentRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.NumberRibbonPageGroup numberRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.StylesRibbonPageGroup stylesRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.CellsRibbonPageGroup cellsRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.EditingRibbonPageGroup editingRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.InsertRibbonPage insertRibbonPage1;
        private DevExpress.XtraSpreadsheet.UI.TablesRibbonPageGroup tablesRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.IllustrationsRibbonPageGroup illustrationsRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.ChartsRibbonPageGroup chartsRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.LinksRibbonPageGroup linksRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.SymbolsRibbonPageGroup symbolsRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.PageLayoutRibbonPage pageLayoutRibbonPage1;
        private DevExpress.XtraSpreadsheet.UI.PageSetupRibbonPageGroup pageSetupRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.PageSetupShowRibbonPageGroup pageSetupShowRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.PageSetupPrintRibbonPageGroup pageSetupPrintRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.ArrangeRibbonPageGroup arrangeRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.FormulasRibbonPage formulasRibbonPage1;
        private DevExpress.XtraSpreadsheet.UI.FunctionLibraryRibbonPageGroup functionLibraryRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.FormulaDefinedNamesRibbonPageGroup formulaDefinedNamesRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.FormulaAuditingRibbonPageGroup formulaAuditingRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.FormulaCalculationRibbonPageGroup formulaCalculationRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.DataRibbonPage dataRibbonPage1;
        private DevExpress.XtraSpreadsheet.UI.SortAndFilterRibbonPageGroup sortAndFilterRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.DataToolsRibbonPageGroup dataToolsRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.OutlineRibbonPageGroup outlineRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.ReviewRibbonPage reviewRibbonPage1;
        private DevExpress.XtraSpreadsheet.UI.CommentsRibbonPageGroup commentsRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.ChangesRibbonPageGroup changesRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.ViewRibbonPage viewRibbonPage1;
        private DevExpress.XtraSpreadsheet.UI.ShowRibbonPageGroup showRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.ZoomRibbonPageGroup zoomRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.WindowRibbonPageGroup windowRibbonPageGroup1;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetBarController spreadsheetBarController1;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem119;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem120;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem121;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem122;
        private DevExpress.XtraSpreadsheet.UI.SpreadsheetCommandBarButtonItem spreadsheetCommandBarButtonItem123;
        public DevExpress.XtraSpreadsheet.SpreadsheetControl SpreadSheet;
    }
}
