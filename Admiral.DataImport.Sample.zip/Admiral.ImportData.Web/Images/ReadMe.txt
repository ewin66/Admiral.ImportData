﻿Folder Description

The "Images" project folder is intended for storing custom image files.


Relevant Documentation

Add and Override Images
http://help.devexpress.com/#Xaf/CustomDocument2792

Assign a Custom Image
http://help.devexpress.com/#Xaf/CustomDocument2744
