﻿Folder Description

The "FunctionalTests" project folder is intended for storing EasyTest 
configuration file and scripts.


Relevant Documentation

Functional Testing
https://documentation.devexpress.com/eXpressAppFramework/CustomDocument113206.aspx
