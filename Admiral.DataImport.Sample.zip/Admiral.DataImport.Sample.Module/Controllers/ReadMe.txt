﻿Folder Description

The "Controllers" project folder is intended for storing platform-agnostic Controller classes 
that can change the default XAF application flow and add new features.


Relevant Documentation

Extend Functionality
https://documentation.devexpress.com/eXpressAppFramework/CustomDocument112623.aspx

Controller Class
https://documentation.devexpress.com/eXpressAppFramework/clsDevExpressExpressAppControllertopic.aspx

ViewController Class
https://documentation.devexpress.com/eXpressAppFramework/clsDevExpressExpressAppViewControllertopic.aspx

WindowController Class
https://documentation.devexpress.com/eXpressAppFramework/clsDevExpressExpressAppWindowControllertopic.aspx
